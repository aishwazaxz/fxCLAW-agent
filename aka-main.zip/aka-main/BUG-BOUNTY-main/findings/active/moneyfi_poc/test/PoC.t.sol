// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "forge-std/Test.sol";

contract MockERC20 {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        require(balanceOf[msg.sender] >= amount);
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(allowance[from][msg.sender] >= amount);
        require(balanceOf[from] >= amount);
        allowance[from][msg.sender] -= amount;
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        return true;
    }
}

contract MockFundVault {
    bool public _paused;
    mapping(address => mapping(address => uint256)) public deposits;

    function pause() external { _paused = true; }

    function depositFund(address _token, address _receiver, uint256 _amount) external returns (uint256) {
        // EXACT: MoneyFiFundVault has `whenNotPaused` modifier
        require(!_paused, "PausableUpgradeable.EnforcedPause");
        deposits[_token][_receiver] += _amount;
        // EXACT: IERC20(_tokenAddress).safeTransferFrom(msg.sender, address(this), _amount)
        MockERC20(_token).transferFrom(msg.sender, address(this), _amount);
        return _amount;
    }
}

contract MockDexBridgeVault {
    MockFundVault public fundVault;
    address public lzEndpoint;
    mapping(uint32 => mapping(bytes32 => bytes)) public payload;

    constructor(address _fv, address _lz) {
        fundVault = MockFundVault(_fv);
        lzEndpoint = _lz;
    }

    /// @dev EXACT replica of MoneyFiStargateCrossChain.lzCompose() vulnerable path
    function lzCompose(
        address,
        bytes32 _guid,
        bytes calldata _message,
        address,
        bytes calldata
    ) external payable {
        require(msg.sender == lzEndpoint);

        (address depositedToken, address depositor, uint256 amountLD, uint32 srcEid) =
            abi.decode(_message, (address, address, uint256, uint32));

        bytes memory _composeMessage = abi.encode(depositor, depositedToken, amountLD, bytes(""));
        payload[srcEid][_guid] = abi.encodePacked(_guid, _composeMessage);

        // VULNERABLE TRY-CATCH: lines ~8970-9002 of dexBridgeVault_impl.sol
        try MockERC20(depositedToken).approve(address(fundVault), amountLD) {
            try fundVault.depositFund(depositedToken, depositor, amountLD) {
                delete payload[srcEid][_guid];
            } catch {
                // FAILURE: tokens stuck, payload NOT deleted, NO recovery
            }
        } catch {
            // FAILURE: same problem
        }
    }
}

contract MoneyFiLzComposeFundLossPoC is Test {
    MockERC20 token;
    MockFundVault fundVault;
    MockDexBridgeVault dexBridge;

    address constant LZ = address(0x1234);
    address constant USER = address(0xBEEF);
    uint256 constant AMOUNT = 1000 ether;
    bytes32 constant GUID = keccak256("test-crosschain-guid");
    uint32 constant SRC_EID = 1;

    function setUp() public {
        token = new MockERC20();
        fundVault = new MockFundVault();
        dexBridge = new MockDexBridgeVault(address(fundVault), LZ);

        // Simulate: tokens arrive at dexBridgeVault via Stargate
        token.mint(address(dexBridge), AMOUNT);
    }

    function test_lzCompose_FundLoss_WhenVaultPaused() public {
        console.log("=== MoneyFi H-01: lzCompose Permanent Fund Loss PoC ===");
        console.log("");

        uint256 beforeBal = token.balanceOf(address(dexBridge));
        console.log("dexBridgeVault USDT balance:", beforeBal / 1e18);

        // Admin pauses vault (legitimate emergency)
        fundVault.pause();
        console.log("Admin pauses fundVault");

        // LayerZero delivers cross-chain message
        bytes memory msg_data = abi.encode(address(token), USER, AMOUNT, SRC_EID);

        vm.prank(LZ);
        dexBridge.lzCompose(address(0), GUID, msg_data, address(0), bytes(""));

        uint256 afterBal = token.balanceOf(address(dexBridge));

        console.log("");
        console.log("USDT STUCK in dexBridgeVault:", afterBal / 1e18);
        assertEq(afterBal, AMOUNT, "FUNDS PERMANENTLY STUCK");

        // Payload NOT deleted
        bytes memory stored = dexBridge.payload(SRC_EID, GUID);
        assertTrue(stored.length > 0, "Payload NOT deleted");

        // fundVault received NOTHING
        assertEq(fundVault.deposits(address(token), USER), 0, "No deposit recorded");

        console.log("");
        console.log("=== VULNERABILITY CONFIRMED ===");
        console.log("Severity: HIGH - Permanent fund loss");
        console.log("Condition: vault paused, token deactivated, LP address zero, etc.");
    }

    function test_lzCompose_Success_WhenVaultActive() public {
        bytes memory msg_data = abi.encode(address(token), USER, AMOUNT, SRC_EID);

        vm.prank(LZ);
        dexBridge.lzCompose(address(0), GUID, msg_data, address(0), bytes(""));

        assertEq(token.balanceOf(address(dexBridge)), 0, "Tokens moved to fundVault");
        assertEq(fundVault.deposits(address(token), USER), AMOUNT, "Deposit recorded");
        assertEq(dexBridge.payload(SRC_EID, GUID).length, 0, "Payload deleted");
    }
}
