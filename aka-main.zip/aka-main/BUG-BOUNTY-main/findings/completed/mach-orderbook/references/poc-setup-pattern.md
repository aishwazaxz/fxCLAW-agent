# MACH OrderBook PoC Setup Pattern

## How to Create Working PoC from Flattened BSCScan Source

### Problem
BSCScan `getsourcecode` returns flattened Solidity with broken imports. Pipeline compilation fails.

### Solution: Create Separate PoC Project

```bash
# 1. Create project structure
mkdir -p targets/MACH_PoC/{src/interfaces,test,lib}

# 2. Copy foundry.toml from working baseline
cp targets/MACH_BSC_OrderBookV2/foundry.toml targets/MACH_PoC/

# 3. Install dependencies
cd targets/MACH_PoC
forge install foundry-rs/forge-std --no-git
cp -r ../MACH_BSC_OrderBookV2/lib/openzeppelin-contracts lib/

# 4. Copy interfaces from original target
cp ../MACH_BSC_OrderBook/src_interfaces_IOptimistic.sol src/interfaces/IOptimistic.sol
cp ../MACH_BSC_OrderBook/src_interfaces_IWrapped.sol src/interfaces/IWrapped.sol

# 5. Copy contract source, fix imports
# Remove @openzeppelin → use lib/ path with remapping
# Fix double slashes: ./lzApp//lz-evm-oapp-v2 → ./lzApp/lz-evm-oapp-v2
# Fix Ownable(): OZ 5.x needs Ownable(owner) not Ownable()

# 6. Compile and fix
forge build  # iterate until clean
```

### Common Fixes

1. `match` is reserved keyword in Solidity 0.8+ → use `matchResult` etc.
2. `Ownable()` → `Ownable(owner)` for OZ 5.x
3. Mock LZ endpoint needs `setDelegate(address)` function (OApp constructor calls it)
4. Use `vm.startPrank(addr) / vm.stopPrank()` not multiple `vm.prank()` for sequential calls
5. Struct names need interface prefix: `OrderDirection` → `TradeInterface.OrderDirection`

### Test Structure

```solidity
contract MachCancelOrderPoC is Test {
    Orderbook public orderbook;
    MockToken public srcToken;
    MockToken public bondToken;
    
    function setUp() public {
        // Deploy mocks
        // Deploy Orderbook
        // Mint tokens
        // Approve orderbook
        // Setup direction, funding, expiration
    }
    
    function test_vulnerability_name() public {
        // Step 1: Setup state
        // Step 2: Execute attack
        // Step 3: Verify impact
        // Step 4: Log findings
    }
}
```

### Running Tests

```bash
cd targets/MACH_PoC
forge test --match-contract MachCancelOrderPoC -vvv
```

### Key Learnings

- Always create separate PoC project, don't try to fix original flattened source
- Use working baseline (MACH_BSC_OrderBookV2) as template
- Mock external dependencies (LayerZero, tokens)
- Test each vulnerability independently
- Log findings with emit log() for visibility
