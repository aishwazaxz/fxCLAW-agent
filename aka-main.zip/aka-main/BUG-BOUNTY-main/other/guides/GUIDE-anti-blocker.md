Anti-blocker toolkit for micro DeFi target research

Rule:
Do not stop just because one explorer/RPC is blocked.
Use legitimate public alternatives only: official explorer APIs, Sourcify, Blockscout API, bytecode fetch, managed RPC, and local fork.
No live fund interaction.

Install/tools:
- Foundry: cast, forge, anvil
- curl / jq
- Sourcify API
- Blockscout API
- explorer API per chain
- heimdall-rs for bytecode fallback
- 4byte / Sourcify signature lookup for unknown selectors
- Optional RPC providers: Tenderly, QuickNode, Alchemy, Ankr, dRPC, BlockPI

Source/ABI retrieval order:
1. Protocol docs contract list
2. Chain explorer verified source
3. Blockscout API v2
4. Etherscan-compatible explorer API
5. Sourcify lookup
6. GitHub/source repo baseline if protocol is fork
7. Bytecode + ABI/selectors fallback
8. Decompile only as last resort

Generic source checks:

Sourcify:
GET https://sourcify.dev/server/v2/contract/<CHAIN_ID>/<ADDRESS>

Blockscout v2:
GET <EXPLORER>/api/v2/smart-contracts/<ADDRESS>

Etherscan-compatible API:
GET <EXPLORER_API>?module=contract&action=getsourcecode&address=<ADDRESS>
GET <EXPLORER_API>?module=contract&action=getabi&address=<ADDRESS>

Bytecode:
cast code <ADDRESS> --rpc-url <RPC_URL>

Fork test:
forge test --fork-url <RPC_URL> -vvv

Local fork:
anvil --fork-url <RPC_URL> --fork-block-number <BLOCK>

#Chain endpoints for the targets

Cronos
- Chain ID: 25
- RPC primary: https://evm.cronos.org
- Explorer: https://cronos.org/explorer
- Explorer API: https://cronos.org/explorer/api
- Use for: Orby, Crodex, CronaSwap

Etherlink
- Chain ID: 42793
- RPC primary: https://node.mainnet.etherlink.com
- Explorer: https://explorer.etherlink.com
- Explorer API:
  https://explorer.etherlink.com/api
  https://explorer.etherlink.com/api/v2/smart-contracts/<ADDRESS>
- Use for: Superlend

Ink
- Chain ID: 57073
- RPC primary: https://rpc-gel.inkonchain.com
- Explorer: https://explorer.inkonchain.com
- Explorer API:
  https://explorer.inkonchain.com/api
  https://explorer.inkonchain.com/api/v2/smart-contracts/<ADDRESS>
- Use for: InkySwap / InkyPump

Mantle
- Chain ID: 5000
- RPC primary: https://rpc.mantle.xyz
- Explorer: https://explorer.mantle.xyz
- Explorer API:
  https://explorer.mantle.xyz/api
- Use for: Lendle

Plume
- Chain ID: 98866
- RPC primary: https://rpc.plume.org
- Explorer: https://explorer.plume.org
- Explorer API:
  https://explorer.plume.org/api
  https://explorer.plume.org/api/v2/smart-contracts/<ADDRESS>
- Use for: HARVEST FLOW / Plume RWA targets

Rootstock
- Chain ID: 30
- Explorer: https://explorer.rootstock.io
- Use for: Rootstock long-tail targets

#If Cronoscan/Cronos RPC blocks:

Do not mark target dead.

Fallback flow:
1. Try cronos.org explorer API:
   https://cronos.org/explorer/api?module=contract&action=getabi&address=<ADDRESS>
   https://cronos.org/explorer/api?module=contract&action=getsourcecode&address=<ADDRESS>

2. Try Blockscout v2 style:
   https://cronos.org/explorer/api/v2/smart-contracts/<ADDRESS>

3. Try Sourcify:
   https://sourcify.dev/server/v2/contract/25/<ADDRESS>

4. Fetch bytecode:
   cast code <ADDRESS> --rpc-url https://evm.cronos.org

5. If public RPC returns 403:
   use a managed RPC key from QuickNode / Ankr / dRPC / Tenderly / BlockPI.
   Do not spam public endpoints.

6. If source still unavailable:
   compare function selectors and bytecode shape against likely upstream fork.
   Example: Orby looks like Liquity fork, so compare against Liquity source:
   https://github.com/liquity/dev

7. Only decompile if source is unavailable:
   heimdall decompile <BYTECODE_FILE> --include-sol -o ./decompiled

   #Quality rules:
- Cache every API response.
- Add retry with backoff.
- Never rely on one explorer.
- Never say “no source” until Sourcify + explorer API + docs + bytecode were checked.
- If ABI-only, mark as LIMITED MODE.
- If source unavailable but fork baseline exists, do fork-diff hypothesis, not full confidence.
- HIGH confidence requires fork/local PoC.