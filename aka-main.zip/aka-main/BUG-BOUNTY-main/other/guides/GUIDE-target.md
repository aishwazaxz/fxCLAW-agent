Execution approach per target

General order:
1. Confirm contracts are live:
   - get code length
   - get latest tx/activity
   - verify proxy or implementation
2. Fetch source/ABI:
   - docs -> explorer -> Blockscout -> Sourcify -> bytecode fallback
3. Classify protocol:
   - DEX / lending / CDP / vault / factory / farm
4. Identify upstream fork:
   - Liquity / Aave / UniswapV2 / MasterChef / bonding curve
5. Diff against upstream:
   - constants changed
   - oracle changed
   - collateral/token changed
   - fee changed
   - admin roles changed
   - emergency path changed
6. Build fork-local PoC harness.
7. Only output value-impact candidates:
   - drain
   - indirect drain
   - freeze with value at risk
   - accounting corruption

   #Target-specific approach

1. Orby / Cronos / Liquity-style CDP
Start from Liquity diff.
Check:
- collateral token differences
- MCR / CCR / liquidation reserve
- oracle adapter
- redemption path
- StabilityPool offset math
- CollSurplusPool withdrawals
- SortedTroves ordering
Fork :
- stale price liquidation
- undercollateralized trove redemption
- liquidation sequence causing surplus loss
- StabilityPool depositor accounting drift
- collateral-specific decimals mismatch

2. Superlend / Etherlink / Aave-style lending
Start from Aave fork diff.
Check:
- reserve config
- LTV/liquidation threshold
- oracle decimals
- interest rate strategy
- gateway native token handling
- isolation/paused/frozen reserve flags
Fork :
- wrong oracle decimals causes bad liquidation
- collateral enabled but price stale
- borrow/repay/withdraw sequence locks user
- gateway withdraw mismatch

3. Crodex or CronaSwap / Cronos / UniswapV2 + farm
Start from UniswapV2/MasterChef diff.
Check:
- pair fee logic
- fee-on-transfer support
- skim/sync assumptions
- MasterChef reward debt
- emergency withdraw
- escrow/vault release
Fork :
- fee-on-transfer pair reserve drift
- LP burn/mint edge
- reward debt corruption
- emergency withdraw drains/sticks rewards

4. Lendle / Mantle / lending + incentives
Start from Aave/Geist/Radiant-style diff.
Check:
- oracle
- incentives controller
- MasterChef reward logic
- WETH gateway
- liquidation math
Fork :
- reward accounting double-claim
- liquidation with stale price
- gateway deposit/withdraw mismatch
- paused/frozen reserve exit path

5. InkyPump / Ink / token factory + bonding curve
Start from factory logic.
Check:
- token creation fee
- creator fee exemption
- bonding curve buy/sell math
- graduation threshold
- LP burn/permanent liquidity
- anti-snipe fee decay
Fork :
- buy/sell roundtrip profit
- fee decay bypass
- graduation stuck state
- creator/attacker drains curve reserve

#Do not come back with “blocked” unless:
- docs checked
- explorer API checked
- Sourcify checked
- at least 2 RPC providers tried
- bytecode fetched or confirmed unavailable
- upstream fork baseline identified or ruled out
- LIMITED MODE reason written

Expected output:
- target_status.md
- source_fetch_log.md
- fork_baseline.md
- risk_map.md
- poc_plan.md
- findings

#END