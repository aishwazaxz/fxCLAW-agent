# Smart-Contract Bug Hunting Engine

## Prinsip

- **Reasoning engine sendiri** — public tools (solc, Slither, Foundry, Medusa, Halmos) hanya optional backend. Bukan aggregate.
- **Primary source: solc AST** — tidak tergantung output format tools publik.
- **Deterministic** — setiap finding harus punya PoC test yang pass via `forge test`.
- **Full spectrum** — semua bug class, tapi modular sebagai risk packs.
- **Degrade gracefully** — engine tetap jalan meskipun satu atau lebih backend unavailable.
- **No hallucination** — kalau fungsi tidak ada di ABI/AST, jangan dikarang.
- **Cache per repo/commit** — tidak perlu re-analyze yang sudah pernah di-run.

---

## 1. Core Analyzer

Input: Solidity source files atau directory.

Build normalized project model:

- `contracts`: nama, file path, pragma version
- `inheritance`: parent contracts, linearization order
- `functions`: name, visibility, modifiers, parameters, return values, source range
- `modifiers`: name, body (block scope), underlying function
- `state_variables`: name, type, visibility, initial value, source range
- `events`: name, parameters, topics
- `external_calls`: function calls ke contract lain (address, function name, parameters)
- `storage_writes`: state variable mutations per function
- `call_graph`: who calls who, cross-contract edges
- `role_map`: role assignments (ACCESS_CONTROL, OWNABLE, PAUSABLE, etc) — who can call what
- `fund_flow_map`: user entry points (deposit/stake/mint), exit points (withdraw/claim/redeem),中间 state (idle/allocated/staked)

Data sources (priority order):
1. solc AST JSON — primary, must work
2. BSCScan/Etherscan ABI — fallback kalau tidak ada source
3. Slither output — enrichment only, not required

Output: normalized JSON model per contract, cached per project/commit di `cache/model.json`.

---

## 2. Risk Model (Risk Packs)

Full spectrum, modular. Setiap pack berdiri sendiri tapi share core model.

### Pack 1: access_control_config
- Role bisa mutate config yang affect user deposit/withdrawal path
- Missing onlyOwner/onlyRole di setter yang kritis
- Role terlalu powerful (can pause, can set fee, can upgrade, can drain)
- Ownership renouncement tanpa timelock
- Config setter tidak validasi new value (zero address, invalid interface)

### Pack 2: accounting_invariant
- totalSupply vs actual balance mismatch
- Fee/rounding bug (biasanya round-down atau round-up)
- Share price manipulation (mint/burn dengan stale price)
- idle balance vs allocated accounting drift
- Debt tracking inconsistency

### Pack 3: withdrawal_freeze
- Withdraw/redeem/claim path bisa revert atau stuckpermanent
- Queue state tidak bisa progress (no execute, timelock tidak expire)
- External dependency (adapter, oracle, another contract) revert block exit
- Emergency withdrawal hanya owner-triggered, user tidak bisa exit normal

### Pack 4: griefing_force_actions
- Zero fee / zero penalty unlock DoS path
- forceDeallocate / forceWithdraw / emergency action abuserandom user balance
- Public action dengan weak gating yang harm unrelated users
- front-running withdrawal dengan high gas
- flash loan + donation attack bikin balance microscopic

### Pack 5: drain_value_flow
- Approved funds bisa di-steal (approve + transferFrom race)
- Reentrancy (no reentrancy guard di balance update)
- Flash loan manipulated accounting/oracle path
- Unsafe transfer/transferFrom tanpa permit
- Logic bug yang buka drain path tanpa explicit approval

### Pack 6: logic_state_machine
- Impossible state transition (misal: already withdrawn tapi masih bisa claim)
- Stale config assumption (misal: assume price selalu > 0)
- Wrong ordering: state update setelah external call
- Integer overflow/underflow (kalau bukan SafeMath)
- Missing zero-address check
- Unchecked return value dari external call

---

## 3. Sequence Planner

Generate exploit sequences dari actual contract graph — bukan hardcoded names.

### Step:
1. **Identify user entry points** — dari fund_flow_map: deposit*, stake*, mint*, approve*
2. **Identify privileged entry points** — dari role_map: set*, update*, pause*, upgrade*, force*, allocate*
3. **Identify exit points** — withdraw*, claim*, redeem*, harvest*, transfer*
4. **Map dependencies** — config yang dibaca di exit path, external calls yang harus succeed

### Sequence template:
```
[Setup] user deposit/stake
[Role] privileged mutation OR adapter abnormal
[Trigger] conditions yang mestinya protect user
[Exploit] action yang violate invariant
[Verify] withdrawal fails OR funds affected OR accounting drift
```

### Branches per sequence:
- success path — exploit berhasil, user tidak bisa withdraw
- revert path — exploit menyebabkan revert
- stuck state path — state machine stuck, tidak bisa progress
- partial loss path — sebagian funds affected
- accounting drift path — numbers tidak cocok tapi tidak revert

Output: list of candidate sequences dengan preconditions jelas, di `logs/candidates.json`.

---

## 4. Harness Generator

Generate Foundry test dari model:

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "forge-std/Test.sol";

contract Exploit_[id] is Test {
    address user = makeAddr("user");
    address role = makeAddr("role");
    address attacker = makeAddr("attacker");

    function setUp() {
        vm.label(user, "user");
        vm.label(role, "role");
        vm.label(attacker, "attacker");
        // deploy target
        // setup initial state
    }

    function test_[finding_id]_[description]() public {
        // [Setup]
        // [Role mutation]
        // [Trigger]
        // [Verify: invariant violated OR withdrawal fails]
    }
}
```

Actors:
- `user` — victim, deposited funds
- `role` / `admin` — privileged account
- `attacker` — malicious actor
- `adapter` / `mock` / `oracle` — protocol dependency (mock kalau perlu)

Invariant assertions:
- `user can withdraw within N blocks`
- `totalAssets == idle + allocated` (within tolerance)
- `balanceOf(user) >= expected minimum`
- `withdrawal reverts only if documented`

---

## 5. Validation Layer

Every finding must pass semua ini sebelum di-report:

1. **Reproducible** — `forge test --match-path poc.t.sol -vvv` pass, tidak flaky
2. **Compilable** — `forge build` sukses tanpa warning
3. **Minimized** — trace seminimal mungkin, hapus langkah yang tidak perlu
4. **Preconditions clear** — state apa yang perlu dipenuhi sebelum exploit jalan
5. **Impact quantified** — berapa dana affected, berapa user impacted
6. **Source lines exact** — contract name + line number
7. **False-positive check** — kalau fungsi revert karena invalid setup, bukan bug
8. **Confidence reason** — HIGH / MED / LOW + alasan

### Confidence scoring:
- **HIGH** — PoC pass, exploit path jelas, tidak butuh kondisi rare
- **MED** — PoC pass tapi perlu asumsi (oracle price realistic, mempool, dll)
- **LOW** — PoC gagal atau butuh kondisi sangat spesifik

### Output per finding:
```
findings/
  [finding-id]/
    poc.t.sol        # Foundry test
    trace.txt        # minimized trace
    report.md        # impact, preconditions, source lines
  findings.json      # summary semua finding
logs/
  candidates.json    # semua candidate sequences
  rejected_candidates.json  # kenapa di-reject
cache/
  model.json         # normalized project model
```

---

## 6. Backend Adapters

Isolation layer — engine tidak depend langsung ke specific tool interface. Kalau satu fail, engine continues dengan capability degraded.

### solc Adapter (required for AST)
- Parse solc AST JSON
- Extract contracts, functions, modifiers, state vars
- Fallback: BSCScan ABI API kalau source tidak ada

### Slither Adapter (optional)
- Call graph enrichment
- Extra data flow hints
- Fallback: engine jalan dengan AST saja

### Foundry Adapter (required for PoC)
- Run tests: `forge test --match-path poc.t.sol -vvv`
- Parse output untuk pass/fail
- Fallback: tidak ada — PoC required

### Medusa Adapter (optional)
- Long sequence fuzzing untuk finding tambahan
- Fallback: engine jalan tanpa fuzzing

### Halmos Adapter (optional)
- Symbolic confirmation untuk minimized path
- Fallback: engine jalan tanpa symbolic

### BSCScan Adapter (optional)
- Fetch ABI when source not available
- Fetch contract metadata
- Fallback: skip kalau API fail

---

## 7. Duplicate Avoidance

Before output:

- Check kalau finding adalah generic known issue
- Require unique angle: different precondition, shorter path, stronger impact, proof of liveness/freeze
- Cross-check dengan report lain kalau ada

Reject candidate harus ada di `logs/rejected_candidates.json` dengan reason.

---

## CLI Interface

```bash
hermes-hunt <target-dir-or-repo> [flags]

Flags:
  --class access_control_config    # pack 1
  --class accounting_invariant     # pack 2
  --class withdrawal_freeze        # pack 3
  --class griefing_force_actions   # pack 4
  --class drain_value_flow         # pack 5
  --class logic_state_machine      # pack 6
  --class all                      # all packs (default)
  --min-confidence HIGH            # minimum confidence
  --output ./findings              # output directory
```

---

## Release Plan

### v0.1
- Core Analyzer (AST → normalized model)
- role_map, fund_flow_map
- external_call_map, storage_write_map
- Foundry harness generator
- Risk packs:
  1. access_control_config
  2. withdrawal_freeze
  3. griefing_force_actions

### v0.2
- accounting_invariant pack
- Mock ERC20/ERC4626/adapters untuk harness
- Sequence minimizer

### v0.3
- drain_value_flow pack
- Reentrancy detector
- value-flow graph
- Medusa integration

### v0.4
- Halmos confirmation
- Differential adapter/token simulation
- Cross-protocol findings

---

## Quality Bar

- Tidak ada fungsi yang dikarang jika tidak ada di ABI/AST
- Tidak ada exploit path yang tidak bisa direproduksi
- Tidak ada report kalau `forge test` gagal (HIGH confidence)
- Engine deterministic — hasil sama tiap run dengan input sama
- Cache per project per commit
- Log setiap keputusan: kenapa candidate dipilih, kenapa di-reject

## Catatan

- Framework ini reasoning engine, bukan tool aggregator. Public tools sebagai optional component.
- Setiap model/agent lain bisa implement independent, asal output format konsisten.
- Bug class tidak dibatasi. Pack modular jadi bisa expand tanpa ubah core.