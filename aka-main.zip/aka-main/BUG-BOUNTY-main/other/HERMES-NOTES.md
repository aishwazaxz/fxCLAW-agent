# Hermes Notes — BUG-BOUNTY Workspace

Copy ini ke `~/.hermes/memories/` atau paste ke Hermes chat sebagai context.

## Environment
- RPC: BSC Infura. Sepolia (publicnode), Base Sepolia (sepolia.base.org)
- Foundry v1.7.1 installed
- Web tools: subfinder, nuclei, ffuf, sqlmap (~/go/bin/)
- EXA + FIRECRAWL API working (keys in .env)
- FlareSolverr: docker port 8191 (CF bypass)
- Playwright+Stealth: pip install playwright playwright-stealth

## Web Hunting Rules
- Target LOW security TLDs: .xyz, .top, .icu, .online, .site, .fun, .club, .vip, .pw
- CF WAF BYPASS ORDER: FlareSolverr → Playwright+Stealth → cloudscraper → pivot
- NEVER skip CF without trying FlareSolverr first

## Fail Rule
- Gagal → analisis kenapa → fix → retry
- JANGAN langsung pivot/skip
- sed gagal = pakai patch()
- timeout = naikkan timeout
- JSON error = pakai json_parse()

## Key Skills (auto-load)
1. `cf-auto-bypass` — CF detected → langsung FlareSolverr
2. `judol-attack-flow` — Full judol attack flow
3. `web-hunting-workflow` — General web hunting
4. `waf-bypass-workflow` — WAF bypass
5. `bsc-smart-contract-audit` — BSC pipeline

## Attack Flow (Judol)
1. RECON: FlareSolverr → subfinder → crt.sh → Shodan → Gau
2. ENUMERATE: /checkExistingEmail → hidden endpoints → S3 → .env
3. EXPLOIT: SQLi → mass assignment → PIN brute → IDOR → APP_KEY RCE

## Tools Location
- tools/onchain/ — BSC pipeline, audit_gate, scorer
- tools/web/ — web_hunter, sqlmap-dev, flare_bypass, playwright_stealth
- tools/GUIDE-*.md — hunting guides
- findings/ — smart contract PoC
- recon/ — web recon data

## Repo
- GitHub: https://github.com/awalusaha03-gif/BUG-BOUNTY
- Clone → run `bash skills/setup-skills.sh` → langsung jalan
