---
name: bsc-smart-contract-audit
description: "End-to-end DeFi bug bounty hunting pipeline - multi-chain target discovery, source fetching, analysis, exploit pattern testing, confidence scoring, and gate-verified reporting. NOT audit (read-only). This is kerja nyata - real execution, real PoC, quantitative impact."
triggers:
  - bug bounty multi-chain contract
  - smart contract vulnerability finding
  - DeFi target discovery
  - find exploit in contract
  - kerja nyata
  - on-chain investigation
  - full spectrum bug hunting
  - chain target selection
---

# DeFi Bug Bounty Hunting Pipeline (Multi-Chain)

Full-spectrum bug hunting workflow for DeFi contracts. Tools live at `/workspaces/BUG-BOUNTY/tools/`. Supports BSC, Ink, Mantle, Cronos, Etherlink, Sonic, Plasma.

## Core Principle

**Model TIDAK BOLEH claim vulnerability tanpa gate approval.** audit_gate.sh = hakim akhir. Confidence scoring wajib: HIGH = PoC pass, MED = slither/semgrep detect, LOW = manual only, NONE = cannot claim.

**Full spectrum — no artificial restriction on bug class.** Bug hunting, not "audit". All exploit classes are in scope: access control, accounting, freeze/liveness, griefing, theft/drain, reentrancy, logic bugs, front-running. The `guide-tools.md` defines the reasoning engine architecture — read it for the full framework.

**IMPORTANT: Do not use the word "audit"** when describing our work — it implies read-only. Our work is bug bounty hunting / on-chain investigation / exploit development. Real execution, real PoC, quantitative impact. Not documentation.

**APPROACH: Hunting Mandiri (Independent Research)**
User is NOT a traditional bounty hunter (find → submit → get paid). This is independent security research:
- **Target → Mechanism → Tools → Discard Results**
- **KEEP**: Pola/technique yang dipelajari, reusable tools, skill/knowledge applicable ke target lain
- **DISCARD**: Report/findings, PoC buat submit, data target spesifik
- **GOAL**: Experience & knowledge accumulation, not bounty submission
- Testnet = primary playground for learning exploit mechanisms without risk

## Source Fetching Workflow (MUST READ FIRST)

**Before starting ANY target on ANY chain, read `/workspaces/BUG-BOUNTY/anti-blocker-toolkit.md` first.** It contains chain-specific RPC endpoints, explorer APIs, and the exact fallback order. This is the canonical reference for multi-chain source/ABI retrieval.

**See**: `references/multi-chain-source-fetching.md` for the full workflow including:
- Cronos cronos.org/explorer/api (works where cronoscan.com is blocked)
- Blockscout v2 API: `/v2/smart-contracts/<ADDRESS>`
- Sourcify lookup: `/server/v2/contract/<CHAIN_ID>/<ADDRESS>`
- Fork-diff hypothesis when source is unavailable
- Bytecode selector comparison against known fork baseline
- Source confidence levels: HIGH (verified source + PoC), MEDIUM (fork-diff hypothesis), LOW (bytecode-only), LIMITED (ABI-only)

**Chain IDs for Sourcify:**
- Cronos: 25
- Etherlink: 42793
- Ink: 57073
- Mantle: 5000
- Plume: 98866
- Rootstock: 30

**Bytecode selector extraction** (primary technique when source unavailable):
1. Get runtime bytecode via `eth_getCode` RPC (or explorer API proxy if RPC blocked)
2. Parse for PUSH4 (0x63) opcodes → extract 4-byte selectors
3. Test each selector via `eth_call` with no params, address param, uint param, two-address params
4. Working selectors identify contract type (factory vs token vs vault)
5. Compare against known fork baseline selectors (UniSwap V2, Liquity, MasterChef, etc.)
6. Fork-diff hypothesis: extra/modified selectors = customization = attack surface

**Selector fingerprinting for mystery contracts (when implementation not verified):**
When you have the proxy ABI but the implementation source is unverified, use `forge test` to do systematic selector fingerprinting:

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
import "forge-std/Test.sol";

contract SelectorFingerprint is Test {
    address constant PROXY = <target>;
    string RPC = "<chain-rpc>";
    
    function setUp() public { vm.createSelectFork(RPC); }
    
    // Phase 1: Arg-sensitivity test - does the function read args?
    // If data is IDENTICAL regardless of arg, it's returning a hardcoded constant
    function test_arg_sensitivity() public {
        bytes4 target = <selector>;
        address[5] memory args = [address(0), address(1), OWNER, attacker, PROXY];
        bytes memory lastData;
        bool same = true;
        
        for (uint i = 0; i < 5; i++) {
            (bool ok, bytes memory data) = PROXY.call(abi.encodeWithSelector(target, args[i]));
            if (i > 0 && keccak256(data) != keccak256(lastData)) same = false;
            lastData = data;
        }
        // If same=true → pure hardcoded return, NOT reading storage
        emit log_named_uint("Returns constant regardless of arg", same ? 1 : 0);
    }
    
    // Phase 2: Access control test - does it work from attacker vs owner?
    function test_access_control() public {
        vm.prank(attacker);
        (bool attacker_ok, ) = PROXY.call(abi.encodeWithSelector(<selector>));
        
        vm.prank(OWNER);
        (bool owner_ok, ) = PROXY.call(abi.encodeWithSelector(<selector>));
        
        // If attacker_ok == owner_ok == true → no access control on this function
        // If attacker_ok == false && owner_ok == true → access control present
        // If both false → function reverts or doesn't exist
    }
    
    // Phase 3: State mutation test - does it modify storage?
    function test_state_mutation() public {
        bytes32 slot7_before = vm.load(PROXY, bytes32(uint256(7)));
        bytes32 slot3_before = vm.load(PROXY, bytes32(uint256(3)));
        
        (bool ok, ) = PROXY.call(abi.encodeWithSelector(<selector>, attacker));
        
        bytes32 slot7_after = vm.load(PROXY, bytes32(uint256(7)));
        bytes32 slot3_after = vm.load(PROXY, bytes32(uint256(3)));
        
        // If storage unchanged → view/pure function
        emit log_named_uint("slot7 changed", slot7_before != slot7_after ? 1 : 0);
    }
    
    // Phase 4: Batch common write selectors scan
    function test_batch_write_selectors() public {
        bytes4[30] memory writeSelectors = [
            0x2e1a7d4d, 0xdcadc3b7, 0xf3fc6a45, // sweepToken, skim, etc.
            // ... more common DeFi write selectors
        ];
        uint256 ok_count = 0;
        for (uint i = 0; i < writeSelectors.length; i++) {
            vm.prank(attacker);
            (bool ok, ) = PROXY.call(abi.encodeWithSelector(writeSelectors[i]));
            if (ok) { ok_count++; emit log("WORKING FROM ATTACKER"); }
        }
    }
}
```

**Key insight:** `cast call <addr> "0x<selector>" --rpc-url <rpc>` returns data even without full calldata — useful for quick fingerprinting of mystery functions.

**Interpretation guide:**
| Result | Meaning |
|--------|---------|
| Returns identical data regardless of args | Pure getter returning hardcoded constant (low exploit potential) |
| Returns different data for different args | Reads state or computes based on input (investigate further) |
| Works from attacker AND owner | No access control on this function |
| Works from owner only | Access control present (normal) |
| All common selectors revert | Standard access control, not exploitable |

**forge --fork-url** is the definitive verification tool after selector fingerprinting:
- Confirms owner, implementation, admin via `vm.load()` storage reads
- Tests functions with actual Solidity ABI (not raw selector encoding)
- Allows `vm.prank(owner)` to test owner-only functions
- Storage slot inspection (`vm.load(addr, bytes32(uint256(N)))`) for state variables
When target is a known fork (e.g., Orby = Liquity fork on Cronos, CronaSwap = MasterChef fork), and source is not verified:
1. Fetch baseline fork source from GitHub (e.g., Liquity from `github.com/liquity/dev`)
2. Extract function selectors from bytecode via `cast code <impl> --rpc-url <RPC>` (or explorer API if RPC blocked)
3. Compare selectors against baseline — extra/modified/different selectors indicate customization
4. Build hypothesis: "Orby changed X from Liquity → potential finding in Y"
5. Confidence: MEDIUM at best without source, cannot claim HIGH without PoC on actual code

**Working public RPCs** (this environment, 2026-05-31):
- BSC: `https://bsc-dataseed.binance.org` ✅ (block 101M)
- Mantle: `https://rpc.mantle.xyz` ✅ (block 96M)
- Etherlink: `https://node.mainnet.etherlink.com` ✅ (block 44M)
- Sonic: `https://rpc.soniclabs.com` ✅ (block 72M+, chain ID 146)
- Ink, Cronos, Polygon, Celo, Plume: 403 or unreachable from this environment

**QuickNode works** when public RPCs don't: user-provided QuickNode endpoints work for Ink, Mantle, Etherlink chains. Format: `https://<subdomain>.quiknode.pro/<key>/`. Tatum keys do NOT work in this environment (403 on all chains).

**Proxy implementation discovery (EIP-1967):**
1. Read proxy contract ABI via explorer API → get `ImplementationAddress` from proxy events
2. Or: read EIP-1967 impl slot via `eth_getStorageAt` RPC
3. Then fetch implementation source via same explorer API chain
4. If implementation not verified → fork-diff hypothesis, LIMITED confidence

## New Chain Onboarding Workflow

When user says "gas ke [chain]" or "cari chain baru", follow this sequence (DO NOT delegate — do it inline):

### Step 1: RPC Connect
```bash
export PATH="$HOME/.foundry/bin:$PATH"
cast block-number --rpc-url <RPC>
cast chain-id --rpc-url <RPC>
cast block latest --rpc-url <RPC> | head -15
```
Verify: block number returns, chain-id matches expected.

### Step 2: Ecosystem Scan (DeFiLlama)
```bash
# Top protocols on chain
curl -s "https://api.llama.fi/protocols" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for p in data:
    if '<CHAIN>' in p.get('chains', []):
        print(f'{p[\"name\"]:20s} TVL: \${p.get(\"tvl\",0)/1e6:.2f}M  Cat: {p.get(\"category\")}')
" 

# Top pools (more granular)
curl -s "https://yields.llama.fi/pools" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for p in data.get('data', []):
    if p.get('chain') == '<CHAIN>' and p.get('tvlUsd', 0) > 100000:
        print(f'{p[\"project\"]:25s} {p[\"symbol\"]:25s} Pool: {p[\"pool\"]}')
"
```

### Step 3: Bug Bounty Check
- Search: `immunefi.com <chain> bug bounty`
- Check chain's official docs for contract addresses
- Look for bridge contracts (often have dedicated bounties)

### Step 4: Core Contract Verification
```bash
# Verify all known contracts are live (have bytecode)
for addr in <addresses>; do
  size=$(cast code --rpc-url <RPC> "$addr" | wc -c)
  if [ "$size" -gt 3 ]; then echo "✓ $addr ($size chars)"
  else echo "✗ $addr (EMPTY)"; fi
done
```

### Step 5: Save Reference
Create `references/<chain>-chain.md` with:
- Chain info (ID, RPC, explorer, gas)
- Bug bounty scope + contract addresses
- Core tokens (wS, WETH, USDC, etc.)
- Top DeFi protocols (from DeFiLlama)
- DeFiLlama pool IDs for tracking
- Known exploits on that chain
- Hunting notes (fork types, audit coverage, attack surface)

### Step 6: Present to User
Show: chain stats, bug bounty (if any), top 10 protocols, and ask user which target to focus on.

**NEVER delegate this workflow.** It's 3-5 terminal calls + 1-2 web searches. Inline execution is faster than subagent overhead.

## Chain Selection Strategy

**Avoid pro-hunter lanes:** Hyperliquid, Monad mainnet, Berachain mainnet, Base top protocols, Arbitrum top protocols, Ethereum mainnet top protocols — too crowded with professional hunters.

**Target chains (in priority order, 2026-06-05):**
- Ink, Mantle, Cronos, Sonic mid-tail, Plasma mid-tail
- **NEW/under-hunted:** Berachain (new, EVM, lots of hype but less audited tail), Monad (new EVM, fast), Sei (CosmWasm + EVM dual), Etherlink (Tezos L2), Rootstock (Bitcoin L2)
- Protocol TVL: $2M-$50M
- Deploy age: < 90 days fresh OR old but under-the-radar
- Source: verified on explorer
- Type: fork vault/lending/DEX with adapter/strategy/allocator pattern
- Audit: minimal or none (don't trust DeFiLlama audit field — unreliable)

**DeFiLlama chain names:**
- BSC = "Binance"
- Ink = "Ink"
- Mantle = "Mantle"
- Cronos = "Cronos"
- Etherlink = "Etherlink"
- Sonic = "Sonic"
- Plasma = "Plasma"

**TVL verification:** DeFiLlama TVL may differ from actual on-chain TVL. For tokens (e.g., BTCST), DeFiLlama shows ~$950K but CoinGecko shows $97M mcap. Always verify on-chain for actual TVL-bearing contracts.

## Pipeline Flow

```
1. bsc_target_pipeline.sh   → discover targets from DeFiLlama
2. pipeline.sh <target> <proxy> → full audit:
   a. fetch_source.py       → ambil source dari BSCScan
   b. bscscan_query.py      → contract details
   c. analyze_contracts.py  → struktur analysis
   d. proxy_checker.py      → ERC1967/UUPS/Transparent checks
   e. forge test exploit_suite/P_ExploitPatterns.t.sol
   f. forge test exploit_suite/P_InvariantTemplate.t.sol
   g. trace_simulator.py    → tx trace analysis
   h. audit_gate.sh         → HAKIM AKHIR
3. FALSE NEGATIVE CHECK     → jangan langsung buang target
```

## Key Rules

### Confidence Scoring (wajib untuk semua findings)
```
HIGH   = forge test PASS (PoC reproduced)     → CLAIMABLE
MEDIUM = slither/semgrep detect                → CLAIMABLE
LOW    = manual review only                    → CLAIMABLE_WITH_CAVEAT
NONE   = no evidence                           → CANNOT CLAIM
```

### False Negative Check (wajib sebelum skip target)
When audit_gate.sh returns FAIL:
1. **Dependency missing?** → Fix imports, re-run
2. **RPC timeout/rate-limit?** → Ganti RPC, re-run
3. **Test gak jalan?** → Fix foundry.toml, re-run
4. **Solc version mismatch?** → Fix solc, re-run
Jika ada salah satu → fix → re-run pipeline. Jika semua clean → baru skip.

### Parallel Analysis
Pakai `delegate_task` dengan `tasks` array (max 3 concurrent) untuk analyze multiple targets sekaligus.

## Tools Inventory

**Foundry v1.7.1** (installed 2026-06-05): `forge`, `cast`, `anvil`, `chisel` at `~/.foundry/bin`. Add to PATH: `export PATH="$HOME/.foundry/bin:$PATH"`. Update via `foundryup`.

**Foundry install (if missing):**
```bash
curl -L https://foundry.paradigm.xyz | bash
export PATH="$HOME/.foundry/bin:$PATH"  # MUST export before foundryup
foundryup
```
**Pitfall:** `source ~/.bashrc` does NOT reliably pick up foundryup in non-interactive shells. Always use explicit `export PATH="$HOME/.foundry/bin:$PATH"` before any forge/cast/anvil command.

| Tool | Purpose |
|------|---------|
| `pipeline.sh` | Full audit pipeline (single target) |
| `bsc_target_pipeline.sh` | Target discovery from DeFiLlama API |
| `audit_gate.sh` | Final judge (compile→test→slither→semgrep→proxy→score→verdict) |
| `confidence_scorer.py` | Auto confidence scoring (HIGH/MED/LOW/NONE) |
| `proxy_checker.py` | ERC1967 proxy analysis (impl/admin/beacon slots) |
| `trace_simulator.py` | Exploit tx trace & root cause analysis |
| `exploit_suite/P_ExploitPatterns.t.sol` | 8 exploit pattern detectors (reentrancy, oracle, flash loan, etc.) |
| `exploit_suite/P_InvariantTemplate.t.sol` | StdInvariant stateful fuzzing template |
| `fetch_source.py` | Fetch source code from BSCScan |
| `bscscan_query.py` | BSCScan API query helper |
| `analyze_contracts.py` | Contract structure analysis |
| `rpc_config.sh` | Multi-RPC fallback configuration |
| `testnet/block_scanner.py` | Scan testnet blocks for active contracts |
| `testnet/contract_analyzer.py` | Analyze contract bytecode, detect proxy/storage |
| `testnet/defi_detector.py` | Detect DeFi vulnerability patterns |
| `testnet/hunt_pipeline.py` | Testnet hunting pipeline (scan→analyze→detect→report) |

## DeFiLlama API Notes

- Chain name for BSC is `"Binance"` NOT `"BSC"` in the API
- Filter: `if p.get('chain') != 'Binance': continue` or `if 'Binance' not in p.get('chains', []): continue`
- Also watch: `'Boba_Bnb'`, `'Op_Bnb'`, `'svmBNB'`
- `address` field format: `"bsc:0x..."` — extract with `addr.split(':')[-1]`
- `tvl` field: list of `{'date': unix_ts, 'totalLiquidityUSD': float}` — get latest with `tvl[-1]['totalLiquidityUSD']`
- `audits` field from DeFiLlama is **unreliable** — do NOT filter by it. Many protocols with real audits show 0 and vice versa. Always verify from protocol docs, Cantina, Immunefi, Code4rena directly. Shadow Exchange is a concrete example: DeFiLlama says NO_AUDIT but actually audited by 6+ firms.
- `chainTvls` field format varies: sometimes a DICT `{chain_name: tvl_value}`, sometimes a LIST of dicts `[{name: chain, tvl: value}]`. Always check `isinstance(ct, dict)` before accessing. WRONG: `for ct in p.get('chainTvls', []): ct.get('name')` — crashes if dict. RIGHT: `ct = p.get('chainTvls', {}); tvl = ct.get('Sonic', 0) if isinstance(ct, dict) else 0`
- **TVL from DeFiLlama ≠ protocol TVL** for tokens (e.g., BTCST shows $950K on DeFiLlama but CoinGecko shows $97M market cap). Verify on-chain for actual TVL-bearing contracts.

## BSCScan API Notes

**See**: `references/bscscan-v2-source-fetching.md` for full details. Summary:

- V2 endpoint: `https://api.etherscan.io/v2/api?chainid=56&apikey=KEY` — NOT `api.bscscan.com` (V1 deprecated)
- `getsourcecode` returns multi-file JSON when source has multiple files: format is `{{ "language": ..., "sources": {...} }}` — strip first+last char, then `json.loads()`
- Multi-file sources: `references/path_file.sol` has underscored paths. Parse JSON, iterate `data['sources'].items()`, save each `['content']` to disk.
- If EIP-1967 impl slot (`0x360894...`) returns `0x0...0` (all zeros) → **NOT a proxy**, the address IS the implementation. Fetch source directly.
- `eth_getCode` (via `eth_getStorageAt` RPC) to distinguish proxy (small code, ~45-100 bytes) from full implementation.
- `getabi` module works reliably for any verified contract.

## Workspace Cleanup Protocol

When user says "hapus hasil X" or "delete results from X", they mean **artifacts produced BY that target** — reports, JSON dumps, screenshots, API swagger files, captcha images, HTML dumps — NOT literally files named "X". Search by target name pattern in filenames (`m-coy99*`, `coy99*`, `captcha*`, etc.) AND by content references.

**Cleanup checklist:**
1. `search_files(pattern='*targetname*', target='files')` — find files by target name
2. `search_files(pattern='targetname', target='content')` — find files referencing target
3. Present file list with sizes to user for confirmation
4. `rm -v` all confirmed files
5. **Clean memory** — remove target-specific entries (API endpoints, merchant IDs, tech stack notes) from memory. Replace with cleaned versions that drop the target reference but keep general tooling knowledge.

**Smart contract targets/ triage (periodic cleanup):**
When targets/ accumulates stale .sol files, categorize them:
- **Empty (0 lines)**: `*_impl.sol` with no content → delete
- **Duplicates**: Same content, different names (e.g., `人生百年.sol` == `RenshiBainian.sol`) → keep one, delete rest
- **JSON wrappers**: .sol files that are actually `{{ "language": "Solidity", "sources": {...} }}` JSON, not real Solidity → delete (re-fetch from explorer if needed)
- **Dead targets**: Old projects (2020-2021), test tokens, abandoned protocols → delete
- **Still valid**: Real source with actual exploit surface → keep

Use `wc -l` + `head -5` on each .sol to quickly triage. Present categorized list to user before deleting.

## Testnet Hunting

Testnets (Sepolia, Base Sepolia, appchains) are the primary playground for learning exploit mechanisms. No real funds at risk, free gas, and active DeFi protocols to study.

### Testnet Tools (`tools/testnet/`)

| Tool | Purpose |
|------|---------|
| `block_scanner.py` | Scan blocks for active contracts, decode selectors, detect patterns |
| `contract_analyzer.py` | Bytecode analysis, proxy detection, storage layout, function extraction |
| `defi_detector.py` | Detect DeFi vulnerability patterns (reentrancy, flash loan, oracle, bridge) |
| `hunt_pipeline.py` | Main pipeline: scan → analyze → detect → report |

### Testnet RPCs (working 2026-06-01)

```bash
SEPOLIA_RPC=https://ethereum-sepolia-rpc.publicnode.com  # Chain ID: 11155111
BASE_SEPOLIA_RPC=https://sepolia.base.org                 # Chain ID: 84532
```

### Quick Hunt

```bash
# Scan Sepolia (5 blocks, top 5 contracts)
python tools/testnet/hunt_pipeline.py -c sepolia -b 5 -n 5

# Analyze specific contract
python tools/testnet/contract_analyzer.py 0xCONTRACT -c sepolia

# Detect vulnerabilities
python tools/testnet/defi_detector.py 0xCONTRACT
```

### Appchain Discovery

Some DeFi protocols run their own EVM appchains (not just smart contracts):
- **Ethereal**: Perpetual futures DEX, Chain ID 5064014 (mainnet) / 13374202 (testnet)
  - Custom sequencer, USDe gas token, Arbitrum settlement, Celestia DA
  - Docs: https://docs.ethereal.trade/
  - **See**: `references/ethereal-protocol.md` for full analysis

When exploring appchains:
1. Check docs for chain config (RPC, explorer, chain ID)
2. Use `cast chain-id --rpc-url <RPC>` to verify connection
3. Look for proxy patterns (EIP-1967) — many appchain contracts are upgradeable
4. Community SDKs (Rust, Go) often reveal contract ABIs and EIP-712 types
5. GitHub org may have private repos — check community repos for ABI leaks

## Support Files
- `references/api-key-management.md` — BSCScan API key convention (env var + file fallback, pre-push checks, leak recovery)

## Common Pitfalls

1. **"DON'T DELEGATE SIMPLE QUESTIONS" (User Correction, 2026-06-05):**
   When user asks a straightforward question like "cari chain baru" or "tools apa yang ready", answer DIRECTLY. Don't spawn delegate_task subagents for simple info-gathering or listing tasks. delegate_task is for complex parallel work (multi-target analysis, deep code review), NOT for answering questions or scanning a single API.
   
   **Rule:** If the task can be answered with 1-3 tool calls (terminal, web_search, read_file), do it inline. Only delegate when work genuinely benefits from parallel isolation (e.g., analyzing 3 contracts simultaneously, each requiring 10+ tool calls).

2. **"PIVOT PARALYSIS" — switching targets too fast (User Correction, 2026-05-31):**
   The user explicitly said: *"mubah analisa dari tadi pivot mulu heran dah"* — frustrated by excessive target switching.
   
   **HARD RULE: Pick ONE target and FINISH it before moving on.**
   - A target is "finished" when: audit_gate.sh returns PASS/CLAIMABLE, or clean FAIL after false-negative check
   - Do NOT present multiple targets to user and ask "which one?" — make a decision yourself
   - If target fails compilation: fix it, don't abandon it for a new one
   - If TVL is 0 or contract is dead: document that, mark as dead target, THEN move on
   - The only exception: target is provably dead AND user explicitly says "skip"
   
   This is a user-facing discipline rule. The user's #1 frustration is wasting time on targets that get rejected after analysis. Don't give them more options — give them completed work.

2. **"Lu terlalu sempit" — single approach trap**: If source verification fails, DO NOT stop. Use MULTIPLE parallel approaches: (a) explorer API proxy → read implementation from events, (b) bytecode selector extraction (extract PUSH4 opcodes from runtime bytecode, test via eth_call), (c) fork testing (`forge test --fork-url` for interface discovery + storage inspection), (d) fork-diff hypothesis (compare selectors against known fork baseline like Liquity or MasterChef), (e) docs/app bundle ABI, (f) decompile as last resort. The anti-blocker-toolkit.md has the canonical order — read it FIRST.
2. **Token contract ≠ TVL-bearing contract**: When you fetch source for a protocol's main address from DeFiLlama, you often get the TOKEN contract (e.g., SBF, SABLE, BTCST), not the vault/staking/CDP engine that actually holds user funds. The token is just the accounting layer. Always look for: `changeFarmContract`, `setPool`, `setVault`, `setStaking`, `setCdpEngine` type functions to find where the real TVL sits. If you only test the token contract, you test nothing economically exploitable.
2. **Source code compilation**: Multi-file sources from BSCScan often have broken import paths. Need to reconstruct directory structure or install real dependencies (OZ, LayerZero).
3. **Slither compilation**: Fails if imports are broken. Fix: install real deps via `forge install` or `git clone` into `lib/`.
4. **Proxy checker false positive**: Empty addresses (no bytecode) look like "UUPS uninitialized" because ERC1967 slots are zero. Always check `code.length > 0` first.
5. **EIP-1967 slot returns 0x0 = NOT a proxy**: If `eth_getStorageAt` for impl slot returns all zeros, the contract is NOT a proxy — it IS the implementation. Fetch source directly.
7. **Diamond facet false positive**: EIP-2535 diamond facets (SYMMIO, etc.) show `init_version=0` and "CONTRACT NOT INITIALIZED - VULNERABLE" because facets are NOT proxies — they're implementation contracts called by the diamond proxy. The proxy_checker.py recommendation "Contract may not be a proxy" is the real signal. If the contract is a diamond facet, this is ALWAYS a false positive.
8. **EIP-2535 `selectorToFacet` optional**: `selectorToFacet(bytes4)` is NOT part of the official EIP-2535 standard — many diamonds implement `facets()` + `facetAddresses()` but not this function. When missing, parse the raw hex return of `facetAddresses()` to extract addresses manually. See `references/symmio-bsc-diamond-case-study.md` for the full SYMMIO investigation methodology including raw hex parsing.
9. **Solidity address checksum compilation failure**: When defining address arrays as Solidity constants in test files, ALL addresses MUST have valid EIP-55 checksums OR compilation FAILS — even when casting through `uint256`. Solidity validates the hex literal before the type conversion. Workaround: retrieve addresses at runtime inside `setUp()` via `facetAddresses()` call, or use `vm.load()` from storage. Never hardcode raw hex address literals in `address[]` arrays in Solidity test files.

   **Forge test address workaround (proven, 2026-05-31):**
   ```solidity
   // WRONG — compilation fails with checksum error
   address constant ORDERBOOK = 0xB6A80EfAAB1d5CC7fC337b9924ef218547F6E9B8;
   address constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
   
   // ALSO WRONG — Solidity validates the literal BEFORE casting
   address constant ORDERBOOK = address(uint160(0xB6A80EfAAB1d5CC7fC337b9924ef218547F6E9B8));
   
   // ALSO WRONG — the literal still has invalid checksum
   address constant ORDERBOOK = address(uint160(80765470696190250357055760300593709272858000640));
   // The uint160 value IS correct but Solidity 0.8.28 validates EIP-55 on the hex form
   
   // CORRECT — compute uint160 value separately, use without hex literal
   address constant ORDERBOOK; // no initializer
   
   function setUp() public {
       ORDERBOOK = address(uint160(1042784150353337158690537566935212775794416216504));
       // Now ORDERBOOK = 0xB6A80EfAAB1d5CC7fC337b9924ef218547F6E9B8 correctly
   }
   
   // Inline assembly with constants: WRONG
   assembly { codeSize := extcodesize(ORDERBOOK) } // Identifier not allowed
   
   // CORRECT: copy to local variable first
   function test_code_size() public {
       address a = ORDERBOOK;
       uint256 codeSize;
       assembly { codeSize := extcodesize(a) }
   }
   ```
   
   **Lesson**: The cleanest pattern for forge fork tests is to initialize address constants inside `setUp()` from numeric uint160 values (computed offline), NOT as Solidity constant declarations with hex literals.
7. **BSCScan multi-file source parsing**: When `getsourcecode` returns `{{"language":"Solidity","sources":{...}}}`, strip first and last character before `json.loads()`. Files are under `data['sources']` as `{path: {"content": ...}}`.
8. **Single EOA admin on upgradeable proxy**: If admin is an EOA (not multisig/timelock), the upgrade function is a single point of failure. This is a finding IF the proxy holds real TVL. Check if upgrade requires timelock or can be called immediately by EOA.

10. **Foundry PoC Compilation Pitfalls (Metropolis session, 2026-06-05):**
    When writing Foundry PoC test contracts for fork tests, these issues cause repeated compilation failures:
    
    a) **Unicode in Solidity strings**: Characters like `→`, `✓`, `✗`, `⚠️` cause `Error (8936): Invalid character in string`. Use ASCII only: `->`, `[OK]`, `[FAIL]`, `[!]`. Even in comments inside `console.log()` strings.
    
    b) **bytes4 to uint256 conversion**: `uint256(selector)` fails with `Explicit type conversion not allowed from "bytes4" to "uint256"`. Fix: `uint256(uint32(selector))` — needs intermediate uint32 cast.
    
    c) **console.log(bytes32)**: `console.log("slot:", slot0)` fails because console.log doesn't have bytes32 overload. Fix: `console.log("slot:", uint256(slot0))`.
    
    d) **MaliciousToken constructor pattern**: When deploying a malicious token for reentrancy PoC, the constructor must take a `_deployer` parameter and set `balanceOf[_deployer] = totalSupply`. If you set `balanceOf[address(this)] = totalSupply`, the tokens are stuck in the token contract and `transfer()` reverts with underflow.
    
    e) **Reentrancy guard detection**: Check storage slot 0 for `_NOT_ENTERED` (value 1) or `_ENTERED` (value 2). If slot 0 = 0, no ReentrancyGuard. Also scan bytecode for PUSH1 0x02 SLOAD pattern.
    
    f) **Flash swap callback**: UniswapV2 pair calls `swap()` on `to` address when `data.length > 0`. The attacker contract must implement `function swap(uint256 amount0Delta, uint256 amount1Delta, bytes calldata data) external` as the callback.

11. **`cast block --json` returns tx hashes, not full objects**: When using `cast block <N> --json`, the `transactions` array contains HASHES (strings), not full transaction objects. To get tx details (to, input, value), you must fetch each hash individually with `cast tx <hash> --json`. This is SLOW for blocks with 100+ txs. Workaround: use `eth_getBlockReceipts` RPC call or filter only the txs you need.

9. **"Search by name" trap (User Correction, 2026-06-01):** When user says "hapus hasil dari slot" or "delete X results", DON'T search for files literally named "X". Understand the CONTEXT — "slot" = gambling site target (e.g., m-coy99.com). Search by the TARGET NAME pattern, not the category word. The user uses Indonesian shorthand: "slot" = slot gambling site, "web slot" = web-based slot platform. Always map domain terms to actual target identifiers before searching.

## Pipeline Diagnostic Protocol

When pipeline returns ALL BLOCKED, run these 7 checks before fixing:

1. **Compilation error log** — grab first 20-40 lines of actual forge build error (not summary)
2. **fetch_source.py output format** — check if multi-file JSON or flattened; verify import paths match file names
3. **foundry.toml existence** — does target have one? If not, clone from MACH_BSC_OrderBookV2 template
4. **Proxy slot verification** — cast storage for impl/admin/init slots, prove values on-chain
5. **BLOCKED step identification** — which audit_gate.sh step exactly (compile/slither/semgrep/test)
6. **Function deep-dive** — for interesting targets, read key functions line-by-line (not just pattern scan)
7. **Baseline target** — find ONE target that compiles end-to-end, clone its config as template

**Working baseline**: `MACH_BSC_OrderBookV2` at `/workspaces/BUG-BOUNTY/targets/MACH_BSC_OrderBookV2/` — has proper `foundry.toml` (solc 0.8.28, OZ remappings), compiles 36 files successfully. Clone its structure for new targets.

## Pipeline Diagnostic Protocol

When pipeline returns ALL BLOCKED, run these 7 checks before fixing:

1. **Compilation error log** — grab first 20-40 lines of actual forge build error (not summary)
2. **fetch_source.py output format** — check if multi-file JSON or flattened; verify import paths match file names
3. **foundry.toml existence** — does target have one? If not, clone from MACH_BSC_OrderBookV2 template
4. **Proxy slot verification** — cast storage for impl/admin/init slots, prove values on-chain
5. **BLOCKED step identification** — which audit_gate.sh step exactly (compile/slither/semgrep/test)
6. **Function deep-dive** — for interesting targets, read key functions line-by-line (not just pattern scan)
7. **Baseline target** — find ONE target that compiles end-to-end, clone its config as template

**Working baseline**: `MACH_BSC_OrderBookV2` at `/workspaces/BUG-BOUNTY/targets/MACH_BSC_OrderBookV2/` — has proper `foundry.toml` (solc 0.8.28, OZ remappings), compiles 36 files successfully. Clone its structure for new targets.

## PoC Project Setup (from Flattened BSCScan Source)

**⚠️ Forge Fork Test Timeout Pattern (CRITICAL):**
When running `forge test --fork-url <RPC>` against BSC or other chains, individual tests take 2-7s each BUT running multiple tests in a suite often times out at 20-30s even with `timeout 30`. Root cause: BSC fork tests require cold RPC call to fetch state on first run, and the Foundry test runner's timeout is per-test, not per-suite.

**Workaround:** Run tests individually with `--match-test <exact_name>`:
```bash
# FAILS (timeout): forge test --match-test test_diamond_check -vvv
# WORKS (2-4s):   timeout 20 forge test --match-test test_diamond_check -vvv
# Pattern: run one test at a time, use timeout wrapper, set timeout >10s
```

**When entire suite times out:** Split into individual test files or run with `--no-match-test` negative patterns. This matters especially for targets that require `vm.createSelectFork(RPC)` setup (which has inherent latency on BSC).

**Bytecode size quick-eval (target triage):**
```python
cast code <addr> --rpc-url <RPC>
# < 200 bytes:  suspicious — too small for real DeFi contract (likely proxy/minimal/placeholder)
# 200-500 bytes: likely proxy (ERC1967Transparent, UUPS, Beacon)
# 1000+ bytes: likely implementation
# 5000+ bytes: full contract (token, factory, vault)
# Example: 185 bytes → contract too small to be SYMMIO real contract (dead address or wrong address)
```
Use this BEFORE deep investigation — saves time on wrong addresses.

```bash
# 1. Create project structure

```bash
# 1. Create project structure
mkdir -p targets/<NAME>_PoC/{src/interfaces,test,lib}

# 2. Copy foundry.toml from working baseline
cp targets/MACH_BSC_OrderBookV2/foundry.toml targets/<NAME>_PoC/

# 3. Install dependencies
cd targets/<NAME>_PoC
forge install foundry-rs/forge-std --no-git
# Clone OZ from baseline
cp -r ../MACH_BSC_OrderBookV2/lib/openzeppelin-contracts lib/

# 4. Copy interfaces from original target
cp ../<TARGET>/src_interfaces_*.sol src/interfaces/
# Rename: src_interfaces_IOptimistic.sol → IOptimistic.sol

# 5. Copy contract source, fix imports:
#    - Remove @openzeppelin → use lib/ path with remapping
#    - Fix double slashes: ./lzApp//lz-evm-oapp-v2 → ./lzApp/lz-evm-oapp-v2
#    - Fix Ownable(): OZ 5.x needs Ownable(owner) not Ownable()

# 6. Compile and fix
forge build  # iterate until clean
```

**Common fixes:**
- `match` is reserved keyword in Solidity 0.8+ → use `matchResult` etc.
- `Ownable()` → `Ownable(owner)` for OZ 5.x
- Mock LZ endpoint needs `setDelegate(address)` function (OApp constructor calls it)
- Use `vm.startPrank(addr) / vm.stopPrank()` not multiple `vm.prank()` for sequential calls

**See**: `references/poc-setup-pattern.md` for full template.

## Workflow After Finding Target

```
./tools/onchain/pipeline.sh <target_name> <proxy_addr>

Jika PASS → forge fork test real → PoC → submit
Jika MEDIUM → build PoC → upgrade ke HIGH
Jika FALSE NEGATIVE → fix tooling → re-run (JANGAN BUANG)
Jika FAIL (clean) → boleh cari target lain
```

**Target selection priority** (multi-chain, $2M-$50M TVL):
1. CDP, Lending, Derivatives, Yield > Dexs, Farm (more complex logic = more attack surface)
2. Fresh deploy < 90d OR old but under-the-radar (not top TVL)
3. Fork of vault/lending/DEX with adapter/strategy/allocator — not bare token
4. Source verified on explorer
5. Avoid: high hype + active bounty + many auditors + easy to fork
6. 0 audits is NOT a reliable filter — use category complexity + TVL + chain instead

**CRITICAL: DeFiLlama audit field is UNRELIABLE.** Concrete example: Shadow Exchange (Sonic) shows `NO_AUDIT` on DeFiLlama for both "Shadow Exchange Legacy" and "Shadow Exchange CLMM" sub-protocols, BUT the protocol is actually audited by **6+ firms** (Spearbit, Cantina, Consensys Diligence, Code4rena competition, 100Proof, Zenith Mitigation, yAudit). Always verify audit status from:
1. Protocol's own docs (e.g., `docs.<protocol>.so/pages/audits`)
2. Cantina/Immunefi/Code4rena/CodeHawk directly
3. GitHub repo (if public — Shadow has NO public GitHub, closed source)

**When DeFiLlama says NO_AUDIT, check anyway. When it says AUDITED, verify the scope.**

**Current target list** (from gpt-codex, see `references/target-candidates-2026-05-31.md`):
- Lendle (Mantle, $552K, Aave-style lending) — highest priority
- Superlend (Etherlink, $604K, Aave-style lending) — high priority
- Orby Network (Cronos, $67K, CDP stablecoin) — liquidation math surface
- CronaSwap (Cronos, $417K, DEX/farm/vault) — MasterChef + vault pattern
- InkySwap (Ink, $507K, token factory) — bonding curve + graduation
- Crodex/EmpireDEX (Cronos, $128K, DEX) — router + LP edge cases

## Exploit Patterns Reference

Full-spectrum patterns — see `references/exploit-patterns.md` for 9 known exploit patterns including P9: Cross-Chain lzCompose Fund Loss (MoneyFi, 2026-05-30).

Pattern classes (all in scope):
- **Access Control**: role mutation affecting user funds, missing onlyOwner, owner too powerful
- **Accounting**: totalSupply/balance mismatch, fee miscalculation, share price manipulation
- **Freeze/Liveness**: withdrawal path revert, queue stuck, adapter revert freezes all users
- **Griefing**: zero penalty/fee DoS, force action loop, front-running withdrawal
- **Theft/Drain**: approved funds steal, reentrancy, flash loan, oracle manipulation, logic bug drain path
- **Logic**: state inconsistency, wrong assumption, overflow/underflow, unchecked return

## Proxy Pattern Reference

See `references/proxy-patterns.md` for known proxy patterns on BSC (LISTA UUPS, PARALLEL proxy, SYMMIO diamond facets, MACH non-proxy) and interpretation guide for proxy_checker.py output.

**IMPORTANT: Before starting ANY target on ANY chain, read `/workspaces/BUG-BOUNTY/anti-blocker-toolkit.md` FIRST.** It has the canonical multi-chain source fetching flow and RPC endpoints. Do not start a new target without it.

**Source fetching details:** See `references/multi-chain-source-fetching.md` — covers Cronos cronos.org/explorer/api, Blockscout v2, Sourcify, fork-diff hypothesis, bytecode selector extraction, and known fork baselines (Liquity for Orby, etc.).

**See also:** `references/on-chain-target-verification.md` — full on-chain verification checklist + MACH case study (TVL=0, no active orders, confirmed dead target, bugs documented via mock PoC).

**See also:** `references/mach-orderbook-analysis.md` — full MACH OrderBook function-by-function analysis, PoC findings, reentrancy note."
**See also**: `references/symmio-bsc-diamond-case-study.md` — SYMMIO BSC Diamond investigation: EIP-2535 loupe functions, raw hex parsing, selector scan, Solidity checksum pitfall, and LIMITED confidence determination without source code.
**See also**: `references/ethereal-protocol.md` — Ethereal Protocol appchain analysis: custom sequencer, EIP-712 signatures, proxy pattern, attack surface.
**See also**: `references/testnet-hunting-patterns.md` — Testnet hunting workflow, function selector quick reference, bytecode triage, DeFi vulnerability patterns.
**See also:** `references/bsc-target-quick-eval.md` — bytecode size triage, chain-specific patterns (LISTA, THENA, MACH, moneyfi), red herrings, and finding status log. Run this BEFORE deep investigation to avoid wasting time on wrong addresses or dead contracts.
**See also:** `references/sonic-chain.md` — Sonic chain reference: Gateway bridge contracts ($2M Immunefi bounty), top DeFi protocols, token addresses, DeFiLlama pool IDs, known exploits. Includes Navigator Exchange investigation (Orderly wrapper, not real target), Shadow Exchange full contract map, and Metropolis Exchange deep dive (reentrancy + price manipulation PoC).

**Heimdall Decompiler** (installed at `~/bin/heimdall` v0.9.2): Use for bytecode decompilation when source unavailable.
```bash
# Install
curl -sL "https://github.com/Jon-Becker/heimdall-rs/releases/download/0.9.3/heimdall-linux-amd64" -o ~/bin/heimdall && chmod +x ~/bin/heimdall

# Decompile bytecode to Solidity
heimdall decompile /tmp/bytecode.hex --output /tmp/decompiled --include-sol

# Key outputs:
# - abi.json — extracted ABI
# - decompiled.sol — human-readable Solidity (may not compile)
```
**Pitfall:** Heimdall decompiled code uses non-standard variable names and confusing control flow. Focus on: (1) require patterns for access control, (2) storage variable writes for state mutation, (3) external calls for reentrancy surface. Don't try to compile the decompiled output — use it for pattern analysis only.

**UniswapV2 Pair Reentrancy Lock Pattern (CRITICAL):**
Standard UniV2 forks use `store_e` (or similar) as a reentrancy lock in the PAIR contract:
```
mint():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
burn():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
swap():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
sync():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
skim():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
```
This means the PAIR contract is reentrancy-protected. However, the ROUTER may NOT have reentrancy protection. The attack vector is: malicious token callback during Router.transferFrom() → re-enter Router (not Pair). This is a rug-pull vector, not a direct drain of existing pools.

**Verification sequence for reentrancy findings:**
1. Check Router storage slot 0 for ReentrancyGuard (value 1 = NOT_ENTERED, 0 = no guard)
2. Decompile Pair contract with Heimdall → grep for `store_e`, `lock`, `require(0x01`
3. If Pair has lock → reentrancy to Pair is DEAD
4. If Router has no lock → check if Router calls transferFrom on user-controlled tokens
5. If yes → malicious token reentrancy is possible (rug-pull vector)
**See also:** `references/protocol-vetting-methodology.md` — 5-minute triage checklist before deep diving any protocol. Detects Orderly/GMX wrappers, checks contract liveness, verifies audit status, assesses attack surface. Decision matrix: 4+ GO factors to proceed.

The reasoning engine framework is defined in `/workspaces/BUG-BOUNTY/guide-tools.md`. Read it for:
- Core Analyzer (solc AST as primary source, not Slither)
- Risk Model (full-spectrum bug classes)
- Sequence Planner (actual contract graph, not hardcoded function names)
- Harness Generator (Foundry tests from model)
- Validation Layer (forge test must pass, confidence scoring)
- Backend Adapters (isolate public tools, degrade gracefully)

The engine must be self-built. Public tools (solc, Slither, Foundry, Medusa, Halmos) are optional backends — the reasoning logic is ours.
