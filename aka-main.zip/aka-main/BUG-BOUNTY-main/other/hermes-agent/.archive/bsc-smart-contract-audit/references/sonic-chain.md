# Sonic Chain — Hunting Reference

## Chain Info

| Key | Value |
|-----|-------|
| Chain ID | 146 |
| RPC | https://rpc.soniclabs.com |
| Explorer | sonicscan.org |
| Token | $S (Sonic) — ~$0.032 (June 2026) |
| Gas Price | ~55 gwei |
| Type | EVM L1 (ex-Fantom) |
| TVL | ~$21.7M (June 2026) |
| Stablecoins | $133.9M (99% USDC) |
| DEX Volume | ~$3.3M/24h |

## Bug Bounty — Sonic Gateway Bridge ($2M Immunefi)

Sonic Labs x Immunefi: $2M bounty on Gateway bridge (Sonic ↔ Ethereum).
Audited by: OpenZeppelin, Quantstamp, Certora.

### Gateway Bridge Contracts (Sonic side)

| Contract | Address |
|----------|---------|
| Bridge (Proxy) | `0x9Ef7629F9B930168b76283AdD7120777b3c895b3` |
| Bridge Impl | `0x0B3fe0c10C050270a9bc34271987989B6CF2107C` |
| StateOracle | `0x836664B0c0CB29B7877bCcF94159CC996528F2C3` |
| ValidatorsRegistry | `0x12727D4169a42A9b5E3ECB11A6d2c95553d3f447` |
| MessageBus | `0xB5B371B75f9850dDD6CCB6C436DB54972a925308` |
| TokenPairs (Proxy) | `0x134E4c207aD5A13549DE1eBF8D43c1f49b00ba94` |
| TokenPairs Impl | `0xE34e6851a4a3763e1d27aa7ac5980d2D33C2d315` |
| MPTProofVerifier | `0xD2f1e904dAf7446686F8057b7dfeb068c75D29A9` |
| UpdateManager (Proxy) | `0x1D3c99DA3CEF5C26f02a86dC7D685efa40176bb7` |
| UpdateManager Impl | `0x1071405A4736535C545580064039A235827ee6D4` |

### Core Tokens

| Token | Address |
|-------|---------|
| Wrapped S (wS) | `0x039e2fB66102314Ce7b64Ce5Ce3E5183bc94aD38` |
| WETH | `0x50c42dEAcD8Fc9773493ED674b675bE577f2634b` |
| USDC | `0x29219dd400f2Bf60E5a23d13Be72B486D4038894` |
| USDT | `0x6047828dc181963ba44974801ff68e538da5eaf9` |
| SFC | `0xFC00FACE00000000000000000000000000000000` |

## Top DeFi Protocols (DeFiLlama, June 2026)

| Protocol | Category | TVL | Audit Status |
|----------|----------|-----|-------------|
| Aave V3 | Lending | $8.11M | Audited |
| Beets LST | Liquid Staking | $3.83M | Audited |
| Shadow Exchange Legacy | DEX | $2.28M | Audited (6+ firms) |
| Shadow Exchange CLMM | DEX | $1.71M | Audited (6+ firms) |
| Silo V2 | Lending | $2.31M | Audited |
| Metropolis DLMM | DEX | $390K | **NO AUDIT** |
| Metropolis DLMM Vaults | Liquidity Mgr | $270K | **NO AUDIT** |
| Navigator | Derivatives | $640K | **NO AUDIT** (wrapper) |
| Beets DEX V3 | DEX | $1.02M | **NO AUDIT** |
| DeFive | DEX | $150K | **NO AUDIT** |
| dTRINITY dUSD | Stablecoin | $230K | **NO AUDIT** |
| dTRINITY dLEND | Lending | $180K | **NO AUDIT** |
| Angles Stake | Liquid Staking | $700K | **NO AUDIT** |

## Shadow Exchange — Full Contract Map

**CRITICAL:** DeFiLlama shows NO_AUDIT but IS audited by 6+ firms (Spearbit, Cantina, Consensys, Code4rena, 100Proof, Zenith, yAudit). Based on Ramses V3 Core (UniV3 fork). CLOSED SOURCE.

### Core Contracts
Shadow Token `0x3333b97138D4b086720b5aE8A7844b1345a33333` | xShadow `0x5050bc082FF4A74Fb6B0B04385dEfdDB114b2424` | Shadow LST `0x3333111A391cC08fa51353E9195526A70b333333` | Wrapped Gems `0x5555b2733602DEd58D47b8D3D989E631CBee5555` | ProxyAdmin `0x0E03b0A37B1C5c1D9800B758Ccb5b8E229690Dcf` | Deployer `0x07712D748c40608810A0305751E35f0EeDEF70d2` | GaugeFactory `0x8CF82D413cA20a40a2Fa43C2bF77D136d81299e9` | PairFactory `0x2dA25E7446A70D7be65fd4c053948BEcAA6374c8` | Router `0x1D368773735ee1E678950B7A97bcA2CafB330CDc` | Voter `0x9f59398d0a397b2eeb8a6123a6c7295cb0b0062d` | Minter `0xc7022F359cD1bDa8aB8a19d1F19d769cbf7F3765` | Autovault `0x1a99E55A2F6ae7d64bcfeDE80837b5884b1B1D74`

### Access Control
Multisig `0x5Be2e859D0c2453C9aA062860cA27711ff553432` | Timelock `0x4577D5d9687Ee4413Fc0c391b85861F0a383Df50` | AccessHub `0x5e7A9eea6988063A4dBb9CcDDB3E04C923E8E37f`

### CL (V3)
Factory `0xcD2d0637c94fe77C2896BbCBB174cefFb08DE6d7` | PoolDeployer `0x8BBDc15759a8eCf99A92E004E0C64ea9A5142d59` | NFPositionMgr `0xA57FA38b3fd45922394e9E1077748A2383F1542E` | NFPositionMgr NEW `0x12E66C8F215DdD5d48d150c8f46aD0c6fB0F4406` | UniversalRouter `0x92643Dc4F75C374b689774160CDea09A0704a9c2` | SwapRouter `0x5543c6176feb9b4b179078205d7c29eea2e2d695` | QuoterV2 `0x219b7ADebc0935a3eC889a148c6924D51A07535A` | FeeCollector `0xcc0365F8f453C55EA7471C9F89767928c8f8d27F`

## Metropolis Exchange — Deep Dive (June 2026)

**Type:** DLMM DEX (Liquidity Book / Joe V2.2 fork). NO AUDIT.
**TVL:** $660K (DLMM: $390K + AMM: $270K)
**Source:** CLOSED SOURCE
**PoC Status:** REENTRANCY CONFIRMED, PRICE MANIPULATION CONFIRMED

### Contract Addresses

| Contract | Address | Size |
|----------|---------|------|
| Router | `0x95a7e403d7cF20F675fF9273D66e94d35ba49fA3` | 36KB |
| AMM Factory | `0x1570300e9cFEC66c9Fb0C8bc14366C86EB170Ad0` | 24KB |
| DLMM Factory | `0x39D966c1BaFe7D3F1F53dA4845805E15f7D6EE43` | 24KB |
| METRO Token | `0xe878A02eA8a286b4d714ffBCF8eC39C1a5f49464` | - |
| Owner | `0xd1f2823f3aBF4b8c7Ad1B6629421b2618a5e28aF` | - |
| WETH/USDC Pool | `0x2Ca54f3FF85599dfF6aDB0B6D8688077a7E7C8df` | - |

### Key Findings (PoC Verified)

1. **NO REENTRANCY GUARD on Router** — Confirmed via:
   - Storage slot 0 = 0 (no _NOT_ENTERED check)
   - Bytecode pattern scan: no PUSH1 0x02 SLOAD pattern
   - PoC: MaliciousToken.transferFrom callback triggers during Router.addLiquidity()
   - Attack count = 1 (reentrancy fires)

2. **116 POOLS VULNERABLE TO PRICE MANIPULATION** — Confirmed via Foundry fork test:
   - Scanned 200 of 1,078 AMM pairs
   - 116 pools have WETH reserve < 10 WETH
   - Many pools have < 0.01 WETH (trivial to drain)
   - WETH/USDC pool: 166.6 wS + 5.3 USDC (price: 31,842 USDC/WETH — should be ~1,675)

3. **AMM Factory uses `allPairsLength()` NOT `allPoolsLength()`** — CRITICAL interface difference

### Reentrancy Exploit Path (CONFIRMED — with caveats)

**Router has NO reentrancy guard** — Confirmed via:
- Storage slot 0 = 0 (no _NOT_ENTERED check)
- Bytecode pattern scan: no PUSH1 0x02 SLOAD pattern
- PoC: MaliciousToken.transferFrom callback triggers during Router.addLiquidity()
- Attack count = 1 (reentrancy fires)

**BUT: Pair contract HAS reentrancy lock** — Confirmed via Heimdall decompilation:
```
Pair store_e pattern (standard UniV2 lock):
  mint():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
  burn():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
  swap():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
  sync():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
  skim():  require(0x01 == store_e); store_e = 0; ... store_e = 0x01;
```
This means direct reentrancy INTO the Pair is DEAD. The only attack path is re-entering the ROUTER via malicious token callback, which is a rug-pull vector (attacker must deploy own token), not a direct drain of existing pools.

```
Attack flow (malicious token rug):
1. Deploy MaliciousToken with callback on transferFrom()
2. Create MAL/WETH pair via Factory
3. Add liquidity (MAL + WETH)
4. Victim swaps WETH -> MAL via Router
5. Router.addLiquidity() -> calls transferFrom(MAL) -> callback fires
6. Callback re-enters Router -> drain pool
```

**Limitation:** Requires malicious token. Standard tokens (WETH, USDC) don't have callbacks. But 1,078 pools = many use custom tokens that COULD have malicious transfer().

### Price Manipulation Exploit (CONFIRMED)

```
Pool: 0x2Ca54f3FF85599dfF6aDB0B6D8688077a7E7C8df (wS/USDC)
Reserves: 166.6 wS + 5.3 USDC
Price: 31,842 USDC per WETH (inflated 19x)

Direct pair swap (bypass Router):
1. Transfer WETH to pair
2. Call pair.swap() with data="" (no flash callback)
3. Receive USDC at manipulated price
4. Sell USDC back -> profit from price swing
```

### PoC Project
Location: `/workspaces/BUG-BOUNTY/WEB3/metropolis-flash/`
- `src/MetropolisAttack.sol` — Attack contract interfaces
- `test/ReentrancyAttack.t.sol` — Reentrancy guard detection + flash swap tests
- `test/MaliciousTokenExploit.t.sol` — Full reentrancy exploit with malicious token
- `test/PriceManipulation.t.sol` — Pool scanning + price manipulation + sandwich attack
- `test/MetropolisFlash.t.sol` — Pool enumeration + oracle manipulation
- `foundry.toml` — via_ir=true (needed for stack-too-deep in complex tests)

### 10-Issue Fix Methodology (Applied to PriceManipulation.t.sol)
When user identifies code issues in PoC tests, fix ALL of them systematically:
1. try/catch all external calls (getAmountsOut, swap, etc.)
2. Check pair != address(0) before accessing token0/getReserves
3. Check transfer return values with require(ok)
4. Guard against zero reserves and zero amounts
5. Cap amounts to available balance
6. Use separate victim address (makeAddr) for sandwich tests
7. Snapshot-based profit calculation (not hardcoded)
8. Decimal-normalized price output
9. Safe helper functions (_safeToken0, _safeGetReserves, _safeDecimals)
10. via_ir=true for stack-too-deep in complex test functions

### Factory Interface (AMM)
```solidity
function allPairsLength() external view returns (uint256);  // NOT allPoolsLength!
function allPairs(uint256) external view returns (address);  // NOT allPools!
```

### DLMM Factory Interface
```solidity
function getNumberOfLBPairs() external view returns (uint256);
function getLBPairInformation(address, address) external view returns (address, bool, uint16);
// NOTE: getLBPairInformation only on DLMM factory, NOT AMM factory
```

### LBPair Interface (flash loan support)
```solidity
function flashLoan(address, uint256, uint256, bytes calldata) external;
function getActiveId() external view returns (uint24);
function getBin(uint24) external view returns (uint256, uint256);
```

## Navigator Exchange — Investigation Results (June 2026)

**VERDICT: NOT A REAL TARGET.** Frontend wrapper for Orderly Network.

- Trading via Orderly Network (https://api.orderly.org), NOT on-chain
- Broker ID: "navigator"
- On-chain contracts nearly empty (0 balance)
- Firebase (navigator-55de8) = analytics only
- Detection: NLP + esNAVI + Multiplier Points = GMX/Orderly fork pattern
- Navigator API (api.navigator.exchange) leaks public data only

## Known Exploits
- **CrediX Finance** (Aug 2025): $4.5M exploit on Sonic

## Hunting Notes
- DeFiLlama audit field UNRELIABLE — always verify from protocol docs
- Closed-source protocols common — use bytecode selector extraction + fork-diff
- TVL ~$21.7M total — smaller protocols = less audit coverage
- Most protocols new (post-Fantom migration) — less battle-tested
- **Metropolis = best unaudited target** — DLMM math + no reentrancy guard + 1,078 pools
- Liquidity Book (Joe V2.2 fork) has flash loan support in LBPair contracts
- AMM Factory uses `allPairsLength()` NOT `allPoolsLength()` — different from standard UniV2
