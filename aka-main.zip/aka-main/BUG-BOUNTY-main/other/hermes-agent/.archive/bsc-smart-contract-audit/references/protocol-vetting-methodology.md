# Protocol Vetting — Quick Triage Before Deep Dive

Save time by vetting protocols BEFORE spending 30+ minutes on deep analysis.

## 5-Minute Triage Checklist

### Step 1: Is it a real on-chain protocol? (30 seconds)

**Check if protocol is just a frontend wrapper:**
- Orderly Network wrappers: look for NLP/esToken/Multiplier Points patterns (GMX-style)
- dYdX forks: look for "vault", "cross margin", "isolated margin"
- GMX forks: look for "GLP", "esGMX", "multiplier points", "keeper"

**Detection in JS bundle:**
```bash
curl -s "https://app.PROTOCOL.exchange/static/js/main.*.js" > /tmp/proto.js
grep -oE 'ORDERLY|orderly|GMX|gmx|dYdX|dydx' /tmp/proto.js | head -5
grep -oE 'Vault:"0x[0-9a-fA-F]{40}' /tmp/proto.js | head -10
```

**If Orderly/dYdX wrapper → SKIP.** Attack surface is the underlying protocol, not the frontend.

### Step 2: Are on-chain contracts alive? (1 minute)

```bash
export PATH="$HOME/.foundry/bin:$PATH"
RPC="<chain_rpc>"

# Check each contract
for addr in <addresses>; do
  size=$(cast code --rpc-url "$RPC" "$addr" | wc -c)
  if [ "$size" -gt 3 ]; then
    echo "✓ $addr ($size chars)"
  else
    echo "✗ $addr (EMPTY)"
  fi
done

# Check vault/token balances
cast call --rpc-url "$RPC" "<USDC_addr>" "balanceOf(address)(uint256)" "<vault_addr>"
```

**If vault balance = 0 and most contracts empty → SKIP.** Protocol is dead or funds elsewhere.

### Step 3: Is it really unaudited? (2 minutes)

**DeFiLlama audit field is UNRELIABLE.** Always verify:

1. Check protocol docs: `docs.PROTOCOL.so/pages/audits` or `docs.PROTOCOL.exchange/security`
2. Search Cantina: `cantina.xyz/portfolio?q=PROTOCOL`
3. Search Immunefi: `immunefi.com/bug-bounty/PROTOCOL`
4. Search Code4rena: `code4rena.com/reports?q=PROTOCOL`
5. Check GitHub for audit reports in repo

**If audited by 3+ firms → SKIP** (unless you find something auditors missed).

### Step 4: Is there real attack surface? (1 minute)

**High attack surface indicators:**
- Custom math (concentrated liquidity, bonding curves, CDP liquidation)
- Oracle dependency (Chainlink, TWAP, custom)
- Flash loan enabled
- Cross-chain messaging
- Complex tokenomics (rebase, vesting, escrow)
- Proxy pattern (upgradeable = more surface)

**Low attack surface indicators:**
- Simple token swap (UniV2 fork)
- Standard staking (MasterChef fork)
- Wrapper/staking only (ERC4626 vault)
- Frontend for Orderly/dYdX/GMX

### Step 5: Source code available? (30 seconds)

```bash
# Check if contracts verified on explorer
# Try Sourcify: https://sourcify.dev/server/v2/contract/<CHAIN_ID>/<ADDRESS>
# Try explorer API: getsourcecode endpoint
```

**If closed source + audited → SKIP.** Can't find bugs without source.

## Decision Matrix

| Factor | GO | SKIP |
|--------|-----|------|
| On-chain contracts | Active, funded | Empty, dead |
| Audit status | 0-1 audits | 3+ audits |
| Source code | Verified/public | Closed source |
| Attack surface | Complex math, oracle, cross-chain | Simple swap, staking |
| Protocol type | Native on-chain | Wrapper (Orderly/GMX) |
| TVL | $100K-$50M | >$50M (too many eyes) |
| Chain | Under-hunted (Sonic, Ink, Mantle) | Crowded (Ethereum, Base top) |

**Rule: Must have 4+ GO factors to proceed with deep dive.**

## Protocol Type Detection

### Orderly Network Wrapper
Signs: "NLP", "esNAVI/esGMX", "multiplier points", "keeper", "vault deposit", ORDERLY_MAINNET in JS
Example: Navigator Exchange (Sonic)
Verdict: SKIP — trading via Orderly, not on-chain

### GMX Fork
Signs: GLP, esGMX, multiplier points, Vault.sol, Router.sol, PositionRouter.sol
Attack surface: Oracle manipulation, liquidation logic, fee calculation
Note: Many GMX forks on smaller chains — check if customized

### Uniswap V2 Fork
Signs: Factory, Router, WETH pair, getAmountOut
Attack surface: Minimal (well-audited base)
Note: Only interesting if has custom fee/staking logic

### Uniswap V3 / CLMM Fork
Signs: NonfungiblePositionManager, concentrated liquidity, tick math
Attack surface: Tick math overflow, oracle TWAP, fee calculation
Note: Shadow Exchange = Ramses V3 = UniV3 fork with custom fees

### Liquidity Book / DLMM Fork (Joe V2.2 / Trader Joe)
Signs: LBPair, bin-based pricing, `getActiveId()`, `getBin()`, `flashLoan()` on pair
Factory: `allPairsLength()` (AMM) + `getNumberOfLBPairs()` (DLMM) — two separate factories
Attack surface: Bin math overflow, flash loan via pair.swap(data>0), oracle manipulation via bin pricing
Note: Metropolis (Sonic) = Joe V2.2 fork — confirmed no ReentrancyGuard on Router
Key pitfall: AMM Factory uses `allPairsLength()` NOT `allPoolsLength()` — different from standard UniV2

### Aave V3 Fork
Signes: Pool, PoolProvider, aToken, variable/stable rate
Attack surface: Liquidation logic, oracle, interest rate model
Note: Many forks on L2s — check if customized

### Balancer V2/V3 Fork
Signs: Vault, weighted pools, stable pools, flash loans
Attack surface: Weighted math, stable math, flash loan composability
Note: Beets (Sonic) = Balancer fork

### CDP / Stablecoin
Signs: Collateral, mint, redeem, liquidation, oracle
Attack surface: Liquidation math, oracle manipulation, peg mechanism
Note: dTRINITY (Sonic) = algorithmic stablecoin — HIGH attack surface

## DeFiLlama API Pitfall

`chainTvls` field is a DICT, not a list:
```python
# WRONG
for ct in p.get('chainTvls', []):
    if ct.get('name') == 'Sonic':  # TypeError if ct is str

# RIGHT
ct = p.get('chainTvls', {})
tvl = ct.get('Sonic', 0) if isinstance(ct, dict) else 0
```

When `chainTvls` is a list of dicts (older format):
```python
for ct in p.get('chainTvls', []):
    if isinstance(ct, dict) and ct.get('name') == 'Sonic':
        tvl = ct.get('tvl', 0)
```

Always check type before iterating.
