# Embedded Git Repository Fix

When a subdirectory has its own `.git/` directory (e.g. a cloned tool like sqlmap-dev), `git add` treats it as a **submodule** (gitlink mode 160000) instead of adding the actual files.

## Symptoms

```bash
# Warning when adding:
warning: adding embedded git repository: subdir/tool
hint: You've added another git repository inside your current repository.

# Only 1 file tracked:
git diff --cached --stat
# subdir/tool | 1 +    ← WRONG, should show all files

# Mode 160000 (submodule):
git ls-files --stage subdir/tool
# 160000 <hash> 0  subdir/tool
```

## Fix

```bash
# 1. Remove the .git directory from the subdirectory
rm -rf subdir/tool/.git

# 2. Force remove the gitlink from the index
git rm --cached -f subdir/tool

# 3. Re-add as regular files
git add subdir/tool/

# 4. Verify — should show many files, mode 100644
git diff --cached --stat | grep subdir/tool | wc -l
git ls-files --stage subdir/tool | head -3
```

## Why this happens

Git has a heuristic: if a directory being added contains a `.git/` directory, it assumes you want a submodule reference (gitlink). This is correct for intentional submodules but wrong when you just want to include a vendored/cloned tool's source code.

## Alternative: Keep as submodule

If you want to track the tool as a proper submodule:

```bash
git submodule add https://github.com/user/tool.git subdir/tool
git submodule update --init
```

This creates `.gitmodules` and tracks only the commit hash, not the files.
