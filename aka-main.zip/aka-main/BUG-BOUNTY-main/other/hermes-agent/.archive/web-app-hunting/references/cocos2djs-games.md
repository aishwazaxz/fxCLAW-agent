# Cocos2d-JS Game Exploitation

Patterns for reversing and exploiting mobile games built with Cocos2d-JS engine.

## Fingerprint

- `libcocos2djs.so` in APK lib/ (20-30MB typical)
- `assets/project.json` — game config (jsList, modules, configUrl)
- `assets/project_common.json` — slot/game definitions
- `assets/main.js` — entry point
- `assets/script/` — Cocos2d engine JS files
- Multiple DEX files (classes.dex through classesN.dex)

## Key Files to Extract

1. **Remote config URL** — in `project.json` → `configUrl` field
2. **Game server** — from remote config JSON → `GATE_HOST`, `GATE_PORT`
3. **CDN URLs** — `ASSET_BASE_URL`, `SCRIPT_BASEURL`
4. **SDK config** — `assets/res/sdkbox_config.json` (Facebook ID, IAP items)
5. **BuildConfig.java** — Google Client ID, build flavor, version

## Remote Config Pattern

```
GET {configUrl}
Returns JSON:
{
  "GATE_HOST": "gate.example.com",
  "GATE_PORT": 20002,
  "ASSET_BASE_URL": "https://cdn.example.com/assets",
  "SCRIPT_BASEURL": "https://cdn.example.com/scripts",
  "STAGE": "stage1",
  "FB_ID": "123456789",
  "versionID": "260601072750"
}
```

## Protocol Analysis

Cocos2d-JS games typically use one of:
1. **Pomelo framework** — HTTP gate API + WebSocket game server (most common for Cocos2d-JS)
2. **Socket.IO** — look for `SocketIO` in SO strings
3. **Raw WebSocket** — `WebSocket` class in SO
4. **HTTP polling** — less common for real-time games

### Pomelo Framework (HTTP Gate + WebSocket)
Many Cocos2d-JS games use the Pomelo game server framework (by NetEase). The gate server exposes an HTTP API on port 443:

```python
import socket, ssl, json

def pomelo_gate(host, route, data, port=443):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(10)
    ss = ctx.wrap_socket(s, server_hostname=host)
    ss.connect((host, port))
    body = json.dumps(data)
    req = (f'POST /{route}?id=0&passport=GAMENAME HTTP/1.1\r\n'
           f'Host: {host}\r\n'
           f'Content-Type: text/plain\r\n'  # MUST be text/plain
           f'Content-Length: {len(body)}\r\n'
           f'Connection: close\r\n\r\n{body}')
    ss.send(req.encode())
    resp = b''
    while True:
        try:
            chunk = ss.recv(4096)
            if not chunk: break
            resp += chunk
        except: break
    ss.close()
    parts = resp.decode().split('\r\n\r\n', 1)
    return json.loads(parts[1]) if len(parts) > 1 else resp.decode()

# Health check (no auth)
r = pomelo_gate('gate.game.com', 'gate.gateHandler.checkVersion', {
    'version': 114,  # CONFIG.VERSION (integer), NOT versionID
    'assetVersion': 312, 'stage': 'stage1', 'groupID': 'default'
})
```

**Detection:** Look for `pomelo`, `gate.gateHandler`, `connector.entryHandler` in compiled JS.
**Key:** Port 443 works when 20002 is firewalled. Content-Type must be `text/plain`.
**Routes:** `gate.gateHandler.checkVersion` (no auth), `queryEntry` (needs FB signed_request), `loggedInAsGuest` (needs existing UID), `newMobileLoginReq` (needs FB token).

### Game Logic in compiled_canvas.js
The compiled game JS (at `SCRIPT_BASEURL/compiled_canvas.js`) can be 5-10MB and contains ALL Pomelo routes and game logic. Download and grep for routes:
```bash
curl -s "$SCRIPT_BASEURL/compiled_canvas.js" -o compiled.js
grep -oP '[a-z]+\.[a-zA-Z]+Handler\.[a-zA-Z]+' compiled.js | sort -u
```

Connection flow:
```
1. OAuth login (FB/Google/Apple) → get auth token
2. Load remote config → get GATE_HOST:GATE_PORT
3. Connect WebSocket/Socket.IO to game server
4. Send auth message with token
5. Game protocol messages (JSON or binary)
```

## String Extraction from SO

```bash
strings libcocos2djs.so | grep -iE "(login|auth|token|coin|balance|spin|slot|bet|win|jackpot)"
strings libcocos2djs.so | grep -iE "(SocketIO|WebSocket|socket\.connect)"
strings libcocos2djs.so | grep -iE "https?://"
strings libcocos2djs.so | grep -iE "(AES|encrypt|decrypt|cipher|hmac)"
```

## Server Fingerprinting

Game servers often run Express.js (Node.js). Check:
```bash
# WSS handshake reveals x-powered-by header
curl -kI https://gate.example.com:20002/
# Look for: x-powered-by: Express
```

Error pages may leak server paths:
```
Error: Not Found at /home/ubuntu/app/app.js:422:15
```

## Common Attack Vectors

1. **Remote config manipulation** — if configUrl is HTTP, MITM to redirect GATE_HOST
2. **CDN asset tampering** — if CDN allows PUT, inject malicious JS
3. **OAuth token theft** — CSP unsafe-eval + XSS → steal FB/Google token
4. **IAP receipt forgery** — fake Google Play receipts sent to game server
5. **Protocol manipulation** — intercept WebSocket, modify coin/bet messages
6. **Device ID spoofing** — predictable MD5(android_id) for multi-account

## PITFALLS

- JS source files listed in project.json are NOT in APK — compiled into libcocos2djs.so
- CDN scripts often return 403 (Access Denied) — need valid session
- Game server port may accept TCP but reject HTTP/WebSocket without proper auth
- Socket.IO EIO version matters — try EIO=2,3,4
- `project.json` configUrl is the PRIMARY target — it reveals everything
- WSS (port 443) often works when WS (port 20002) drops connections
- **compiled_canvas.js is downloadable from CDN** — even when individual asset files return AccessDenied, the game logic JS at `SCRIPT_BASEURL/compiled_canvas.js` is often publicly accessible. This is the #1 source for route enumeration.
- **CONFIG.VERSION ≠ versionID** — `CONFIG.VERSION` (integer, e.g. 114) is the game version used in gate auth. `versionID` (string, e.g. "260601072750") is a build timestamp. Sending versionID as version fails with "version incorrect".
