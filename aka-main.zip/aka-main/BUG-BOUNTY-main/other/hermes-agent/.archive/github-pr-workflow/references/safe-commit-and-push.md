# Safe Commit & Push — Exclude Secrets, Scan Before Push

When the user says "commit everything" or "push all changes", always run this
checklist BEFORE staging. The goal: push code, never secrets.

---

## 1. Fix .gitignore Before Staging

Common mistake: root-only patterns don't match nested directories.

```gitignore
# WRONG — only matches at repo root
cache/
out/
artifacts/

# RIGHT — matches at any depth
**/cache/
**/out/
**/artifacts/
```

### Standard sensitive-file block (add to every .gitignore)

```gitignore
# Secrets
.env
.env.*
*.key
*.pem
*.p12
*.pfx
**/.env
**/.env.*
**/hydra.restore
*.sql
*.dump
```

### Check if .gitignore already covers what you need

```bash
# See what's currently ignored
git status --ignored --short | head -30

# See what WOULD be staged (dry run)
git add -A --dry-run 2>&1 | head -40
```

---

## 2. Scan for Secrets in Staged Files

Run this BEFORE `git commit`. Catches API keys, private keys, tokens.

```bash
# Common secret patterns
git diff --cached --name-only | xargs grep -lE \
  "(sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{36}|AKIA[A-Z0-9]{16}|-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY)" \
  2>/dev/null

# Service-specific keys
git diff --cached --name-only | xargs grep -lE \
  "(FIRECRAWL_API_KEY|EXA_API_KEY|INFURA_API_KEY|PRIVATE_KEY=|MNEMONIC=|SECRET_KEY=|AWS_SECRET)" \
  2>/dev/null

# If either returns files → DO NOT commit. Fix .gitignore or remove from staging.
```

### Quick patterns to grep for

| Pattern | What it catches |
|---------|----------------|
| `sk-[a-zA-Z0-9]{20,}` | OpenAI / Stripe API keys |
| `ghp_[a-zA-Z0-9]{36}` | GitHub personal access tokens |
| `AKIA[A-Z0-9]{16}` | AWS access key IDs |
| `-----BEGIN.*PRIVATE KEY` | PEM private keys |
| `PRIVATE_KEY=`, `MNEMONIC=` | .env-style secrets |
| `Bearer [a-zA-Z0-9_-]{20,}` | Auth bearer tokens |
| `0x[a-fA-F0-9]{64}` | Possible Ethereum private keys (context matters — addresses are 40 hex) |

---

## 3. Check Tracked Files for Secrets

Even if .gitignore is correct now, old commits may have tracked sensitive files:

```bash
# Check if any sensitive files are already tracked
git ls-files | grep -E "\.env$|\.key$|\.pem$|hydra|secret|token" 2>/dev/null

# If found, untrack them (keeps local file):
git rm --cached <file>
```

---

## 4. Stage and Commit

```bash
# Stage everything (respects .gitignore)
git add -A

# Review what's staged
git status --short
git diff --cached --stat

# Commit
git commit -m "feat: <description>"

# Push
git push origin main
```

---

## Pitfalls

1. **Root-only patterns**: `out/` only matches `./out/`, not `WEB3/project/out/`. Always use `**/` prefix for build artifacts.

2. **grep xargs on empty**: `git diff --cached --name-only | xargs grep` returns exit 123 when no files match — that's NORMAL, not an error. Exit code 0 means secrets WERE found.

3. **forge-std lib/**: Foundry projects include `lib/forge-std/` (~1.3MB). This is fine to commit — it makes PoCs reproducible. BUT `out/` and `cache/` are build artifacts, always exclude.

4. **Decompiled .hex files**: These may contain ABI references that match "PRIVATE_KEY" patterns in function signatures, not actual keys. Inspect context before panicking.

5. **.env.example is safe**: Template files with placeholder values (`.env.example`, `.env.sample`) are safe to commit. Only actual `.env` with real values is dangerous.
