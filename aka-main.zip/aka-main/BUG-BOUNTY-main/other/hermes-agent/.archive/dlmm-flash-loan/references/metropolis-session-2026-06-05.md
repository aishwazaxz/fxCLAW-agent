# Metropolis Exchange — DLMM Flash Loan Session (5 Juni 2026)

## Contracts
- DLMM Factory: 0x39D966c1BaFe7D3F1F53dA4845805E15f7D6EE43
- LB Pair Implementation: 0xed06734629e22277D395d8EB8b67Cc75c27Cb6A2 (49KB)
- AMM Router: 0x95a7e403d7cF20F675fF9273D66e94d35ba49fA3
- AMM Factory: 0x1570300e9cFEC66c9Fb0C8bc14366C86EB170Ad0
- Owner: 0xd1f2823f3aBF4b8c7Ad1B6629421b2618a5e28aF

## LB Pairs with WETH
| Index | Address | WETH | Token0 |
|-------|---------|------|--------|
| 7 | 0x29ED80C7Cf29F50Dd0419d53821b06cE4F4EAce2 | 3.6 WETH | toona (0xf4F9...fee-on-transfer) |
| 15 | 0x36c48f5E423748E9fFe958befBa6822451c87E4e | 1.67 WETH | Familio (0xBe42...normal ERC20) |
| 16 | 0x634D830B4434b01862B787Ce4b2111fCC2dd75A2 | 3.63 WETH | 0x39fd... (dead contract) |

## Cross-DEX Price (PAIR15 Familio/WETH)
- AMM price: 0.000152 WETH/F (pool: 0xF92008d856279470A3c9C3ef24aC44D9Bd8b4C52)
- LB price: 0.000138 WETH/F (active bin 8387715)
- Spread: 10.5% (AMM more expensive)
- NOT a vuln — cross-DEX arb is normal market behavior

## What Works
- Flash loan: borrow WETH from LB pair, 0.0005% fee ✅
- Callback fires with selector 0x1faa6b87 ✅
- Return value 0xab5c473b... passes check ✅

## What Doesn't Work
- LB swap(bool,address) via proxy — reverts without error
- Cross-pair arb — F only traded on 1 AMM pair
- Hooks — all pairs return empty hooks config

## Next Targets
1. Composition fee bug (TJ LB v2.0 historical)
2. Oracle TWAP manipulation
3. Hook re-entry (if hooks found on other pairs)
4. Active bin drain via volatility accumulator
