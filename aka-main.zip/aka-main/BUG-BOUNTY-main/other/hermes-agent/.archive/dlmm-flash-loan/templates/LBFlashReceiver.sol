// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

// WORKING DLMM Flash Loan Receiver
// Tested on Metropolis Exchange (Sonic chain)
// Key: return value MUST be CALLBACK_SUCCESS or pair reverts with "JW"

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
}

contract LBFlashReceiver {
    address public owner;
    address public weth;
    uint256 public callbackCount;
    bool public repaySuccess;
    uint256 public flashFee;

    bytes32 constant CALLBACK_SUCCESS = 0xab5c473bce5960a8292e9c8db82f9272504caab4e9ef09553fc112f82b62a3c2;

    constructor(address _weth) {
        owner = msg.sender;
        weth = _weth;
    }

    receive() external payable {}

    /// @notice Execute flash loan on DLMM LB pair
    /// @param pair LB pair address
    /// @param amount0 Amount of token0 to borrow (token1 = 0)
    function doFlashLoan(address pair, uint256 amount0) external {
        require(msg.sender == owner, "not owner");
        // Encode: amount0 in high 128 bits, amount1=0 in low 128 bits
        bytes32 amounts = bytes32(uint256(amount0) << 128);
        bytes memory emptyData;
        (bool ok,) = pair.call(
            abi.encodeWithSignature("flashLoan(address,bytes32,bytes)", address(this), amounts, emptyData)
        );
        require(ok, "Flash loan failed");
    }

    /// @notice Callback from LB pair during flash loan
    /// Selector: 0x1faa6b87
    /// MUST return abi.encode(CALLBACK_SUCCESS) or pair reverts
    fallback(bytes calldata) external returns (bytes memory) {
        callbackCount++;

        // Decode calldata via assembly (abi.decode does NOT work here)
        // Layout: selector(4) + sender(32) + id(32) + token(32) + amounts(32) + fees(32) + data
        uint256 amount;
        uint256 fee;
        assembly {
            amount := shr(128, calldataload(100)) // amount0 = high 128 bits of amounts
            fee := shr(128, calldataload(132))     // fee0 = high 128 bits of feeAmounts
        }
        flashFee = fee;

        if (amount > 0) {
            // Repay: transfer borrowed WETH + fee back to the pair
            (bool ok,) = weth.call(
                abi.encodeWithSignature("transfer(address,uint256)", msg.sender, amount + fee)
            );
            if (ok) repaySuccess = true;
        }

        // CRITICAL: must return this exact value
        return abi.encode(CALLBACK_SUCCESS);
    }

    function withdraw(address token) external {
        require(msg.sender == owner, "not owner");
        IERC20(token).transfer(owner, IERC20(token).balanceOf(address(this)));
    }
}
