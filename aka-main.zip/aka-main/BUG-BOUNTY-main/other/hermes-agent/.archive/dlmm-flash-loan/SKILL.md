---
name: dlmm-flash-loan
description: DLMM (Liquidity Book) flash loan exploitation — callback selectors, proxy patterns, return values, amount encoding. Applies to Trader Joe LB forks (Metropolis, etc.)
triggers:
  - DLMM
  - Liquidity Book
  - LB pair
  - Trader Joe LB
  - flash loan on LB
  - bin-based AMM
  - composition fee
---

# DLMM / Liquidity Book Flash Loan Exploitation

## Flash Loan Function

```
Function: flashLoan(address receiver, bytes32 amounts, bytes data)
Selector: 0xea3446bf
Location: LB Pair (via proxy → implementation)
Fee: Set by factory.getFlashLoanFee() — typically 5e12 (0.0005%)
```

**amounts encoding:** `(amount0 << 128) | amount1` — borrow amount0 of token0 and/or amount1 of token1.

The pair ALWAYS transfers the borrowed token to the receiver FIRST, then calls the callback.

## Callback (THE CRITICAL PART)

```
Selector: 0x1faa6b87 (custom, NOT in 4byte.directory)
Signature: LBFlashLoanCallback(address sender, bytes32 id, address token, bytes32 amounts, bytes32 feeAmounts, bytes data)
```

**CRITICAL: Callback MUST return this exact bytes32 or the pair reverts with "JW":**
```
0xab5c473bce5960a8292e9c8db82f9272504caab4e9ef09553fc112f82b62a3c2
```

This hash is hardcoded in the implementation at PUSH32 before the EQ check. If return value != this hash → `LBPair__FlashLoanCallbackFailed()` (0x4a570113).

## Parameter Mapping (TRAP!)

The callback params are NOT what you expect:
- `sender` = the receiver contract address (msg.sender of flashLoan)
- `id` = **the borrowed token address** as bytes32 (e.g., token0)
- `token` = the OTHER token in the pair (often WETH) — NOT the borrowed one!
- `amounts` = `(amount0 << 128) | amount1` — borrowed amounts
- `feeAmounts` = `(fee0 << 128) | fee1` — fees to pay

**To get the borrowed token address:** `address(uint160(uint256(id)))`
**To repay:** transfer the borrowed token (from `id`), NOT `token`.

## Calldata Decoding — MUST USE ASSEMBLY

`abi.decode(msg.data[4:], ...)` DOES NOT WORK due to calldata encoding. Use assembly:

```solidity
fallback(bytes calldata) external returns (bytes memory) {
    uint256 amount;
    uint256 fee;
    assembly {
        amount := shr(128, calldataload(100))  // amount0 from amounts
        fee := shr(128, calldataload(132))      // fee0 from feeAmounts
    }
    // ... repay logic ...
    return abi.encode(CALLBACK_SUCCESS);
}
```

Calldata layout after 4-byte selector:
- Offset 4: sender (address, 32 bytes)
- Offset 36: id (bytes32, 32 bytes)
- Offset 68: token (address, 32 bytes)
- Offset 100: amounts (bytes32, 32 bytes)
- Offset 132: feeAmounts (bytes32, 32 bytes)
- Offset 164: data offset + data

## Proxy Pattern (LB Pairs)

LB pairs use a modified ERC-1167 proxy that appends embedded data:

```
Proxy bytecode: 363d3d373d3d3d3d61002c806035363936013d73<impl_addr>5af43d3d93803e603357fd5bf3
Embedded data:  <token0_20bytes><token1_20bytes><binStep_2bytes><baseFactor_2bytes>
```

The proxy:
1. Copies calldata + embedded data to memory
2. Delegates to implementation (which receives calldata + embedded params)
3. On success: jumps to 0x33 (JUMPDEST then RETURN)
4. On fail: reverts

**Implication:** The implementation reads token0/token1/binStep/baseFactor from the appended calldata, not from storage.

## Error Codes

| Selector | Name | Meaning |
|----------|------|---------|
| 0xe4f56042 | LBPair__ZeroBorrowAmount() | amounts = 0 |
| 0xe450d38c | ERC20InsufficientBalance | Pair doesn't have enough tokens |
| 0x4a570113 | LBPair__FlashLoanCallbackFailed() | Callback failed or wrong return value |
| "JW" | (same as above) | Return value mismatch |

## Working PoC Template

```solidity
contract LBFlashReceiver {
    bytes32 constant CALLBACK_SUCCESS = 0xab5c473bce5960a8292e9c8db82f9272504caab4e9ef09553fc112f82b62a3c2;
    
    function doFlashLoan(address pair, uint256 amount0) external {
        bytes32 amounts = bytes32(uint256(amount0) << 128);
        bytes memory d;
        (bool ok,) = pair.call(
            abi.encodeWithSignature("flashLoan(address,bytes32,bytes)", address(this), amounts, d)
        );
        require(ok, "Flash loan failed");
    }
    
    fallback(bytes calldata) external returns (bytes memory) {
        uint256 amount;
        uint256 fee;
        assembly {
            amount := shr(128, calldataload(100))
            fee := shr(128, calldataload(132))
        }
        // Repay: transfer borrowed token + fee to msg.sender
        (bool ok,) = <BORROWED_TOKEN>.call(
            abi.encodeWithSignature("transfer(address,uint256)", msg.sender, amount + fee)
        );
        require(ok, "Repay failed");
        return abi.encode(CALLBACK_SUCCESS);
    }
}
```

## LB-Specific Attack Vectors (Status: 2026-06-05)

1. **Composition fee bug** — DEAD. Historical vuln in TJ LB v2.0, fixed in v2.1/v2.2. Metropolis = clean v2.2 fork (36/37 selectors match canonical).
2. **Oracle (TWAP) manipulation** — VIABLE but untested. Oracle exists (getOracleParameters, getOracleSampleAt). Need to find consumers first.
3. **Hook re-entry** — DEAD. All pairs use factory as hook address. Factory doesn't implement beforeFlashLoan/afterFlashLoan. Hooks configured but not called during flash loan.
4. **Active bin drain** — DEAD. Standard v2.2, v2.0 bug fixed.
5. **Cross-pair flash loan arbitrage** — CONFIRMED WORKING. Flash borrow from pair A → swap on pair B → sell on AMM → repay. Profit from price discrepancy between LB and AMM.

## LB Pair Swap Function

```
Function: swap(bool swapForY, address to)
Selector: 0x53c059a0
```

**How to call (MUST transfer tokens first):**
```solidity
// Transfer tokens to pair FIRST
IERC20(token).transfer(pair, amount);
// Then swap
(bool ok,) = pair.call(abi.encodeWithSignature("swap(bool,address)", true, address(this)));
```

**Direction:**
- `swap(true, to)` = token0 → token1
- `swap(false, to)` = token1 → token0

**CRITICAL: LB pair has reentrancy guard!** `ReentrancyGuardReentrantCall()` (0x3ee5aeb5) when calling swap on the SAME pair during flash loan callback. Must use CROSS-PAIR strategy.

## Cross-Pair Flash Loan Arbitrage Pattern

When LB and AMM price differ for the same token:

1. Flash borrow WETH from LB pair A (fee: 0.0005%)
2. Transfer WETH to LB pair B, swap WETH → token (buy cheap at LB price)
3. Sell token on AMM (expensive — AMM price often higher)
4. Repay WETH + fee to pair A
5. Profit = AMM output - flash loan cost

**Key constraint:** Must borrow from DIFFERENT pair than swap target (reentrancy guard).

**Verified example:** Metropolis Familio/WETH — LB price 3.54e-5, AMM price 1.52e-4 (4.3x spread). Profit: 0.01457 WETH per 0.5 WETH borrowed.

## Pitfalls

1. **Return value is NOT optional** — Forgetting `return abi.encode(CALLBACK_SUCCESS)` causes "JW" revert even if repayment succeeds.
2. **abi.decode doesn't work on callback calldata** — Must use assembly for calldataload.
3. **id ≠ token** — `id` is the borrowed token, `token` is the other one. Mixing them up causes wrong-token repayment.
4. **Fee-on-transfer tokens break flash loans** — Borrowed amount != received amount.
5. **Proxy appends data** — Don't assume standard ERC-1167. The implementation receives extra calldata.
6. **LB swap() is NOT AMM swap** — `swap(bool,address)` is bin-based, not constant product. Different interface, different math.
7. **LB reentrancy guard blocks same-pair swap** — `ReentrancyGuardReentrantCall` (0x3ee5aeb5) when calling swap during flash loan callback on the SAME pair. Use cross-pair strategy.
8. **Hooks may be no-op** — If all pairs use factory as hook address and factory doesn't implement hook functions, hooks are configured but never called. Don't claim "hooks exist = attack surface" without verifying hook implementation.
9. **Swap return values from low-level call() are NOT decoded** — `bool ok` only shows success/fail. Use `balanceOf` diffs for profit verification. If logs show "output: 0" but "profit: X", the swap worked but return wasn't captured.
10. **console.log with 4+ args fails in Foundry** — Split into multiple console.log calls with max 3 args each.
