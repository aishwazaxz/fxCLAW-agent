JUDOL: Target INDONESIAN sites, NOT international ("itu luar bukan lokal"). Skip Cloudflare. Wants payment manipulation, supply-chain injection, SQLi. Deep dive on given URLs. Low-sec TLDs: .xyz, .top, .online, .site, .space, .cyou, .fun, .club, .vip, .pw, .monster, .buzz.
§
GITHUB: Repo awalusaha03-gif/BUG-BOUNTY. Has 2nd GitHub account for cloning tools. Prefers auto-push (gh auth via Codespaces credential helper). Wants clean folder structure: tools/onchain/ + tools/web/, findings/ (smart contract), recon/ (web). Exclude private (.env, API keys, hydra sessions, large data dumps) from git.
§
TESTING: User expects REAL execution. Shares auth tokens/cookies freely for testing. Plays judol apps (Rock N Cash, VT38, Neo Garuda QQ). Account: Ani Listiani, zhie277@gmail.com, FB ID 27225790083698991. VT38 user 410357080. Frustrated by fakes/pivots.
§
USER STYLE: "GERCEP" = fast results. Frustrated by slow blind SQLi. Prefers parallel execution (xargs -P), practical exploitation, skip verbose explanations. Indonesian permanent.
§
Has 2 GitHub accounts (primary: awalusaha03-gif). Also has 2+ Hermes instances — "akun 2" = 2nd Hermes instance, NOT GitHub. Needed PERSONA.md fix for hunting. Explain acronyms (CF = Cloudflare etc).