# ONIX Gambling Platform

Backend for Indonesian judol sites (jangkar55, asgacor, juara126, leon188, nona55, platinum789).

## API Access

```
Base: https://api-onix-ns2.seamless-hptech.com
Headers (ALL required):
  d-key: CS2ABA0          (app identifier, varies per site)
  domain_key: CS2ABA0     (same as d-key)
  agent_id: CS2ABA0       (same as d-key)
  x-api-key: edV1^z5uhx6WN8z
  User-Agent: okhttp/4.9.3
  Accept: application/json
  X-Requested-With: XMLHttpRequest
```

## d-key Mapping

| d-key   | App          |
|---------|--------------|
| CS2ABA0 | jangkar55    |
| CS2ABCA | asgacor      |
| CS2ABAJ | juara126     |
| CS2ABA1 | leon188      |
| CS2ABAG | nona55       |
| CS2ABAH | platinum789  |

## Key Endpoints (GET)

| Endpoint | Auth | Returns |
|----------|------|---------|
| `/` | With headers | Main page (24KB with headers, 357KB without) |
| `/ajaxCSRFToken` | With headers | `{"data": "csrf_token"}` |
| `/register` | With headers | Full config JSON (49 banks, 10 ewallets, admin users, honeypot) |
| `/promotion` | With headers | Promo banners JSON |
| `/referral` | With headers | Referral config |
| `/getHkgpLiveDraw` | None | Lottery results |
| `/get_reward_balance` | Auth required | Reward balance |

## Key Endpoints (POST, need _token in body)

| Endpoint | Data | Returns |
|----------|------|---------|
| `/checkExistingEmail` | `email=X&_token=Y` | `true`/`false` (BROKEN — always returns true) |
| `/checkUserNameAvailability` | `user_name=X&_token=Y` | `true` or error message |
| `/login` | `user_name=X&password=Y&_token=Z` | `{"s":"s","m":"success"}` or error |

## Login Error Enumeration

```
"tidak terdaftar"  → user does NOT exist
"Password salah!"  → user EXISTS, wrong password
"Too many requests" → rate limit (~5 attempts/minute)
```

## Register Endpoint Leaks

GET /register returns JSON with:
- `banks[]` — 49 banks with MongoDB ObjectIDs
- `fund_methods{}` — 10 ewallets (DANA, OVO, GOPAY, etc.) with IDs
- `is_disable_otp: true` — OTP disabled
- `honeypot{}` — bot detection fields (4 fields, 1 with hardcoded value)
- `register_token` — format: `CS2ABA0-{timestamp}-{random}`
- `pwd_regex` — password requirements
- Admin usernames in `created_by` fields: cs2aba0, jay, jangkar, kaptenjangkar1-4, bongejk, kurojangkar

## Infrastructure

- Payment Gateway: stgapicurr.seamlesss-hptech.com (CF 403 HTTP, 500 HTTPS)
- Help2Pay: stgpay.ug396-api.com (403)
- Firebase: api-onix-ns2-live2-default-rtdb.firebaseio.com (READ OPEN)
- Global Config: global-configs-2-default-rtdb.asia-southeast1.firebasedatabase.app
- VaderPay: stageapi.vaderpay.net (staging shell, any token = 0.00)
- Subdomains: admin/stg/stgapi/pay/payment/gateway/merchant.seamlesss-hptech.com

## PITFALLS

- POST to `/register` returns 405 — registration is mobile-only
- `/checkExistingEmail` is broken (always returns true) — useless for enum
- CSRF token must come from `/ajaxCSRFToken` with proper headers FIRST
- Without `d-key` header, main page returns 500 (0 bytes)
- Rate limit: ~5 login attempts per 60 seconds
