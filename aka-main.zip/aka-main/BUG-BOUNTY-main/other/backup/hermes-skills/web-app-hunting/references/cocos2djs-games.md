# Cocos2d-JS Game Exploitation

Patterns for reversing and exploiting mobile games built with Cocos2d-JS engine.

## Fingerprint

- `libcocos2djs.so` in APK lib/ (20-30MB typical)
- `assets/project.json` — game config (jsList, modules, configUrl)
- `assets/project_common.json` — slot/game definitions
- `assets/main.js` — entry point
- `assets/script/` — Cocos2d engine JS files
- Multiple DEX files (classes.dex through classesN.dex)

## Key Files to Extract

1. **Remote config URL** — in `project.json` → `configUrl` field
2. **Game server** — from remote config JSON → `GATE_HOST`, `GATE_PORT`
3. **CDN URLs** — `ASSET_BASE_URL`, `SCRIPT_BASEURL`
4. **SDK config** — `assets/res/sdkbox_config.json` (Facebook ID, IAP items)
5. **BuildConfig.java** — Google Client ID, build flavor, version

## Remote Config Pattern

```
GET {configUrl}
Returns JSON:
{
  "GATE_HOST": "gate.example.com",
  "GATE_PORT": 20002,
  "ASSET_BASE_URL": "https://cdn.example.com/assets",
  "SCRIPT_BASEURL": "https://cdn.example.com/scripts",
  "STAGE": "stage1",
  "FB_ID": "123456789",
  "versionID": "260601072750"
}
```

## Protocol Analysis

Cocos2d-JS games typically use one of:
1. **Socket.IO** — look for `SocketIO` in SO strings
2. **Raw WebSocket** — `WebSocket` class in SO
3. **HTTP polling** — less common for real-time games

Connection flow:
```
1. OAuth login (FB/Google/Apple) → get auth token
2. Load remote config → get GATE_HOST:GATE_PORT
3. Connect WebSocket/Socket.IO to game server
4. Send auth message with token
5. Game protocol messages (JSON or binary)
```

## String Extraction from SO

```bash
strings libcocos2djs.so | grep -iE "(login|auth|token|coin|balance|spin|slot|bet|win|jackpot)"
strings libcocos2djs.so | grep -iE "(SocketIO|WebSocket|socket\.connect)"
strings libcocos2djs.so | grep -iE "https?://"
strings libcocos2djs.so | grep -iE "(AES|encrypt|decrypt|cipher|hmac)"
```

## Server Fingerprinting

Game servers often run Express.js (Node.js). Check:
```bash
# WSS handshake reveals x-powered-by header
curl -kI https://gate.example.com:20002/
# Look for: x-powered-by: Express
```

Error pages may leak server paths:
```
Error: Not Found at /home/ubuntu/app/app.js:422:15
```

## Common Attack Vectors

1. **Remote config manipulation** — if configUrl is HTTP, MITM to redirect GATE_HOST
2. **CDN asset tampering** — if CDN allows PUT, inject malicious JS
3. **OAuth token theft** — CSP unsafe-eval + XSS → steal FB/Google token
4. **IAP receipt forgery** — fake Google Play receipts sent to game server
5. **Protocol manipulation** — intercept WebSocket, modify coin/bet messages
6. **Device ID spoofing** — predictable MD5(android_id) for multi-account

## PITFALLS

- JS source files listed in project.json are NOT in APK — compiled into libcocos2djs.so
- CDN scripts often return 403 (Access Denied) — need valid session
- Game server port may accept TCP but reject HTTP/WebSocket without proper auth
- Socket.IO EIO version matters — try EIO=2,3,4
- `project.json` configUrl is the PRIMARY target — it reveals everything
- WSS (port 443) often works when WS (port 20002) drops connections
