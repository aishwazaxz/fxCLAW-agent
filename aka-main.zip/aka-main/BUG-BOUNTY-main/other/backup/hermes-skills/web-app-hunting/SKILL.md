---
name: web-app-hunting
description: Systematic web application bug bounty hunting — API exploitation, auth bypass, info disclosure, and infrastructure mapping for Indonesian gambling/finance targets.
triggers:
  - "hunt web target"
  - "exploit website"
  - "API enum"
  - "web app audit"
  - "judol hunting"
  - "gambling site exploit"
---

# Web Application Hunting

Systematic approach to finding and exploiting vulnerabilities in web applications, with focus on API abuse, authentication bypass, and infrastructure mapping.

## PHASE 1: RECON

1. **Subdomain enumeration** — `subfinder -d target.com`, DNS brute
2. **Tech fingerprint** — headers (Server, X-Powered-By), CSP, cookies
3. **Endpoint discovery** — JS files, robots.txt, sitemap.xml, API docs
4. **Firebase check** — `https://{project-id}.firebaseio.com/.json` (try READ)
5. **Remote config** — common paths: `/projectConfig`, `/config`, `/api/config`, `/.env`

## PHASE 2: API EXPLOITATION

### Header Manipulation
Many APIs require custom headers. Check app source (APK/JS) for:
- `d-key` / `domain_key` / `agent_id` — platform identification
- `x-api-key` — API authentication
- `X-Requested-With: XMLHttpRequest` — AJAX detection
- Custom auth headers from mobile interceptors (OkHttp, Dio, Alamofire)

### CSRF Token Extraction
```
GET /ajaxCSRFToken → {"data": "token_value"}
POST /endpoint with _token=token_value in body AND X-CSRF-TOKEN in header
```
Key: Visit main page first to get session cookie, THEN get CSRF token.

### Username Enumeration via Login
Different error messages for existing vs non-existing users:
- "Username not registered" → user does NOT exist
- "Username or password incorrect" → user EXISTS but wrong password
Test with known-bad password like "WrongPass123!" to distinguish.

## PHASE 3: AUTH BYPASS

1. **Register endpoint data leak** — GET /register often returns full config (banks, ewallets, admin usernames, OTP settings, honeypot fields)
2. **Mass assignment** — try adding `role=admin`, `balance=999999`, `is_verified=true` to registration/profile update
3. **IAP receipt forgery** — test with fake Google Play receipts
4. **Token prediction** — analyze token format (timestamp + random, UUID, sequential)

## PHASE 4: INFRASTRUCTURE

1. **Error page analysis** — trigger 404/500, check for stack traces (server paths, framework versions)
2. **CORS check** — `Access-Control-Allow-Origin: *` = any origin can make API calls
3. **CSP analysis** — `unsafe-eval` + `unsafe-inline` = XSS trivial
4. **Rate limiting** — test login/API rate limits (5-10 requests to detect)

## PITFALLS

- **Cloudflare 403 on HTTP but 500 on HTTPS** — try HTTPS directly, backend may be accessible
- **"All emails return true"** — test endpoint is broken/useless, not a real enum
- **Firebase "deactivated"** — check if old data still accessible via specific paths
- **CSRF token mismatch** — you need BOTH session cookie AND fresh token from /ajaxCSRFToken
- **POST returns 405** — endpoint only accepts GET (common in Cocos2d-JS apps)
- **Socket.IO vs raw WebSocket** — test both `ws://` and `wss://`, different EIO versions (2,3,4)

## TOOLS

- `subfinder` — subdomain enum
- `nuclei` — vulnerability scanning
- `ffuf` — directory/file brute force
- `sqlmap` — SQL injection
- `curl` — HTTP requests
- `python3 requests` — scripted exploitation
- `websocket-client` — WebSocket testing

## REFERENCES

See `references/onix-platform.md` for ONIX gambling platform specifics.
See `references/cocos2djs-games.md` for Cocos2d-JS game exploitation patterns.
