---
name: waf-bypass-workflow
description: "Low-noise web hunting workflow for WAF-protected targets (Cloudflare, AWS WAF)"
metadata:
  hermes:
    tags: [security, web, waf, cloudflare, bypass, hunting]
---

# WAF Bypass & Low-Noise Web Hunting Workflow

When targets have WAF (Cloudflare, AWS, etc.) and catch-all routes (Laravel, Django), use this workflow instead of aggressive scanning.

## 1. Nuclei - Low Noise Mode

Don't use default aggressive templates. Use scoped, slow scan:

```bash
nuclei -l live.txt \
  -severity critical,high,medium \
  -etags fuzz,dos \
  -rl 5 \          # rate limit: 5 req/sec
  -c 5 \           # concurrency: 5
  -bs 5 \          # batch size: 5
  -timeout 10 \
  -retries 1 \
  -H "X-BugBounty-Hacker: <handle>" \
  -o nuclei_safe.txt
```

- `-etags fuzz,dos` = exclude fuzzing and DoS templates
- `-rl 5` = slow rate to avoid WAF blocks
- For login areas: use authenticated scan (secret file)

## 2. SQLMap - Request-Based, Low Profile

Don't scan blindly. Use real request from Burp:

```bash
python sqlmap.py -r request.txt \
  -p id \          # specific parameter only
  --level=1 \      # low level
  --risk=1 \       # low risk
  --threads=1 \    # single thread
  --timeout=10 \
  --retries=1 \
  --batch
```

- `-r request.txt` = use real HTTP request (from Burp/DevTools)
- `-p id` = test only specific parameter
- `--level=1 --risk=1` = minimal tests, avoid WAF triggers

## 3. FFUF - Baseline Filtering (for catch-all routes)

When site returns 200 for everything (Laravel catch-all):

```bash
# Step 1: Get baseline (random path)
curl -s https://target.com/xyzrandom123 -o /dev/null -w "%{size_download}"
# Note the size, e.g., 17385

# Step 2: Filter by size/words/lines
ffuf -w wordlist.txt \
  -u https://target.com/FUZZ \
  -mc all \
  -fs 17385 \      # filter by response SIZE
  -fw 1828 \       # filter by word count
  -fl 4 \          # filter by line count
  -o ffuf.json
```

- `-mc all` = match all status codes
- `-fs <size>` = filter out responses with this size (baseline)
- `-fw <words>` = filter out responses with this word count
- `-fl <lines>` = filter out responses with this line count

## 4. Katana - Custom Endpoint Discovery

Focus on custom endpoints, not generic CVEs:

```bash
katana -list live.txt \
  -jc \            # JavaScript crawl
  -d 3 \           # depth 3
  -rl 20 \         # rate limit 20
  -o katana_urls.txt
```

Then analyze:
```bash
httpx -l katana_urls.txt \
  -sc \            # status code
  -title \         # page title
  -td \            # tech detect
  -o tech_map.txt
```

## 5. Debug Mode - Signal, Not Finding

When debug mode is ON but doesn't leak info:
- Treat as SIGNAL, not finding
- Look for: different roles, internal endpoints, behavior differences when authenticated
- Test: different user roles, admin vs regular user

## 6. Priority: Business Logic > CVE

After initial recon, focus on:
- IDOR (Insecure Direct Object Reference)
- Role bypass
- Workflow abuse
- Authz (authorization) issues
- Parameter tampering

These are harder to detect with automated tools but more valuable.

## 7. User Enumeration via Registration API

Many Laravel sites expose user enumeration via registration endpoints:

```bash
# Common endpoint: /register/check_user
curl -s -X POST "https://target.com/register/check_user?token=test" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d "username=admin"

# Response patterns:
# EXISTS:     {"success":true,"data":{"check":true},"valid":false}
# NOT EXISTS: {"success":false,"data":{"check":false},"valid":true}
# Note: "valid" field is INVERTED (valid:false = username is TAKEN)
```

**No rate limiting = mass enumeration possible.** Build wordlist from common gambling terms: admin, bandar, boss, manager, deposit, withdraw, hoki, gacor, maxwin, jackpot, slot.

## 8. False Positive Detection

### Login brute force
ALWAYS verify with garbage credentials first. If `admin:wrongpass` and `admin:realpass` return identical responses, the login form doesn't differentiate = can't brute force.

### Catch-all 200 responses
When ALL paths return 200, use baseline filtering (see section 3). Don't trust status codes alone.

### Registration validation endpoints
`/register/check_bank_account` may accept ANY input and return `valid:true` — this is NOT a vulnerability, just poor validation. Verify by checking if the data is actually used downstream.

## 7. User Enumeration via Registration APIs

When registration endpoints exist, test for user enumeration:

```bash
# Test check_user endpoint
curl -s -X POST "https://target/register/check_user" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d "username=admin"

# Response analysis:
# {"valid": false} = user EXISTS (taken)
# {"valid": true} = user NOT EXISTS (available)
```

Common endpoints to check:
- `/register/check_user` - username enumeration
- `/register/check_bank_account` - bank account validation leak
- `/register/check_password` - password policy leak

## 8. Login Response Analysis

Always verify if login responses are real or false positives:

```bash
# Test with definitely wrong credentials
curl -s -X POST "https://target/login" \
  -d "username=xyznonexistent999&password=xyznonexistent999"

# Compare with valid credentials
curl -s -X POST "https://target/login" \
  -d "username=admin&password=test"

# If responses are IDENTICAL = FALSE POSITIVE
# Login form might always redirect regardless of credentials
```

## Pitfalls

- Don't use `-t 50` (50 threads) on WAF-protected sites
- Don't use default nuclei templates (too noisy)
- Don't rely on status code alone for catch-all routes
- Don't scan without baseline filtering on catch-all sites
- Always use `-rl` (rate limit) on WAF-protected targets
- Always verify login brute force results (check for false positives)
- Laravel catch-all returns 200 for ALL paths - filter by size/words/lines
- Don't assume login brute force works without verifying with garbage credentials
- Don't assume user enumeration endpoint = password brute force (different vulns)
- **Spring Boot 403 from curl** — Java/Spring Boot backends often return 403 to curl but work fine from browser. This is NOT a WAF block — it's CSRF/header validation. Set Origin, Referer, x-requested-with headers, or use browser. See `references/static-config-enumeration.md`.

## Cloudflare FULL Bypass (ALWAYS TRY FIRST)

Before pivoting or skipping, try these:

### FlareSolverr (primary — most reliable)
```bash
docker run -d --name flaresolverr -p 8191:8191 flaresolverr/flaresolverr:latest
# Then:
python3 tools/web/flare_bypass.py https://target.com
# Or raw:
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"request.get","url":"https://target.com","maxTimeout":60000}'
```

### FlareSolverr Persistent Sessions (for CSRF-protected sites)
When POST requests return "Page expired due to inactivity":
```python
# Use sessions.create to maintain session across requests
# See: references/flaresolverr-persistent-sessions.md (in cf-auto-bypass skill)
flare = FlareSolverr()  # see cf-auto-bypass skill for class implementation
flare.create_session()
page = flare.get("https://TARGET")  # get CSRF token
result = flare.post("https://TARGET/endpoint", f"_token={csrf}&field=value")
flare.close()
```

### Playwright + Stealth (fallback — may NOT solve non-interactive CF)
```bash
pip install playwright playwright-stealth && python3 -m playwright install chromium
python3 tools/web/playwright_stealth_get.py https://target.com
```
⚠️ PITFALL: Playwright+Stealth may NOT solve non-interactive CF challenges ("Tunggu sebentar...", "Just a moment..."). FlareSolverr is more reliable for CF bypass.

Both return full HTML + cookies bypassing CF challenge. Use cookies from response for subsequent curl/requests.

### Cookie Extraction for curl
```python
import requests, json
r = requests.post("http://localhost:8191/v1", json={"cmd":"request.get","url":"https://target.com","maxTimeout":60000}, timeout=90)
cookies = "; ".join(f"{c['name']}={c['value']}" for c in r.json()["solution"]["cookies"])
# Use: curl -b "COOKIES" https://target.com/api/endpoint
```

If FlareSolverr AND Playwright both fail → THEN try Origin IP Discovery below.

## Cloudflare Origin IP Discovery (PIVOT SECOND)

When target has Cloudflare WAF, DON'T auto-skip. Try origin IP discovery:

1. **DNS history** — `curl -s "https://api.hackertarget.com/hostsearch/?q=DOMAIN"`
2. **Subdomain brute-force** — api, admin, mail, cpanel, whm, staging, dev, backend, app, ftp
3. **Port scan** — Check 80, 443, 8080, 8443, 3000, 3306 on discovered IPs
4. **Direct IP access** — `curl -sk -H "Host: DOMAIN" http://ORIGIN_IP:8080/`

If ALL ports return "cloudflare" responses → origin is fully behind CF (Spectrum). THEN skip.

See `references/cloudflare-origin-ip-discovery.md` for full workflow and decision tree.

## Support Files
- `references/static-config-enumeration.md` — Static JSON/YAML config file enumeration on Cloudflare-protected SPA sites. Bypasses WAF by targeting static file serving. Includes detection script and high-value paths.
- `references/cloudflare-origin-ip-discovery.md` — Origin IP discovery workflow: DNS history, subdomain brute-force, port scanning, direct IP access, decision tree.

## Static Config Bypass
Cloudflare blocks API scanning but often allows static JSON/YAML config files. Always check `/public/html/settings/*.json`, `/config/*.json`, `/locales/*.json` etc. These leak API endpoints, payment configs, admin usernames, and feature flags. See `references/static-config-enumeration.md` for full path list and detection script.
