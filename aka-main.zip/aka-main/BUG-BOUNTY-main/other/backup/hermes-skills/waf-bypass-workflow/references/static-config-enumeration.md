# Static Config File Enumeration (WAF Bypass Technique)

## Concept
Cloudflare WAF blocks API scanning but often serves static files (JSON, YAML, JS) without challenge. Many SPA-based gambling sites expose internal configuration as publicly accessible static JSON files.

## Common Paths to Check

### Whitelabel/Platform Configs
```
/public/html/settings/*.json
/public/html/default_whitelabel/settings/*.json
/public/html/scripts/*.json
/public/html/scripts/processed_data/*.json
/locales/{lang}/*.json
/public/html/contact.json
/public/html/provider_maintenance/*.json
```

### Specific High-Value Files
```
# Payment processors + bank codes
/public/html/settings/bank-name.json

# Contact channels (Telegram, WhatsApp, LiveChat per locale)
/public/html/contact.json

# Site config (logos, videos, CMS images)
/public/html/scripts/website-settings.json

# Game providers, menu ordering, hidden games
/public/html/settings/menu-settings.json

# SPA route config (exposes ALL pages including admin)
/public/html/settings/custom-route-settings.json
/public/html/default_whitelabel/settings/base-route-settings.json

# Feature flags
/public/html/default_whitelabel/settings/flagsmith.json

# Provider maintenance status
/public/html/provider_maintenance/provider_maintenance_{CURRENCY}.json

# Announcements (may contain internal info)
/public/html/scripts/announcement.json
/public/html/scripts/multi-announcement.json

# External style/scripts (third-party integrations)
/public/html/scripts/external-style.json
/public/html/settings/floating-notification-before-login.json
```

## API Endpoints That Return Config (No Auth)
Some API paths are whitelisted by the WAF and return JSON without auth:
```
/cashmarket/api/v3/public/settings/*
/cashmarket/api/public/*
/campaign/api/v2/p/*
```

## Detection Script
```bash
#!/bin/bash
TARGET="$1"
echo "[*] Static config enumeration: $TARGET"

for path in \
  "/public/html/settings/bank-name.json" \
  "/public/html/contact.json" \
  "/public/html/scripts/website-settings.json" \
  "/public/html/settings/menu-settings.json" \
  "/public/html/settings/custom-route-settings.json" \
  "/public/html/default_whitelabel/settings/base-route-settings.json" \
  "/public/html/default_whitelabel/settings/flagsmith.json" \
  "/public/html/scripts/announcement.json" \
  "/public/html/settings/custom-translation.json" \
  "/public/html/settings/account-page-settings.json" \
  "/locales/en/global.json" \
  "/locales/en/settings.json"; do
  
  resp=$(curl -sk --max-time 10 "$TARGET$path" 2>/dev/null)
  if echo "$resp" | python3 -m json.tool &>/dev/null; then
    size=$(echo "$resp" | wc -c)
    echo "[+] 200 $path (${size}b)"
  fi
done
```

## What Each File Reveals
- **bank-name.json** → All payment method codes (useful for payment manipulation)
- **contact.json** → Telegram/WhatsApp channels (social engineering vectors)
- **menu-settings.json** → Game providers (third-party API targets)
- **base-route-settings.json** → All SPA routes including admin/account pages
- **flagsmith.json** → Feature flags (deposit prevention, VIP, etc.)
- **announcement.json** → Internal announcements, marketing team names
- **custom-translation.json** → Full translation keys (reveals hidden UI elements)

## Pitfalls
- Static files bypass Cloudflare WAF but NOT rate limiting. Don't hammer them.
- Some JSON files may be behind authentication — check if response is HTML (redirect) vs JSON.
- SPA catch-all means some paths return 200 with HTML, not JSON. Always validate with `python3 -m json.tool`.
