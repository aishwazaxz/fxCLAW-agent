# Cloudflare Origin IP Discovery & Pivot Workflow

When a target is behind Cloudflare, DON'T auto-skip. Try to find the origin IP first.

## Step 1: DNS History Lookup

```bash
# hackertarget — free, no auth
curl -s "https://api.hackertarget.com/hostsearch/?q=DOMAIN" | head -20

# bufferover.run — free
curl -s "https://dns.bufferover.run/dns?q=DOMAIN" | python3 -c "
import sys,json; d=json.load(sys.stdin)
[print(r) for r in d.get('FDNS_A',[]).split(',')]
"
```

Output: subdomain → IP mappings. Non-Cloudflare IPs = origin servers.

## Step 2: Subdomain Brute-Force

Common subdomains that often bypass CF or reveal origin:

```bash
for sub in api admin mail ftp cpanel whm webmail staging dev test app backend 
           ns1 ns2 mx smtp pop imap vpn portal manage dashboard panel 
           cdn static assets img media files download; do
  ip=$(curl -sk --connect-timeout 3 --max-time 5 \
    "http://${sub}.DOMAIN" -o /dev/null -w '%{remote_ip}' 2>/dev/null)
  echo "${sub}.DOMAIN → $ip"
done
```

Look for IPs that differ from main domain's CF IP. Multiple origin IPs = multiple backend servers.

## Step 3: Port Scan Discovered IPs

```bash
python3 -c "
import socket
for ip in ['ORIGIN_IP_1', 'ORIGIN_IP_2']:
    print(f'=== {ip} ===')
    for port in [21,22,25,80,443,8080,8443,3000,3306,5432,9090,27017]:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            if s.connect_ex((ip, port)) == 0:
                print(f'  PORT {port} OPEN')
            s.close()
        except: pass
"
```

Interesting ports: 8080/8443 (alt HTTP), 3000 (Node.js), 3306/5432 (DB), 9090 (admin panels).

## Step 4: Direct IP Access (Bypass CF)

```bash
# Standard ports
curl -sk -H "Host: DOMAIN" http://ORIGIN_IP/
curl -sk -H "Host: DOMAIN" https://ORIGIN_IP/

# Non-standard ports (often NOT behind CF)
curl -sk -H "Host: DOMAIN" http://ORIGIN_IP:8080/
curl -sk -H "Host: DOMAIN" https://ORIGIN_IP:8443/

# Subdomain Host headers
curl -sk -H "Host: admin.DOMAIN" http://ORIGIN_IP/
curl -sk -H "Host: api.DOMAIN" http://ORIGIN_IP:8080/
```

## Step 5: Analyze Response

- `301/302 with "cloudflare"` in body = origin is ALSO behind CF (dead end)
- `200` with actual content = BYPASS SUCCESS
- `403` = origin exists but blocks non-CF requests
- `Connection refused` = port not open

## Decision Tree

```
CF Detected
  → DNS history (hackertarget)
  → Subdomain brute-force
  → Found non-CF IP? 
    YES → Port scan → Direct access → BYPASS or PIVOT
    NO  → Skip target, find another
  → All ports return CF?
    YES → Server-level CF (Spectrum/full proxy) → Skip
    NO  → Target uncovered ports/services
```

## Pitfalls

- **Cloudflare Spectrum** — Some servers configure ALL ports through CF (not just 80/443). If 8080/8443 also return "cloudflare", the origin is fully protected. Skip.
- **IP ranges** — 45.194.x.x, 104.x.x.x, 172.64.x.x, 172.65.x.x are Cloudflare ranges. If discovered IPs fall in these ranges, they're CF edge servers, not origin.
- **Rate limiting** — DNS history APIs may rate-limit. Space requests.
- **False positives** — Some subdomains (mail, ftp) may resolve to shared hosting IPs unrelated to the web app.
- **Header validation** — Some origins check `Host` header strictly. Try both the main domain and specific subdomain names.
