---
name: x2
description: "x2 — Deep Decomposition & Strategic Sequencing"
tags: [security-audit, x2]
---

# x2 — Deep Decomposition & Strategic Sequencing
# Load ONLY when: complex multi-step, strategy, architecture, "help me think through", tradeoff, "should I", roadmap

---

## When to load this
- Decision has >2 viable paths
- Mistake is expensive or hard to reverse
- User asks "what should I do" without a clear obvious answer
- Multi-day or multi-system project planning

NOT for: single-step tasks, well-defined builds, debug (use x3).

---

## Protocol

### Step 1 — Reframe
```
Stated:    [user's words]
Actual:    [what's really being asked]
Objective: [end state in 1 sentence]
Constraint: [time / money / skill / political]
Assumed:   [things treated as fact that might not be]
```

The reframe step alone often solves the problem. If stated ≠ actual, surface this BEFORE proposing solutions.

### Step 2 — Decompose
```
Sub-problems (independent):
  A. ...
  B. ...
  C. ...

Critical path: A → C → D (B is optional)
Dependencies: D needs A done first
```

### Step 3 — Options matrix
For each viable path:
```
PATH 1: [name]
  Upside:   [specific concrete win]
  Downside: [specific concrete loss]
  Risk:     low / medium / high
  Speed:    [hours/days/weeks]
  Cost:     [$ or token or time]
  Reversible? yes / no / partial
```

### Step 4 — Pre-mortem (NEW vs v2)
```
Assume in 30 days this failed. Why?
  Scenario A: [most likely failure mode]
  Scenario B: [second most likely]

Kill criteria: when do we abandon? (specific metric)
```

Pre-mortem catches the failure mode user is too excited to see.

### Step 5 — Recommend
```
Primary:  [path] — because [specific reason tied to objective]
Fallback: [path] — switch when [condition]
Avoid:    [path] — because [specific risk]
```

### Step 6 — First move
```
Next 24h action: [one specific thing, executable today]
```

Always end with a concrete action. Strategy without first move = procrastination.

---

## Reversibility framework (NEW)
Two-way door (reversible cheaply) → just decide, move fast.
One-way door (expensive to reverse) → spend time on x2, get it right.

Examples:
- Pick framework for prototype = two-way → decide in 5 min
- Pick chain for token launch = one-way → x2 full protocol
- Hire someone = one-way → x2
- Send tweet = two-way (can delete) → just send

---

## Anti-patterns
- Listing 7 options (paralysis) → max 3
- Recommending "it depends" without picking → always pick primary
- Strategy with no first action → useless
- Ignoring user's actual constraints → reframe step prevents this

---

## Output format
Short. Headers + bullets. Long thinking → compressed output.
Internal chain shown only if explicitly asked ("show your work").
