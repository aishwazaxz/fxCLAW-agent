# VT38 (h5.vt38tg.com) — Case Study

**Platform:** VT38 (NEO PARTY)  
**Engine:** Cocos2d-JS + we.core framework  
**Version:** v5.1.1.4  
**Language:** Indonesian (id)  
**Server:** Alibaba Cloud (Tengine/Alicdn)

## Infrastructure

| Endpoint | Tech | Status |
|----------|------|--------|
| h5.vt38tg.com | Cocos2d-JS | Main game site |
| api.yuanball.com/hall | Express.js | Hall API (404 for REST) |
| api.yuanball.com/naming/v2/ws/login | WebSocket | Naming server (JWT auth) |
| track.yuanball.com/track | — | Tracking |
| api.yuanball.com/maintain | — | Maintenance |
| images.gfegee.com | — | Image CDN (403) |

**Domains:** yuanball.com, rednana.com, pangtiger.com, kissmeng.com  
**Zone domains:** gyc4sp0k.com, x3dyqla3.com  
**Bundle domains:** gyc4sp0k.com, x3dyqla3.com

## Account (User's)

```json
{
  "user_id": 410357080,
  "user_token": "df15899315a15855b17d8a5e0ea3657d",
  "device_id": "w-442439-40556-97763-98414-09699",
  "channel": "h5_8218slots",
  "brand_id": 13,
  "user_name": "Guest-7080",
  "gold": 88,
  "diamond": 0,
  "isFormal": 0,
  "vip_level": 0,
  "country": "ID"
}
```

## Key Findings

### 1. Token + JWT in localStorage (CRITICAL)
```javascript
localStorage['we:sys'].sys.user_token  // plaintext token
localStorage['we:sys'].sys.user_id     // user ID
localStorage['we:sys'].sys.app_device_id // device ID
```

### 2. 150+ Gambling Games
Categories: SLOT, FISH, FIGHT, MULTI, ARCADE, VIDEO, SINGLE
Games include: Sweet Bonanza, Gates of Olympus, Starlight Princess, Dog House, Aztec, Neko, Wild Bandito, Book of Dead, Sea King, Air Fighter, Caishen Fishing, Texas, Baccarat, Blackjack, Roulette, Sicbo, Crash, Aviator, Mines, Plinko, Limbo, Teen Patti, Dragon Tiger, Sabong, Lottery, Pokdeng

### 3. Payment Methods
- OVO: Min 50jt, Max 10M
- Gopay: Min 50jt, Max 10M
- Dana: Min 50jt, Max 10M
- LinkAja: Min 10jt, Max 5M

### 4. Naming WebSocket JWT
```
wss://api.yuanball.com/naming/v2/ws/login?token=eyJhbGci...
```
JWT claims: `{user_id, chn, device_id, brand_id, expired}`

### 5. Brand/Channel System
- brand_id: 13
- channel: h5_8218slots
- Multiple brands supported via different brand_ids

## we.core Framework Data

### Server Manager
```javascript
we.core.serverMgr.getHallHost()    // "https://api.yuanball.com/hall"
we.core.serverMgr.getNamingWs()    // "wss://api.yuanball.com/naming/v2/ws/login?token=JWT"
we.core.serverMgr.getDomain()      // "yuanball.com"
we.core.serverMgr.domains          // ["yuanball.com", "rednana.com", "pangtiger.com", "kissmeng.com"]
```

### User Manager
```javascript
we.common.userMgr.userInfo.userId    // 410357080
we.common.userMgr.userInfo.userName  // "Guest-7080"
we.common.userMgr.userInfo.gold      // 88
we.common.userMgr.token              // "df15899315a15855b17d8a5e0ea3657d"
we.common.userMgr.allPayments        // Array of payment methods
we.common.userMgr.PropId             // {CoinId: 0, GemId: 1, RpId: 2, AgentId: 11, ...}
```

### Game IDs (sample)
```javascript
we.GameId  // {DOGHOUSE: 101, SWEET: 118, OLYMPUS: 119, CRASH: 174, AVIATOR: 191, ...}
we.GameType // {SLOT: 1, FISH: 2, FIGHT: 3, MULTI: 4, ARCADE: 5, VIDEO: 6, SINGLE: 7}
```

## Advertising Intelligence

The game advertises via Rock N Cash (net.flysher.rockncash):
- Ad network: Moloco (pid=moloco_int)
- Channel: UNITY
- Campaign: "NEO DOMINO QQ-Purchase-1008"
- Target: OPPO CPH2343, Android 13

## Techniques Demonstrated

### 1. we.core localStorage Extraction
```javascript
const sys = JSON.parse(localStorage.getItem('we:sys'));
// sys.sys.user_id, sys.sys.user_token, sys.sys.app_device_id
// sys.sys.app_domain_list, sys.sys.zone_domain_list
```

### 2. Naming JWT Decode
```python
import base64
jwt = "eyJhbGci..."
payload = jwt.split('.')[1]
payload += '==' * (4 - len(payload) % 4)
claims = json.loads(base64.urlsafe_b64decode(payload))
# → {"data": {"user_id": N, "chn": "h5_xxx", "device_id": "w-xxx", "brand_id": N}, "expired": timestamp}
```

### 3. Token Replacement
```javascript
localStorage.setItem('we:sys', JSON.stringify({
  sys: { user_id: TARGET_ID, user_token: TARGET_TOKEN, app_device_id: "..." }
}));
window.location.reload();
```

## Blockers

- Hall API returns 404 for REST — WebSocket-only
- Naming WebSocket returns 502 from external (Alibaba Cloud)
- CDN scripts not accessible from non-origin contexts
- Game creates new guest accounts on fresh visits
