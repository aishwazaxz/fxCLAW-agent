# Neo Garuda QQ (Neo Party) — Case Study

**Package:** com.neo.dominoqq  
**Developer:** Neo Party  
**Engine:** Unity + C# + Lua (tolua)  
**APK Size:** 68MB  
**Version:** V1.12 (2026-05-29)  
**Build Machine:** DESKTOP-ISVNVDO

## Infrastructure

| Endpoint | Tech | Status |
|----------|------|--------|
| mo.neodominoslot.com | Vue.js | Landing page (APK download) |
| neodominoslot.com | GoDaddy | Parked domain |
| idn-ack-test.neopartyworld.com | Custom | Test server (protobuf API) |
| neo-cdn.theneoparty.com | CDN | APK download |
| idn-cdn.neopartyworld.com | CDN | APK download (older versions) |
| www.neopartyworld.com | — | Company website |
| images.gfegee.com | CDN | Image CDN (403) |

## Firebase Config (LEAKED)

```json
{
  "project_id": "neo-party-53740",
  "project_number": "415294762773",
  "api_key": "AIzaSy...5QjI",
  "storage_bucket": "neo-party-53740.firebasestorage.app",
  "packages": [
    "com.neo.dominoqq",
    "com.neoparty.indonesiagame",
    "com.neoparty.pro"
  ]
}
```

## APK Structure

- **Engine:** Unity + C# (IL2CPP) + Lua (tolua)
- **global-metadata.dat:** 7.9MB — contains all C# class names, method names, string literals
- **clientlua.u3d:** 2.5MB — Lua game logic
- **google-services-desktop.json:** Firebase config exposed

## Key Classes Found (from global-metadata.dat)

- `AuthTokenString`, `Authentication`, `Authorization`
- `AutoReconnectEnabled`, `BackToLogin`
- `BeforeFetchFromServer`, `BankStubPrefix`
- `AdNetworkHandling`, `AdRevenueNetwork`

## Test Server API (Protobuf)

**Endpoint:** idn-ack-test.neopartyworld.com  
**Protocol:** Protocol Buffers + JSON fallback

### Login Response
```
POST /login → 200 (2B) hex=0x0806
JSON: {"En":6}  // Error code 6 = invalid params
```

### Protobuf Encoding
```python
def encode_str(field_num, value):
    tag = (field_num << 3) | 2  # wire type 2 = length-delimited
    data = value.encode()
    return bytes([tag, len(data)]) + data

def encode_varint(field_num, value):
    tag = (field_num << 3) | 0
    result = bytes([tag])
    while value > 0x7f:
        result += bytes([(value & 0x7f) | 0x80])
        value >>= 7
    result += bytes([value & 0x7f])
    return result
```

## Advertising Intelligence

- **Source app:** net.flysher.rockncash (Rock N Cash)
- **Ad network:** Moloco (pid=moloco_int)
- **Channel:** UNITY
- **Campaign:** "NEO DOMINO QQ-Purchase-1008"
- **Target:** OPPO CPH2343, Android 13

## APK Download URL Pattern

```
https://neo-cdn.theneoparty.com/Indonesia_Deputy/android/apk/NeoGarudaQQ_{appId}_V{version}_{date}.apk
```
Example: `NeoGarudaQQ_24104_V1.12_20260529.apk`

## Blockers

- Game is mobile-only (no web version)
- Test server returns error code 6 for all login attempts
- Firebase RTDB not enabled (404)
- Firebase Storage not accessible (404)
- Domain neodominoslot.com is parked (GoDaddy)
- Need APK installed on device to play
