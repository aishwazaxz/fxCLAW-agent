# Rock N' Cash Casino — Case Study

**Package:** net.flysher.rockncash  
**Developer:** PLAYLINKS Corp. (South Korea)  
**Engine:** Cocos2d-JS  
**APK Size:** 74MB, 8 DEX files  
**Version:** 1.72.0 (code 203)  
**User tested:** 19049263-aosPhone (Android)

## Infrastructure Map

| Endpoint | Tech | Status |
|----------|------|--------|
| www.rockncash.com | Express.js | CSP unsafe-eval, CORS * |
| gate.rockncash.com:20002 | Express.js | Game server, WebSocket |
| gate.rockncash.com:443 | Express.js | WSS, returns 404 for wrong paths |
| test.rockncash.com:8001 | Express.js (Ubuntu) | Path leak in errors |
| aflog.rockncash.com | Express.js (Ubuntu) | Error logging |
| support.rockncash.com | PHP | No CSRF on contact form |
| faq.rockncash.com | Zendesk | FAQ portal |
| deeplink.rockncash.com | — | Deep link handler |
| d3eqkzy550d33u.cloudfront.net | AWS CloudFront | CDN (Access Denied) |
| rock-n-cash-casino-slots-52496.firebaseio.com | Firebase | Deactivated |

## Key Findings

### Remote Config (CRITICAL)
```
GET https://www.rockncash.com/projectConfig
→ GATE_HOST: gate.rockncash.com
→ GATE_PORT: 20002
→ ASSET_BASE_URL: https://d3eqkzy550d33u.cloudfront.net/rnc/app/live/stage1/assets
→ STAGE: stage1
→ FB_ID: 749075361821621
```

### Exposed Credentials
```
GOOGLE_CLIENT_ID_1: 485485803377-1hfsdng9mr0t2054ha43ka0oq4ve01tv.apps.googleusercontent.com
GOOGLE_CLIENT_ID_2: 485485803377-ibmqf8p9mpjrv9dihjvb1p1nferqqogo.apps.googleusercontent.com
FACEBOOK_APP_ID: 749075361821621
FACEBOOK_PIXEL: 1270386799662885
SENTRY_DSN: 220539a814afd31853b5feb250348698
FIREBASE: rock-n-cash-casino-slots-52496.firebaseio.com (deactivated)
```

### Server Path Leak (test server)
```
GET https://test.rockncash.com:8001/ → 404
Error: Not Found at /home/ubuntu/afLog/app.js:422:15
    at Layer.handle [as handle_request] (/home/ubuntu/afLog/node_modules/express/lib/router/layer.js:95:5)
```
Reveals: Ubuntu OS, app at `/home/ubuntu/afLog/`, Express.js framework.

### Facebook OAuth Flow
```
Login methods: Facebook, Google, Apple
Flow: FB.init → FB.getLoginStatus → authResponse.accessToken → gate server auth
Game server validates FB token via Graph API
WebSocket connection requires valid auth session
```

### FB Graph API Data (with user token)
```json
{
  "id": "27225790083698991",
  "name": "Ani Listiani",
  "email": "zhie277@gmail.com",
  "friends": {"summary": {"total_count": 4230}}
}
```

### Security Issues
- CSP: `default-src * 'unsafe-inline' 'unsafe-eval'` — XSS trivial
- CORS: `Access-Control-Allow-Origin: *` — any origin
- Rate limit: 900,000 requests/window (extremely high)
- Game server TCP accessible on port 20002
- WSS on port 443 accepts connections (Express.js)
- Support portal (support.rockncash.com) no CSRF
- Device ID = MD5(android_id) — predictable, spoofable
- OneSignal push notification SDK exposed
- AppLovin ad mediation SDK exposed

### Native Code Analysis (libcocos2djs.so)
```
Socket.IO support: (function () { return SocketIO; })()
WebSocket support: (function () { return WebSocket; })()
Build path: /Users/buildmachine/.jenkins/jenkinswork/rnc_android_live/client/rockncash/
Facebook Plugin: sdkbox PluginFacebook (login, getUserID, getAccessToken)
Google Login: onGoogleLoginCallback, onGoogleLogoutCallback
Apple Connect: js_AppleConnectLogin, js_AppleConnectGetUserID
IAP: js_IAP_Purchase, js_IAP_PurchasePlaystore, js_IAP_FinishTransaction
OneSignal: NOTI_APP_ID, push notifications
AppLovin: rewarded ads, interstitial ads
```

### IAP Items (30+)
Pattern: `com.rockncash.{101-207}`, all consumable

## Techniques Demonstrated

### 1. Remote Config Extraction
1. Extract `assets/project.json` from APK
2. Find `configUrl` field
3. Fetch URL → returns server infrastructure JSON
4. `GATE_HOST` + `GATE_PORT` = game server

### 2. Express.js Server Fingerprinting
- `x-powered-by: Express` header confirms Express.js
- Error pages leak internal file paths (`/home/ubuntu/...`)
- Test/staging servers often have weaker error handling

### 3. FB OAuth Token Enumeration
- Get token from user via browser console
- Call Graph API: `/me?fields=id,name,email,friends`
- Token can enumerate user data but NOT authenticate to game server directly

### 4. WebSocket Path Discovery
- Game server on port 20002 (raw TCP) — drops connections
- Game server on port 443 (WSS) — returns HTTP 404 for wrong paths
- Need to intercept real game traffic to find correct WebSocket path
- Socket.IO uses `/socket.io/?transport=websocket&EIO=N` pattern

### 5. Native Code String Extraction
```bash
# Extract .so from APK
python3 -c "import zipfile; zipfile.ZipFile('app.apk').extract('lib/arm64-v8a/libcocos2djs.so', '.')"
# Search for game-specific strings
strings libcocos2djs.so | grep -iE "(socket|login|auth|token|api|host|port)"
# Search for SDK functions
strings libcocos2djs.so | grep -iE "(js_IAP_|js_AppLovin_|js_OneSignal_|PluginFacebook)"
```

## Attack Vectors

1. **XSS via CSP bypass** — `unsafe-eval` allows arbitrary JS on game website
2. **Protocol RE** — intercept real game traffic to understand binary protocol
3. **IAP receipt forgery** — test with fake/old receipts
4. **Device ID spoofing** — multi-account bonus abuse
5. **Coin injection** — if protocol allows balance modification
6. **Support spam** — contact form has no CSRF protection
7. **Test server exploitation** — `/home/ubuntu/afLog/` path leaked
8. **FB token abuse** — enumerate user data, friends list, email
9. **OneSignal abuse** — push notification injection (if NOTI_APP_ID found)
10. **Sentry abuse** — inject fake error reports with DSN

## Blockers

- **Game server WebSocket path unknown** — all tested paths return 404
- **FB token alone insufficient** — game server needs full OAuth session, not just token
- **CDN assets Access Denied** — CloudFront requires signed URLs
- **Firebase deactivated** — no data accessible
- **Need MITM proxy** — to capture real game WebSocket traffic and understand protocol
- **Game won't load in agent browser** — Facebook OAuth redirect blocks initialization. Need user's browser cookies (c_user, xs, datr, sb) set BEFORE page load.
- **Hall API returns 404** — game uses WebSocket-only, not REST.

## OAuth Flow Observed
```
1. User opens www.rockncash.com
2. main_canvas.js loads → fetches /projectConfig
3. FB SDK initializes → FB.getLoginStatus()
4. If not connected → redirect to Facebook OAuth dialog
5. After OAuth → FB returns authResponse.accessToken
6. Game uses accessToken to authenticate with gate.rockncash.com:20002
7. Gate server validates token via Graph API → returns game session
8. Game connects via WebSocket (path unknown)
```

**User's Facebook Profile (from token):**
- Name: Ani Listiani
- FB ID: 27225790083698991
- Email: zhie277@gmail.com
- Friends: 4,230

**Cookies captured from user's browser:**
- c_user: 100000841008629 (Facebook user ID)
- xs: session cookie (encrypted)
- fbsr_749075361821621: signed request cookie
- datr, sb: Facebook security cookies
