---
name: web3-protocol-analysis
description: "Analyze Web3 protocols (Solana, EVM) for vulnerabilities: smart contract review, tokenomics analysis, attack surface mapping, mining/staking mechanism exploitation."
metadata:
  hermes:
    tags: [security, web3, solana, ethereum, smart-contract, defi, mining]
---

# Web3 Protocol Analysis Workflow

Systematic approach to analyzing Web3 protocols for security vulnerabilities.

## Phase 1: Reconnaissance

### Identify Protocol Type
- DEX (Uniswap, Raydium, Jupiter)
- Lending (Aave, Compound, Solend)
- Mining/Staking (Kairo, Helium)
- Bridge (Wormhole, LayerZero)
- NFT Marketplace (Magic Eden, OpenSea)

### Gather Information
```bash
# Check GitHub for source code
# Check docs for architecture
# Check explorer for contract addresses
# Check Twitter/Discord for community
```

### Contract Discovery
```bash
# EVM: Etherscan/BSCScan
# Solana: Solscan/SolanaFM
# Check for proxy patterns (EIP-1967, UUPS)
```

## Phase 2: Smart Contract Analysis

### EVM (Solidity)
```bash
# Check for common vulnerabilities
# - Reentrancy
# - Integer overflow/underflow
# - Access control issues
# - Oracle manipulation
# - Flash loan attacks

# Tools: slither, mythril, echidna
```

### Solana (Rust/Anchor)
```bash
# Check for common vulnerabilities
# - Account validation missing
# - Signer verification bypass
# - Integer overflow
# - Account data sharing
# - CPI (Cross-Program Invocation) issues

# Key files to analyze:
# - lib.rs (entry point)
# - state.rs (data structures)
# - instructions/ (all instruction handlers)
# - errors.rs (error codes)
```

## Phase 3: Tokenomics Analysis

### Supply Mechanics
- Total supply cap
- Premine/initial distribution
- Emission curve (halving, linear, exponential)
- Burn mechanisms

### Fee Structure
- Initialization fees
- Transaction fees
- Top-off/maintenance fees
- Withdrawal fees

### Revenue Model
- Where do fees go?
- Treasury management
- Buyback & burn mechanisms
- Revenue sharing

## Phase 4: Attack Surface Mapping

### On-Chain Attack Vectors
1. **Oracle Manipulation**
   - Price oracle dependency
   - TWAP manipulation
   - Flash loan oracle attacks

2. **Access Control**
   - Admin centralization
   - Multi-sig requirements
   - Timelock mechanisms

3. **Economic Attacks**
   - Flash loan exploitation
   - Sandwich attacks
   - MEV extraction

4. **Logic Bugs**
   - Reward calculation errors
   - Staking/unstaking edge cases
   - Withdrawal timing issues

### Off-Chain Attack Vectors
1. **Oracle Key Compromise**
   - Key management
   - Key rotation
   - Multi-sig requirements

2. **Frontend Attacks**
   - Phishing
   - DNS hijacking
   - Supply chain attacks

3. **API Attacks**
   - Rate limiting
   - Authentication bypass
   - Data leakage

## Phase 5: Mining/Staking Analysis

### Score/Hashrate Mechanisms
```bash
# Analyze scoring formula
# Identify gaming opportunities
# Check for Sybil resistance
# Verify determinism
```

### Reward Distribution
```bash
# Check reward calculation
# Verify proportional distribution
# Look for rounding errors
# Check for dust accumulation
```

### Decay/Top-off Mechanisms
```bash
# Analyze decay rate
# Check top-off frequency
# Verify cost-benefit
# Look for timing attacks
```

## Common Vulnerability Patterns

### Smart Contract
- Missing access control
- Integer overflow/underflow
- Reentrancy (EVM)
- Account validation (Solana)
- Oracle manipulation
- Flash loan attacks

### Tokenomics
- Unbounded emission
- Fee manipulation
- Reward calculation errors
- Sybil attacks
- Governance attacks

### Off-Chain
- Oracle key compromise
- Frontend manipulation
- API abuse
- Social engineering

## Tools

### EVM
- `slither` - Static analysis
- `mythril` - Symbolic execution
- `echidna` - Fuzzing
- `cast` - Contract interaction

### Solana
- `anchor` - Framework
- `solana-cli` - Blockchain interaction
- `solscan` - Explorer
- `solana-fm` - Analytics

### General
- `curl` - API interaction
- `jq` - JSON processing
- `python3` - Scripting

## Analysis Checklist

- [ ] Protocol type identified
- [ ] Source code reviewed
- [ ] Tokenomics analyzed
- [ ] Attack surface mapped
- [ ] Smart contract vulnerabilities checked
- [ ] Off-chain components analyzed
- [ ] Economic attack vectors identified
- [ ] Recommendations provided

## Pitfalls

- Don't assume code is secure just because it's open source
- Don't ignore off-chain components (oracles, frontends)
- Don't忽略经济攻击向量（闪电贷、三明治攻击）
- Don't forget to check for proxy patterns (upgradeable contracts)
- Always verify findings with actual tests when possible
