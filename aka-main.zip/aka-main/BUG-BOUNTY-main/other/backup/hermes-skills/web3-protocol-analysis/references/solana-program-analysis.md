# Solana Program Analysis

Techniques for analyzing Solana programs (smart contracts) written in Rust/Anchor.

## Key Files to Analyze

### lib.rs (Entry Point)
- Program ID declaration
- Instruction handlers
- Public API surface

### state.rs (Data Structures)
- Account structures (#[account])
- PDA seeds
- State management logic

### instructions/ (Instruction Handlers)
- Each instruction in separate file
- Account validation (#[derive(Accounts)])
- Business logic

### errors.rs (Error Codes)
- Custom error types
- Error messages

### constants.rs (Protocol Constants)
- Token decimals
- Fee amounts
- PDA seeds

## Common Vulnerability Patterns

### Missing Account Validation
```rust
// BAD: No validation that account belongs to user
#[derive(Accounts)]
pub struct BadExample<'info> {
    pub user: Signer<'info>,
    pub account: Account<'info, SomeAccount>,  // No has_one constraint
}

// GOOD: Validate account ownership
#[derive(Accounts)]
pub struct GoodExample<'info> {
    pub user: Signer<'info>,
    #[account(has_one = user)]
    pub account: Account<'info, SomeAccount>,
}
```

### Signer Verification Bypass
```rust
// BAD: No signer check
pub fn handler(ctx: Context<SomeContext>) -> Result<()> {
    // Anyone can call this
    Ok(())
}

// GOOD: Require signer
pub fn handler(ctx: Context<SomeContext>) -> Result<()> {
    require!(ctx.accounts.user.is_signer, ErrorCode::Unauthorized);
    Ok(())
}
```

### Integer Overflow
```rust
// BAD: Unchecked arithmetic
let total = amount + fee;  // Can overflow

// GOOD: Checked arithmetic
let total = amount.checked_add(fee).ok_or(ErrorCode::Overflow)?;
```

### Account Data Sharing
```rust
// BAD: Two accounts can share same data
#[derive(Accounts)]
pub struct BadExample<'info> {
    #[account(mut)]
    pub account_a: Account<'info, SomeAccount>,
    #[account(mut)]
    pub account_b: Account<'info, SomeAccount>,  // Can be same as account_a
}

// GOOD: Constraint to prevent sharing
#[derive(Accounts)]
pub struct GoodExample<'info> {
    #[account(mut, constraint = account_a.key() != account_b.key())]
    pub account_a: Account<'info, SomeAccount>,
    #[account(mut)]
    pub account_b: Account<'info, SomeAccount>,
}
```

## Mining/Staking Protocol Analysis

### Score Mechanisms
```rust
// Check scoring formula
pub fn compute_score(activity: Activity) -> u64 {
    // Look for:
    // - Diminishing returns (log scaling)
    // - Anti-Sybil measures
    // - Determinism
    // - Gaming opportunities
}
```

### Reward Distribution
```rust
// Check reward calculation
pub fn calculate_reward(share: u64, total: u64, emission: u64) -> u64 {
    // Look for:
    // - Rounding errors
    // - Dust accumulation
    // - Proportional fairness
}
```

### Decay Mechanisms
```rust
// Check decay implementation
pub fn decayed_hash_rate(base: u64, elapsed: i64, halflife: i64) -> u64 {
    // Look for:
    // - Decay rate
    // - Top-off mechanisms
    // - Timing attacks
}
```

## Tokenomics Analysis

### Supply Mechanics
- Total supply cap
- Premine/initial distribution
- Emission curve (halving, linear, exponential)
- Burn mechanisms

### Fee Structure
- Initialization fees
- Transaction fees
- Top-off/maintenance fees
- Withdrawal fees

### Revenue Model
- Where do fees go?
- Treasury management
- Buyback & burn mechanisms
- Revenue sharing

## Attack Vectors

### Oracle Key Compromise
```rust
// Check oracle verification
pub fn verify_oracle_attestation(
    instructions_sysvar: &AccountInfo,
    oracle_pubkey: &Pubkey,
    expected_message: &[u8],
) -> Result<()> {
    // Look for:
    // - Key management
    // - Key rotation
    // - Multi-sig requirements
}
```

### Admin Centralization
```rust
// Check admin functions
pub fn set_oracle(ctx: Context<AdminOnly>, new_oracle: Pubkey) -> Result<()> {
    // Look for:
    // - Timelock
    // - Multi-sig
    // - Governance
}
```

### Economic Attacks
```rust
// Check for flash loan vulnerabilities
pub fn flash_loan(ctx: Context<FlashLoan>, amount: u64) -> Result<()> {
    // Look for:
    // - Price manipulation
    // - Sandwich attacks
    // - MEV extraction
}
```

## Tools

### Local Development
```bash
# Build
anchor build

# Test
anchor test

# Deploy
anchor deploy
```

### On-Chain Analysis
```bash
# Get account data
solana account <ADDRESS>

# Get program data
solana program show <PROGRAM_ID>

# Get transaction history
solana transaction-history <ADDRESS>
```

### Explorers
- Solscan: https://solscan.io
- SolanaFM: https://solana.fm
- Explorer: https://explorer.solana.com

## Analysis Checklist

- [ ] Program ID identified
- [ ] Source code reviewed (if available)
- [ ] Account structures analyzed
- [ ] Instruction handlers reviewed
- [ ] Access control checked
- [ ] Integer overflow/underflow checked
- [ ] Oracle verification checked
- [ ] Admin functions analyzed
- [ ] Tokenomics reviewed
- [ ] Attack vectors identified

## Pitfalls

- Don't assume code is secure just because it's open source
- Don't ignore off-chain components (oracles, frontends)
- Don't forget to check for proxy patterns (upgradeable programs)
- Always verify findings with actual tests when possible
- Check for PDA seed collisions
- Verify signer requirements on all instructions
