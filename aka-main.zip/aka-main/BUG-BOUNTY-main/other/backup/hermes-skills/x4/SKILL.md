---
name: x4
description: "x4 — Self-Improvement & Autonomous Problem-Solving (NEW in v4.0)"
tags: [security-audit, x4]
---

# x4 — Self-Improvement & Autonomous Problem-Solving (NEW in v4.0)

---

## What this is

Mode yang bikin agent **makin pinter tiap hari**: belajar dari tiap sesi, mendiagnosa masalah sendiri, dan **auto-fix hal operasional yang reversible tanpa diminta**.

Scripts: `tools/memory_engine.py` (substrat belajar) + `tools/reflection.py` (loop + gerbang).

---

## Loop harian (dipanggil dari HEARTBEAT)

```
1. OBSERVE  → tiap task di-log ke memory (apa diminta, apa works, apa gagal, error+resolusi)
2. REFLECT  → scan memory terbaru: kegagalan berulang? jalur lambat? fix manual yang sama terus?
3. LEARN    → distill jadi 'lesson' di memory_engine → next time situasi sama, lesson kepake
4. DIAGNOSE → pas ada masalah, jalanin pola x3 (debug) OTOMATIS tanpa diminta
5. AUTO-FIX → kalau action ∈ SAFE_AUTO_ACTIONS → beresin sendiri
6. PROPOSE  → selain itu → tulis proposal ke antrian, kabarin operator
```

Memory yang kepake & kebukti berguna → di-reinforce (weight naik) → makin sering muncul. Itu mekanisme "makin pinter": yang berguna naik, yang gak relevan decay.

---

## HARD LIMITS (tidak bisa di-override oleh mode ini)

```
NEVER autonomously:
✗ Sign tx / mindahin dana / approve spending
✗ Ubah spend cap atau matiin governor
✗ Regenerate SKILLS.lock (itu langkah operator — biar integrity tetap bermakna)
✗ Edit file FROZEN (SOUL, AGENTS, governor.*, mev.py, security.md,
  skill_integrity.py, reflection.py, USER.md, x4.md)
✗ Apply proposal-nya sendiri
```

`reflection.py` ngejaga ini secara struktural: `guard_write(path)` ngelempar exception kalau loop nyoba nulis ke FROZEN_PATHS. Bukan sekadar aturan di prompt — di-enforce di kode.

### SAFE_AUTO_ACTIONS (satu-satunya yang boleh tanpa konfirmasi)

```
retry_with_fallback_rpc · rotate_rpc · switch_llm_provider ·
restart_crashed_process · clear_cache · requote · backoff_and_retry
```

Semua reversible, gak nyentuh dana, gak ubah skill. Apa pun di luar ini → jadi proposal.

---

## Alur proposal (gimana agent "upgrade" dirinya dengan aman)

```
agent nemu perbaikan → reflection.propose(...) → file di ~/.hermes/proposals/
   → operator review → kalau setuju, operator ubah manual
   → operator: python tools/skill_integrity.py generate  (re-lock)
```

Operator yang nutup loop. Ini sengaja: kalau agent bisa apply + re-sign sendiri, integrity check jadi teater. Friksi di sini = fitur.

---

## Wiring ke task biasa

```python
from memory_engine import MemoryEngine
from reflection import daily_cycle, auto_fix, can_autofix, propose, Proposal

mem = MemoryEngine()

# setiap kali sesuatu gagal lalu ketemu solusinya:
mem.remember("Base RPC ankr timeout → llamarpc works", "blocker", tags="rpc,base")

# pas ada error operasional, coba auto-fix dulu:
if can_autofix("retry_with_fallback_rpc"):
    auto_fix("retry_with_fallback_rpc", handlers=my_handlers)

# di akhir sesi (HEARTBEAT):
report = daily_cycle(mem)   # learn + hitung proposal pending
```

Audit semua aksi otonom: `~/.hermes/reflection-audit.log`.

---

## Output ke operator

Pas mode ini aktif & ada sesuatu, agent lapor ringkas (bukan diam-diam):
> `🔧 auto-fix: rotate RPC Base (ankr timeout). | 📝 1 proposal baru: "fallback RPC permanen" — review di ~/.hermes/proposals/`

Hal otonom yang berhasil = lapor setelahnya. Hal yang butuh keputusan = proposal, tunggu operator.
