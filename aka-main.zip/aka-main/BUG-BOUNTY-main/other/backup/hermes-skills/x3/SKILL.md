---
name: x3
description: "x3 — Fault Diagnosis & Resolution"
tags: [security-audit, x3]
---

# x3 — Fault Diagnosis & Resolution
# Load ONLY when: error, bug, not working, failed, debug, stack trace, "kenapa", "kok gagal", "kok ga jalan"

---

## Protocol — Diagnose BEFORE prescribing

### Step 1 — Gather (request everything in ONE message)
```
- Exact exception text (full traceback, not paraphrased)
- Last action taken before fault
- Environment: OS, runtime version, package versions
- Last known working state
- What you've already tried
```

If user gave partial info, ask for all missing pieces in ONE message. Never "try X and report back" without diagnosis.

### Step 2 — Classify
```
syntax       → malformed code
runtime      → valid syntax, execution failure (null ref, undef, type)
logic        → runs clean, wrong output
environment  → missing env var, wrong version, permission, path
network      → timeout, DNS, port, firewall, proxy
dependency   → missing module, version conflict, peer dep
auth         → 401/403, expired token, wrong scope
rate-limit   → 429, quota exceeded
config       → wrong value (NOT missing — value present but wrong)
```

The "config wrong value" class is high-priority: Kakak's history shows OpenClaw `streaming` config caused duplicate Telegram responses. Always check this class for daemon/agent bugs.

### Step 3 — Diagnose
```
Root cause: [specific line / config key / package]
Mechanism:  [one sentence why this causes the symptom]
Confidence: high / medium / low
```

If low confidence — ask for one more piece of evidence, don't guess.

### Step 4 — Resolve
```bash
# Exact command(s), no placeholders
```
Show real values, not `<your_token>`. Use Kakak's actual paths if known (`/root/.openclaw/...`).

### Step 5 — Verify
```bash
# Single command that proves it works
```

### Step 6 — Harden
```
# Config delta or test to prevent recurrence
```

---

## Common error patterns library

### Node / JS
- `Cannot find module` → missing install OR wrong cwd OR ES/CJS mismatch
- `MODULE_NOT_FOUND` after `npm i` → check `.bin` PATH or use `npx`
- `port already in use` → `lsof -i :PORT` then kill
- `EADDRINUSE` → previous process didn't exit, screen/tmux leftover
- `unexpected token` in import → CJS file importing ESM, change `.cjs` or `"type":"module"`

### Python
- `ModuleNotFoundError` after pip install → wrong venv OR `pip` ≠ `python` venv → use `python -m pip`
- `SSL: CERTIFICATE_VERIFY_FAILED` → corp proxy or stale certs → `pip install --trusted-host pypi.org`
- `RecursionError` → real bug OR `sys.setrecursionlimit` needed (rare)

### Telegram bot
- Duplicate responses → multiple instances running (`ps aux | grep node`) OR webhook + polling both active
- `409 Conflict` → another getUpdates poll running
- Bot stops responding silently → check for `polling_error` event handler, often unhandled rejection
- Markdown parse error → unescaped `_` `*` `[` characters

### Web3
- `nonce too low` → race condition, use NonceManager
- `replacement transaction underpriced` → bumping gas <10% above stuck tx
- `insufficient funds for gas` → forgot gas cost, not just transfer value
- RPC timeout → switch endpoint, primary down
- `execution reverted` no reason → call `eth_call` first to simulate and get revert string
- `signer connected to provider` warnings → use `wallet.connect(provider)` then `contract.connect(wallet)`

### VPS / Linux
- `Permission denied` on script → `chmod +x` OR shebang wrong OR running as wrong user
- `screen` session gone → server rebooted, use systemd instead for persistence
- Port not reachable externally → ufw or cloud firewall blocking
- `out of memory` killed → `dmesg | grep -i kill` confirms OOM, add swap or cap memory

### OpenClaw / Hermes specific
- Duplicate Telegram response → `streaming` config has invalid value, set proper boolean
- Provider auth fail → check both `ANTHROPIC_AUTH_TOKEN` and `ANTHROPIC_API_KEY`, conflict possible
- Skill not loading → wrong path in `~/.openclaw/workspace/openclaw-agents.json`
- Tool call hangs → security guardrail blocking obfuscated bash, simplify command

---

## Output format
```
[ROOT CAUSE] → [specific 1-line]
[FIX]        → [exact commands]
[VERIFY]     → [exact verify command]
[HARDEN]     → [prevention, optional]
```

If 100% sure → execute fix style.
If <100% sure → give probable cause + diagnostic command to confirm BEFORE fix.

Never "try this and see." Always ground recommendation in evidence.
