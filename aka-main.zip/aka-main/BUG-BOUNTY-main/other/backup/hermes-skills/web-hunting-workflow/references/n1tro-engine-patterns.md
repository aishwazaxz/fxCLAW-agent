# N1TRO Engine — B2B Gambling Platform Pattern

## Identification
- React SPA with `company=XXXXXX` query param in JS bundles
- External domains: `n1troengine.com` (API, WebSocket, CDN, LB)
- Manifest: `"name": "Create React App Sample"` (default CRA)
- Color config JS: `/lottery-n1tro1/colors/XXXX.js`

## Domain Pattern
```
API:        lotteryfoapi.n1troengine.com
WebSocket:  wss://lbfos.n1troengine.com
CDN:        lbstatic.n1troengine.com
LB:         lapp.n1troengine.com
```

## API Behavior
- Go (Fiber framework) backend
- All GET paths return `{"data":null,"err":"net/http: abort Handler","success":false}` (62 bytes)
- POST paths return `{"data":null,"err":"code=404, message=Not Found","success":false}` (66 bytes)
- Actual API endpoints use different route patterns (not discovered yet)

## Exploitation Approach
1. Extract `company=XXXXXX` from JS bundle URLs
2. Find all `*.n1troengine.com` subdomains
3. Check companion domains (mysterybox, moneysite, etc.)
4. Look for directory listings on companion domains
5. Check for source code leaks (.zip files on companion domains)

## Related Domain Enumeration
When you find a judol on N1TRO engine, search for:
- `site:*.org "unsurhoki"` (brand name)
- `site:*.pages.dev "unsurhoki"` (Cloudflare Pages)
- `site:*.cyou "unsurhoki"` (alternative domains)
- Check `misterybox*.org`, `moneysite-*.pages.dev` patterns

## Session Example (2026-06-01)
Target: unsurhokiuu.space
- Companion: misteryboxunsur.org → directory listing → lootbox.zip (12MB)
- lootbox.zip contained: full PHP source, DB credentials, SQLi vulns
- DB: backskos_misbox / ^eKPAoZrcsv@ / backskos_misbox (localhost only)
- SQLi payload: `' OR '1'='1` (use `#` comment, not `--`)
- Box opening bypassed without valid voucher
