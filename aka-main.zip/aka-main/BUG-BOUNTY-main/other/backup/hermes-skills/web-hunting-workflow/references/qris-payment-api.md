# QRIS Payment API Exploitation

## Endpoint
```
POST https://qris.otomatis.vip/api/generate
Content-Type: application/json
```

## Parameters
```json
{
  "username": "any_string",
  "amount": 50000,
  "uuid": "85dc56d4-583f-43d2-9484-cf66c33b18b1",
  "bonus": 0
}
```

## Key Findings (unsurhokiuu.space)

### No Username Validation
- Any username works (even "test", "admin", random strings)
- No check against gambling site's user database
- Impact: Can generate QR codes with any username

### Micro Payments Accepted
- Minimum in config: Rp 20,000
- Reality: Rp 1, Rp 10, Rp 100 all work
- Impact: Bypass minimum deposit limits

### Rotating Merchants
- Each transaction uses a different merchant
- Merchants: ASRUL INDAH MEDIKA, SENTRA GRAFIKA KREASI, YOSUA MODERN WEAR, etc.
- Impact: Avoids payment processor detection

### Fee Structure
- Config fee: Rp 3,500
- QR amount: Matches request (no fee in QR)
- Fee may be deducted from user's balance on the site

### Negative Bonus
- Negative bonus values (-10%, -50%, -100%) cause vendor errors
- Positive bonus values (10%+) also fail
- Bonus parameter is not exploitable

## UUID Discovery
The UUID is site-specific. Find it in:
1. Main page inline scripts: `uuidautodepo = "xxx"`
2. Config file: `https://iframe15.otomatis.vip/data/{uuid}.txt`
3. The config file is base64-encoded JSON

## Related Domains
- `iframe15.otomatis.vip` — Script hosting
- `qris.otomatis.vip` — Payment API
- `*.otomatis.vip` — Various services

## Detection
Look for scripts loading from `otomatis.vip` or `analyticpro.online` in the page source. These indicate the site uses the same payment infrastructure.
