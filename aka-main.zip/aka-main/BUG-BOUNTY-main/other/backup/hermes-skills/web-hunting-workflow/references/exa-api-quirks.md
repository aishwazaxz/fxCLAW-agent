# Exa API Quirks

## Search Method (as of 2026)
```python
from exa_py import Exa
exa = Exa(api_key=os.environ['EXA_API_KEY'])

# WORKS:
results = exa.search("query", num_results=5)

# BROKEN (removed in newer versions):
# results = exa.search("query", num_results=5, use_autoprompt=True)
# results = exa.search("query", num_results=5, text=True, highlights=True)
# results = exa.search("query", num_results=5, text={"maxCharacters": 500})
```

The `use_autoprompt` parameter was removed. If you get:
```
Exa.search() got an unexpected keyword argument 'use_autoprompt'
```
Just remove the parameter.

The `text` and `highlights` parameters were also removed (as of 2026-06). If you get:
```
Exa.search() got an unexpected keyword argument 'text'
```
Just use `exa.search(q, num_results=N)` without any text/highlights params. The results object has `.title` and `.url` but `.text` may be None.

## API Key Loading
The EXA_API_KEY must be in environment. Load from .env:
```bash
source ~/.hermes/.env 2>/dev/null
# or in Python:
with open(os.path.expanduser('~/.hermes/.env')) as f:
    for line in f:
        if line.strip().startswith('EXA_API_KEY=') and not line.strip().startswith('#'):
            os.environ['EXA_API_KEY'] = line.strip().split('=', 1)[1]
```

## Effective Search Queries for Target Discovery
```
# Login panels on low-security TLDs
site:.xyz login admin panel database
site:.top login register user management
site:.icu admin dashboard login
site:.pw admin login database

# CMS-specific
inurl:admin/login.php site:.xyz OR site:.top
inurl:wp-login.php site:.xyz OR site:.top
inurl:phpmyadmin site:.xyz OR site:.top

# Exposed files
filetype:sql site:.xyz OR site:.top
filetype:env site:.xyz OR site:.top
intext:"DB_PASSWORD" filetype:env site:.xyz
```
