# Catch-All SPA Detection & Directory Listing Exploitation

## Catch-All SPA Detection (CRITICAL)

Many gambling sites serve the same SPA page for ALL paths. This causes false positives.

### Detection Method
```python
# Get main page size
r_main = requests.get(target, timeout=10)
main_size = len(r_main.text)

# Get random nonexistent path
r_test = requests.get(f"{target}/nonexistent_check_12345", timeout=5)
test_size = len(r_test.text)

# If sizes are similar, it's catch-all
is_catchall = abs(test_size - main_size) < 300
```

### Red Flags
- `.env` returns 200 with same size as main page
- `.git/HEAD` returns 200 with same size as main page
- ALL paths return 200 with ~same size
- Page title is generic ("Home", "Login", etc.)

### Real vs Fake
- **REAL**: `.env` contains `DB_PASSWORD=`, `APP_KEY=`
- **REAL**: `.git/HEAD` contains `ref: refs/heads/`
- **FAKE**: `.env` returns full HTML page (same as main)
- **FAKE**: `.git/HEAD` returns full HTML page (same as main)

## Directory Listing Exploitation

### Finding Directory Listings
```bash
# Check common paths
for path in "" "files/" "backup/" "db/" "uploads/" "data/" "config/" "assets/"; do
  curl -s "https://target/$path" | grep -i "index of\|parent directory"
done
```

### What to Look For
1. **Source code** (.php, .py, .js, .zip, .tar.gz)
2. **Config files** (.env, config.php, .json, .yaml)
3. **Database backups** (.sql, .db, .sqlite)
4. **Error logs** (error_log, debug.log)
5. **Backup files** (.bak, .old, .save, .orig)

### Exploitation Flow
1. Find directory listing
2. Download all interesting files
3. Search for credentials in config files
4. Check error logs for file paths and credentials
5. Analyze source code for SQLi, file upload, etc.

## Session Example (2026-06-01)
- misteryboxunsur.org → directory listing → lootbox.zip (12MB)
- lootbox.zip contained:
  - inc/config.php (DB credentials)
  - admin/login.php (SQLi in username)
  - admin/vouchers.php (SQLi in all queries)
  - admin/rewards.php (unrestricted file upload)
  - error_log (883KB, file path disclosure)
