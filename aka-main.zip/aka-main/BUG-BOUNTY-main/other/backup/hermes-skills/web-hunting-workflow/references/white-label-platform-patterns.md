# White-Label Gambling Platform Patterns

## Known Platforms

### ambengine.com
- B2B gambling platform provider
- Used by: unsurhoki, zeus222, and many others
- Game engine for slots, live casino, sports
- Detection: `ambengine.com` in page source or JS files

### choice-gaming.com
- Gaming platform
- "CHOICE GAMING Master Tournament"
- Detection: `choice-gaming.com` in page source

### N1TRO Engine
- API: `lotteryfoapi.n1troengine.com`
- WebSocket: `wss://lbfos.n1troengine.com`
- CDN: `lbstatic.n1troengine.com`
- Load balancer: `lapp.n1troengine.com`
- Detection: `n1troengine.com` domains in page source
- Go-based backend (net/http)

### IGN/NXB Platform
- Image CDN: `api2-ign.imgnxb.com`
- APK hosting: `apk-depot.s3.ap-northeast-1.amazonaws.com`
- Detection: `imgnxb.com` in image URLs

## Attack Surface Consistency
Sites using the same platform share:
- Same API endpoints
- Same authentication flow
- Same payment infrastructure
- Same vulnerability patterns

If you find SQLi on one site using platform X, check ALL other sites using platform X.

## Platform Detection
```bash
# Check page source for platform indicators
curl -s "https://target" | grep -i "ambengine\|choice-gaming\|n1troengine\|imgnxb\|otomatis\|analyticpro"

# Check JS files
curl -s "https://target" | grep -oP 'src="[^"]*\.js[^"]*"' | grep -i "otomatis\|analyticpro\|n1tro"
```

## Companion Domain Enumeration
When you find a gambling site, search for related domains:
1. Check page source for external domains
2. Search Exa for "site:*.tld brand_name"
3. Check DNS records for shared infrastructure
4. Look for APK downloads on S3/CDN

## Supply-Chain Script Injection
Many gambling sites load external scripts for deposit flow:
- `otomatis.vip` — QRIS payment scripts
- `analyticpro.online` — Deposit overlay scripts
- `onechat.dev` — Chat integration

These scripts often have access to:
- User session data
- Deposit amounts
- Payment flow
- Can be compromised to steal funds
