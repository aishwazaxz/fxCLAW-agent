# Git History Sanitization — Remove Leaked API Keys

When API keys, passwords, or secrets get committed to git history, use `git-filter-repo` to rewrite history before pushing.

## Install
```bash
pip install git-filter-repo
```

## Remove Hardcoded Key from All Commits

```bash
# Replace key value with placeholder across ALL commits
git filter-repo --replace-text <(echo 'ACTUAL_KEY_VALUE==>REDACTED_KEY_NAME') --force
```

This rewrites ALL commits in history. The `--force` flag is required when the repo has been pushed before.

## After filter-repo

```bash
# filter-repo removes the remote (safety measure)
git remote add origin https://github.com/USER/REPO.git

# Force push (history changed, must force)
git push --force origin main
```

## Fix Source Files

After filter-repo, files contain `REDACTED_KEY_NAME` literal strings. Replace with env reads:

**Python:**
```python
import os
API_KEY=os.environ.get('API_KEY', open(os.path.expanduser('~/.api_key')).read().strip() if os.path.exists(os.path.expanduser('~/.api_key')) else '')
```

**Bash:**
```bash
API_KEY="${API_KEY:-$(cat ~/.api_key 2>/dev/null)}"
```

## Verification

```bash
# Check no keys remain in tracked files
grep -rn 'ACTUAL_KEY_VALUE' --include='*.py' --include='*.sh' .

# Check no keys in git history
git log --all -p -S 'ACTUAL_KEY_VALUE' --oneline

# Check .gitignore includes key files
grep '.env\|.key' .gitignore
```

## Pitfalls

- **filter-repo removes remote** — Always re-add remote after running
- **Large repos** — Push may timeout. Use generous timeout.
- **Already pushed** — Key may exist in GitHub cache or forks. Regenerate the key after sanitizing.
- **Multiple keys** — Pass multiple lines to replace-text.
- **grep truncation** — `grep` output may truncate long key values. Use `python3 -c "print(repr(line))"` to see full strings.
