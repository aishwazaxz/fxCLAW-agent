# Cashmarket API Platform (BK8-class gambling sites)

## Platform Characteristics
- **Backend**: Spring Boot (Java) — NOT PHP/Laravel like most judol
- **Frontend**: React SPA (v19.x) — catch-all 200 on all paths
- **WAF**: Cloudflare with Turnstile CAPTCHA
- **API prefix**: `/cashmarket/api/v3/` (member), `/campaign/api/v2/` (campaigns)
- **Merchant system**: numeric codes (001, etc.) used in all API calls
- **Version string**: visible in CSS/JS paths (e.g., `10.5.29b`)
- **Chatbot**: Forethought AI (solve-widget.forethought.ai)
- **Live Chat**: Comm100 / LiveChatAPI

## Detection
```bash
# Check for Cashmarket API
curl -sk 'https://target/cashmarket/api/v3/public/settings/GENERAL?currencyCode=IDR'

# Check for Spring Boot error format
curl -sk 'https://target/api/v3/member/login' -X POST -d '{}'
# Spring Boot returns: {"timestamp":"...","status":403,"error":"Forbidden","path":"/api/v3/member/login"}
```

## Public API Endpoints (No Auth Required)

| Endpoint | Data Leaked |
|----------|-------------|
| `/cashmarket/api/v3/public/settings/GENERAL?currencyCode=X` | Feature flags (seamless wallet, VIP, lucky wheel) |
| `/cashmarket/api/public/auth-setting/LOGIN?isNew=true&currencyCode=X` | Login config: maxLoginAttempt, Turnstile rules, bypass_app flag |
| `/cashmarket/api/public/auth-setting/REGISTER?isNew=true&currencyCode=X` | Registration requirements, verification types |
| `/cashmarket/api/public/cloudflare-turnstile-setting` | Turnstile site_key |
| `/cashmarket/api/public/validate-affiliate-parameter?affId=X&...` | Affiliate codes, campaign IDs, currency |
| `/cashmarket/api/public/check-seamless-enable?merchantCode=X&currency=Y` | Seamless wallet enabled (true/false) |
| `/cashmarket/api/public/forethought-script?merchantCode=X&language=Y&platform=web` | **Forethought AI API key** (data-api-key) |
| `/cashmarket/api/public/angpow-rain-settings?language=X&currencyCode=Y` | Angpow/red envelope rain settings |
| `/campaign/api/v2/p/lucky-wheel/v2/lucky-wheel-setting-detail?merchantCode=X&currency=Y` | Lucky wheel prizes, deposit conditions, **admin usernames** (createdBy field) |

## Static Config Files (No Auth)

| Path | Data |
|------|------|
| `/public/html/settings/bank-name.json` | All payment processors (50+), bank codes |
| `/public/html/contact.json` | Telegram channels, LiveChat URLs, social media per locale |
| `/public/html/scripts/website-settings.json` | Favicon, logo, video URLs, CMS images |
| `/public/html/settings/menu-settings.json` | Game providers, menu ordering, hidden games |
| `/public/html/settings/custom-route-settings.json` | All SPA routes, account page structure |
| `/public/html/default_whitelabel/settings/base-route-settings.json` | Full route config with component paths |
| `/public/html/default_whitelabel/settings/flagsmith.json` | Feature flags, deposit prevention flags |
| `/public/html/settings/account-page-settings.json` | Account page structure |
| `/public/html/provider_maintenance/provider_maintenance_IDR.json` | Provider maintenance status |
| `/public/html/scripts/announcement.json` | Active announcements |
| `/public/html/settings/floating-notification-before-login.json` | Pre-login notifications |
| `/public/html/settings/custom-menu.json` | Custom menu overrides |
| `/public/html/settings/provider-currency-menu-settings-custom.json` | Per-currency provider settings |

## Auth Flow Analysis
- **Cloudflare Turnstile** CAPTCHA after N failed attempts (typically 2)
- Login/Register API returns **403 from curl** — requires proper browser headers + CSRF
- `bypass_app: enabled` in auth settings — potential bypass vector
- `maxLoginAttempt: 2` before Turnstile kicks in
- Verification types: `CLOUDFLARE_TURNSTILE`
- Auth settings endpoint reveals `bypass_app` flag — always check this

## Forethought AI Chatbot Deep Dive

### Auth Mechanism (reverse-engineered from embed.js)
The Forethought widget uses `Authorization: Bearer *** — NOT a custom header. The API key is passed as `data-api-key` in the script tag.

```bash
# Test auth (should return 422 = auth OK, body wrong)
curl -sk -X POST 'https://solve-api.forethought.ai/workflow/widget-config' \
  -H 'Authorization: Bearer *** \
  -H 'Origin: https://<target>' \
  -H 'solve-origin: https://<target>' \
  -H 'solve-release: production_v1.7.1087_1_7962696' \
  -d '{}'
# 422 = "request validation error" → auth PASSED, body format wrong
# 401 = "Unauthenticated" → bad key
# 403 = "Invalid permissions" → origin mismatch (key is origin-locked)
```

### Origin Validation
Forethought validates the `Origin` header against the registered domain:
- Correct origin → 422 (auth OK, body format issue)
- Wrong origin (evil.com) → 403 "Invalid permissions"
- No origin → 403 "Invalid permissions"

### Available Forethought API Endpoints (from embed.js reverse engineering)
```
# Widget-level (no version prefix)
POST /workflow/widget-config          # Widget configuration
POST /workflow/tracking-event         # Analytics tracking
POST /workflow/upload-file            # File upload (!)

# Conversation-level (tw="workflow/v2")
POST /workflow/v2/conversation                          # Init conversation
GET  /workflow/v2/conversation/{id}/archive-components  # Get components
PUT  /workflow/v2/conversation/{id}/free-form-query     # Send message
POST /workflow/v2/conversation/{id}/search-knowledge    # Search KB (!)
POST /workflow/v2/conversation/{id}/send-conversation-alert
PUT  /workflow/v2/conversation/{id}/send-conversation-feedback
POST /workflow/v2/conversation/{id}/submit-intent-csat
POST /workflow/v2/conversation/{id}/continue-autoflow-intent
GET  /workflow/v2/conversation/{id}/oauth/{credId}/status

# Autonomous agent (tw="workflow/v3")
POST /workflow/v3/conversation                        # Init agent conversation
PUT  /workflow/v3/conversation/{id}/autonomous-agent-query

# Live chat
POST /live-chat/v1/conversation/{id}/send-message
POST /live-chat/v1/conversation/{id}/end
PUT  /live-chat/v1/conversation/{id}/resolve
DELETE /live-chat/v1/conversation/{id}
```

### Widget URL Structure
The widget loads in an iframe with all config in the URL hash:
```
https://solve-widget.forethought.ai/?v=2#data-api-key=<KEY>&data-ft-embed-script-language=id&data-ft-region=ID&data-ft-platform=web&data-ft-domain-address=<domain>
```

### Impact
- Widget-level key (not admin), but exposes support bot to abuse
- `/workflow/upload-file` endpoint could be exploitable for file upload
- `/workflow/v2/conversation/{id}/search-knowledge` could leak internal KB data
- Combined with XSS on target domain = full support bot abuse
- Origin validation mitigates external abuse, but key exposure is still unnecessary

## Campaign API Endpoint Map

Cashmarket platforms use `/p/` for public and `/s/` for secured (auth-required):

### Public (no auth)
```
GET /campaign/api/v2/p/lucky-wheel/v2/lucky-wheel-setting-detail
GET /campaign/api/v2/p/match-prediction/image
```

### Secured (JWT required) — return CPN30000 without auth
```
POST /campaign/api/v2/s/lucky-wheel/v2/spin          # Spin the wheel
GET  /campaign/api/v2/s/lucky-wheel/v2/winner-list    # Winner list
GET  /campaign/api/v2/s/lucky-wheel/v2/history        # Spin history
GET  /campaign/api/v2/s/lucky-wheel/v2/eligibility    # Check eligibility
GET  /campaign/api/v2/s/lucky-wheel/v2/member-status  # Member status
GET  /campaign/api/v2/s/lucky-wheel/v2/prize-list     # Prize list
POST /campaign/api/v2/s/match-prediction/predict      # Make prediction
GET  /campaign/api/v2/s/match-prediction/info          # Prediction info
GET  /campaign/api/v2/s/match-prediction/list          # Prediction list
GET  /campaign/api/v2/s/match-prediction/history       # Prediction history
POST /campaign/api/v2/s/angpow-rain/claim              # Claim angpow
GET  /campaign/api/v2/s/angpow-rain/settings           # Angpow settings
GET  /campaign/api/v2/s/referral/info                  # Referral info
GET  /campaign/api/v2/s/referral/validate              # Validate referral
GET  /campaign/api/v2/s/bonus/list                     # Bonus list
POST /campaign/api/v2/s/bonus/claim                    # Claim bonus
POST /campaign/api/v2/s/deposit/submit                 # Submit deposit
POST /campaign/api/v2/s/withdrawal/submit              # Submit withdrawal
GET  /campaign/api/v2/s/member/profile                 # Member profile
GET  /campaign/api/v2/s/member/wallet                  # Wallet balance
```

### Campaign API Error Format
```json
{"code":"CPN30000","message":"Full authentication is required to access this resource","timestamp":"...","data":null,"traceId":"..."}
```

## Lucky Wheel Analysis

### Key Settings Exposed
- `isFakeWinnerListEnabled=true` — platform FAKES winner lists to lure users
- Most prizes have `duplicateMemberCheckEnabled=false` — repeat exploit possible
- `maxReward=null` on all prizes — no reward cap visible
- `eligibilityType="X"` — unknown type, may be exploitable
- `createdBy` / `lastModifiedBy` fields expose admin usernames

### Prize Types
- `ACTIVITY_POINT` — activity points reward
- `FIXED_BONUS_REWARD` — fixed cash bonus (e.g., Rp 5, Rp 100, Rp 5000)
- `SPECIAL` — special prizes (e-wallet balance, freebets)

### Duplicate Check
Some prizes have `duplicateMemberCheckEnabled=true` with `duplicateMemberCheckDays=N`. Others have it set to false — these are prime targets for repeat exploitation once authenticated.

## XHR Endpoint Discovery via Browser Console
For SPAs that load APIs dynamically, use the browser console:
```javascript
performance.getEntriesByType('resource')
  .filter(r => r.initiatorType === 'xmlhttprequest' || r.initiatorType === 'fetch')
  .map(r => r.name)
  .filter(u => u.includes('target-domain'))
```
This captures ALL XHR/fetch calls made during page load — much more reliable than guessing endpoints.

## Locale/Currency Matrix
Cashmarket platforms support multiple locales. Each locale may have different contact channels, payment processors, game providers, and promotions.

Test with: `ID_ID`, `EN_MY`, `MS_MY`, `TH_TH`, `VI_VN`, `ZH_SG`, `EN_KH`, `KM_KH`, `TL_PH`

## Pitfalls
- **403 from curl ≠ endpoint doesn't exist** — Spring Boot endpoints require browser-like headers. Use browser or set proper Origin/Referer/x-requested-with headers.
- **Catch-all 200** — SPA returns 200 for ALL paths. Always verify response content, not status code. Compare with baseline `/xyznonexistent123`.
- **Cloudflare bot protection** — `__cf_bm` cookie required. curl without proper headers gets blocked. Use browser for initial session, then extract cookies.
- **Turnstile vs reCAPTCHA on registration** — Auth settings API says `CLOUDFLARE_TURNSTILE` but registration page may actually use **reCAPTCHA v2 invisible** (`size=invisible` in iframe src). Always check actual iframe `src` attribute: `iframe[src*="recaptcha"]` = reCAPTCHA, `iframe[src*="turnstile"]` = Turnstile. The reCAPTCHA sitekey is in the anchor URL: `k=<SITEKEY>`. Example BK8 uses reCAPTCHA sitekey `6LfG15waAAAAABRHsid0K9NosEx8i2uxdj-svwpu` on registration despite API reporting Turnstile.
- **React controlled inputs block automation** — React SPA registration forms use controlled inputs (`value` managed by React state). `browser_type` tool doesn't trigger React's synthetic events, so typed text doesn't persist. Setting value via `Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set` also fails because React re-renders. Workaround: use Playwright's `page.fill()` which fires proper input events, or intercept the API call directly with a valid reCAPTCHA token from a real browser session.
- **Turnstile bypass** — Don't waste time trying to bypass Turnstile/reCAPTCHA programmatically. Focus on endpoints that don't require it (public APIs, static configs).
- **Merchant code is NOT secret** — It's embedded in every API call and static config. Treat it as public knowledge.
- **Spring Boot error format** — `{\"timestamp\":\"...\",\"status\":N,\"error\":\"...\",\"path\":\"...\"}` is Spring Boot default. Don't confuse with application-level errors.
- **Campaign API /p/ vs /s/ naming** — `/p/` = public (no auth), `/s/` = secured (JWT required). Always enumerate both prefixes.
- **Forethought origin validation** — API key is origin-locked. Must test from target domain context (browser or matching Origin+Referer headers).
- **Lucky wheel fake winners** — `isFakeWinnerListEnabled=true` means displayed winners are fabricated. Don't report "winner list exposed" without verifying real user data.
- **delegate_task timeout on browser recon** — Browser-based recon with multiple page loads often exceeds subagent timeouts. Do browser work directly in main session.
