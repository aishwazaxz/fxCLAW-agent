# Forethought AI Widget Reverse Engineering

## Overview
Forethought AI (forethought.ai) is a customer support chatbot widget used by many gambling/e-commerce sites. The widget API key is embedded in the frontend script tag and can be extracted from public endpoints.

## Key Extraction
```bash
# Many Cashmarket sites expose the key via this endpoint
curl -sk 'https://target/cashmarket/api/public/forethought-script?merchantCode=001&language=ID_ID&platform=web'
# Returns HTML script tag with data-api-key="UUID"
```

## Auth Mechanism
The API key is used as a **Bearer token** (NOT a custom header):
```
Authorization: Bearer <api-key>
```

This was determined by reverse-engineering the minified `embed.js`:
- Search for `this.headers` initialization
- Look for `"Bearer ".concat(n)` pattern where `n` is the apiKey parameter

## API Base
```
https://solve-api.forethought.ai
```

## Origin Validation Behavior
Test with different Origin headers to confirm origin-locked behavior:

```bash
# Correct origin → 422 (auth OK, body format wrong)
curl -sk -X POST 'https://solve-api.forethought.ai/workflow/widget-config' \
  -H 'Authorization: Bearer *** \
  -H 'Origin: https://target.com' \
  -H 'solve-origin: https://target.com' \
  -d '{}'

# Wrong origin → 403 (auth rejected by origin check)
curl -sk -X POST 'https://solve-api.forethought.ai/workflow/widget-config' \
  -H 'Authorization: Bearer *** \
  -H 'Origin: https://evil.com' \
  -H 'solve-origin: https://evil.com' \
  -d '{}'
```

Response codes:
- **422** "request validation error" = Auth PASSED, body format wrong
- **401** "Unauthenticated" = Bad/invalid API key
- **403** "Invalid permissions" = Origin mismatch (key is origin-locked)

## Required Headers
```
Authorization: Bearer <api-key>
Content-Type: application/json
Origin: https://<target-domain>
Referer: https://<target-domain>/<path>
solve-origin: https://<target-domain>
solve-release: production_v1.7.1087_1_7962696  (version from embed.js)
```

## Widget URL Structure
```
https://solve-widget.forethought.ai/?v=2#data-api-key=<KEY>&data-ft-embed-script-language=<lang>&data-ft-region=<region>&data-ft-platform=web&data-ft-domain-address=<domain>
```

## Reverse Engineering embed.js
The minified embed.js (~220KB) contains:

### Route Definitions
```javascript
// Widget routes (no version prefix)
tg = {
  "tracking-events": {method:"post", url:"/workflow/tracking-event"},
  "upload-file": {method:"post", url:"/workflow/upload-file"},
  "widget-config": {method:"post", url:"/workflow/widget-config"}
}

// Conversation routes (tw="workflow/v2")
tm = {
  "init-intent-conversation": {method:"post", url:"/workflow/v2/conversation"},
  "search-knowledge": {method:"post", url:"/workflow/v2/conversation/{conversationId}/search-knowledge"},
  "send-free-form-query": {method:"put", url:"/workflow/v2/conversation/{conversationId}/free-form-query"},
  // ... more routes
}
```

### Key Patterns to Search For
- `this.headers` — finds auth header construction
- `this.routes` — finds all API route definitions
- `Authorization: Bearer` — confirms auth mechanism
- `tw=` — finds API version prefix (e.g., `tw="workflow/v2"`)
- `ty=` — finds autonomous agent version prefix
- `tS=` — finds live chat version prefix

## Impact Assessment
- Widget key is designed to be public-facing (embedded in HTML)
- But exposure via API endpoint is unnecessary and risky
- Origin validation mitigates direct external abuse
- Key can be abused from target domain context (XSS → full bot abuse)
- `/workflow/upload-file` endpoint is particularly risky
- `/workflow/v2/conversation/{id}/search-knowledge` can leak internal knowledge base
