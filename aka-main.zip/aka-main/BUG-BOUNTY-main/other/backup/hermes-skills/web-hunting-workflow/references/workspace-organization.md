# Workspace Organization

User preference: tools and findings MUST be in separate, clean folders.
Root should be CLEAN — only config files (.env, API keys) and README.md.

## Canonical Structure

```
BUG-BOUNTY/
├── .env                      # API keys (gitignored)
├── .bscscan_key              # BSCScan key (gitignored)
├── .gitignore
├── README.md                 # Minimal — quick start only
│
├── tools/
│   ├── onchain/              # Smart contract & DeFi hunting
│   │   ├── pipeline.sh       # Main BSC pipeline
│   │   ├── audit_gate.sh     # Quality gate (hakim akhir)
│   │   ├── confidence_scorer.py
│   │   ├── bscscan_*.py/sh   # BSCScan queries
│   │   ├── contract_interaction/
│   │   ├── exploit_suite/    # Foundry templates
│   │   ├── testnet/          # Testnet playground
│   │   └── README.md         # Index of onchain tools
│   ├── web/                  # Web app hunting
│   │   ├── web_hunter.py     # Target discovery
│   │   ├── sqlmap-dev/       # SQLi tool
│   │   └── hydra.restore     # Session file (gitignored)
│   ├── GUIDE-*.md            # Guides colocated with tools
│   └── README.md             # Master index of ALL tools
│
├── findings/                 # Smart contract findings & PoC
│   ├── findings.md
│   └── Finding*_PoC.t.sol
│
├── recon/                    # Web recon results (per-target)
│   ├── bk8reg10/
│   └── defillama/            # Large data dumps (gitignored)
│
├── targets/                  # Target contract sources
├── moneyfi_poc/              # Standalone PoC projects
└── kairo/                    # Separate project (gitignored if own repo)
```

## Rules
- Tools = reusable scripts, NEVER mixed with findings/output
- Findings = output data, NEVER mixed with tools
- Guides → tools/ folder (GUIDE-*.md prefix), NOT project root
- Per-target data → recon/<target_name>/ or findings/
- Large JSON dumps (>5MB, DeFiLlama etc.) → recon/ subfolder, gitignore
- README.md in tools/ is mandatory (index of all tools)
- Separate repos (kairo/) → .gitignore

## Security Checklist Before Push
ALWAYS verify before `git push`:
```bash
# 1. Check for hardcoded API keys
grep -rn 'API_KEY\|api_key\|apikey\|secret\|password\|bearer\|0x[a-fA-F0-9]{40,}' \
  --include='*.py' --include='*.sh' --include='*.md' tools/ targets/ findings/ | \
  grep -v 'os.env\|getenv\|expanduser\|\${\|cat.*key\|REDACTED'

# 2. Check .gitignore covers secrets
cat .gitignore | grep -E 'env|key|secret'

# 3. Verify staged files
git diff --cached --name-only | grep -iE '\.env|key|token|secret|password'
```

## When Secrets Get Pushed (Emergency)
If API keys/passwords were already pushed to remote:
```bash
# 1. Install git-filter-repo
pip install git-filter-repo

# 2. Replace secret in ALL commits
git filter-repo --replace-text <(echo 'HARDCODED_SECRET==>REDACTED')

# 3. Re-add remote (filter-repo removes it)
git remote add origin https://github.com/user/repo.git

# 4. Force push (rewrites history)
git push --force origin main

# 5. Fix REDACTED placeholders in files to read from env/file
# Replace REDACTED strings with os.getenv() or file reads
```
**IMPORTANT**: After force push, the old secret is STILL in GitHub's cache for ~90 days. Regenerate the key immediately.

## When Restructuring
1. Create .gitignore FIRST (before any git add)
2. Move tools, verify paths work
3. Grep ALL skill files for old paths: `grep -r "old/path" ~/.hermes/skills/ --include='*.md' -l`
4. Update skill references (patch old → new paths)
5. Create/update README.md for tools/
6. Run security checklist above
7. Clean up __pycache__ and empty dirs
8. Commit and push
