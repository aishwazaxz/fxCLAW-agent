# Mobile Game Reverse Engineering Patterns

## Cocos2d-JS Games (e.g., Rock N Cash, VT38)

Framework: `we.core` namespace with `serverMgr`, `networkMgr`, `userMgr`

### Key Objects
- `we.core.serverMgr.getHallHost()` → Hall API URL
- `we.core.serverMgr.getNamingWs()` → WebSocket URL with JWT
- `we.common.userMgr.userInfo` → User data (userId, userName, gold, diamond)
- `we.common.userMgr.token` → Auth token
- `we.common.bankMgr.bankConfig` → Banking config
- `we.GameId` → Game ID enum (100+ games)

### Remote Config
- `GET /projectConfig` → Server config (GATE_HOST, GATE_PORT, SCRIPT_BASEURL, ASSET_BASE_URL)
- Scripts loaded from CDN (CloudFront usually)
- CDN often blocks direct access (need browser context)

### Auth Flow
1. FB.init() → Facebook SDK
2. FB.getLoginStatus() → get accessToken
3. Game connects to gate server via WebSocket with token
4. WebSocket path is custom (not discoverable without intercepting)

### localStorage Data
Key: `we:sys` contains:
- user_id, user_token, app_device_id
- app_domain_list, zone_domain_list
- app_bundle_local_version

### Limitation
- Facebook OAuth required for web version
- Cannot set FB cookies from JavaScript (third-party cookie blocking)
- CDN scripts blocked from non-origin contexts
- WebSocket path not discoverable without live traffic capture

## Unity Games (e.g., Neo Domino QQ)

### Key Files
- `assets/bin/Data/Managed/Metadata/global-metadata.dat` — All C# strings
- `assets/google-services.json` — Firebase config
- `assets/build_info.txt` — Build machine + date

### API Protocol
- Often uses Protobuf (binary) or MessagePack
- Error format: `{"En": N}` where N is error code
- Login via POST with binary body

### Firebase Extraction
```bash
unzip -p target.apk assets/google-services.json | python3 -m json.tool
```

## General APK Analysis

```bash
# Decompile with jadx
jadx -d jadx_out target.apk --no-res

# Extract strings from SO
strings lib/arm64-v8a/lib*.so | grep -i "http\|api\|server\|login"

# Find API endpoints in DEX
find jadx_out -name "*.java" | xargs grep -l "http\|api\|socket"

# Extract Firebase config
unzip -p target.apk assets/google-services*.json 2>/dev/null
unzip -p target.apk res/values/strings.xml | grep -i firebase
```
