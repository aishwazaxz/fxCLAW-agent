# ONIX Gambling Platform Patterns

## Detection
ONIX is a common B2B gambling platform used by Indonesian judol sites (Jangkar55, etc.).

**Indicators:**
- jQuery + Bootstrap + SweetAlert2 frontend
- Laravel PHP backend
- Cloudflare WAF (usually)
- Forms: `_token` (CSRF), `register_token`, `stage_val`
- Agent code in meta tags or page content
- Currency: IDR, Country code: 62
- LiveChat via livechatinc.com
- CDN: sitestatic.net / cdn.sitestatic.net

**Key difference from other platforms:** NOT a SPA catch-all — each path returns different content with different sizes. Baseline filtering still needed but less false positives.

## API Endpoints (Laravel Routes)

### Public (No Auth)
| Endpoint | Method | Response |
|----------|--------|----------|
| `/checkExistingEmail` | POST | Full page HTML (NOT true/false!) — dynamic content varies ±500 bytes |
| `/checkExistingUser` | POST | 1461 bytes always (no enumeration) |
| `/getPokerJackpotAmt` | POST | Poker jackpot amount (e.g. Rp 35.8 Milyar) |
| `/getHKBLotteryResults` | POST | 12 lottery games results |
| `/captcha-image-forgotpw` | GET | Captcha image (may be static!) |

### Auth-Required
| Endpoint | Method | Notes |
|----------|--------|-------|
| `/validate-pin` | POST | 6-digit PIN, fields: `pincode[0]`..`pincode[5]` |
| `/validate-2fa` | POST | 6-digit OTP, fields: `pincode[1]`..`pincode[6]`, needs 2FA session token |
| `/fpw-verify-otp` | POST | Forgot password OTP, fields: `otp_pincode[1]`..`otp_pincode[6]` |
| `/submitregister` | POST | Registration with stage control |
| `/login` | POST | Standard login |
| `/apply-resetpwd` | POST | Password reset |
| `/authViaIdp` | POST | Firebase IDP auth |

## Registration Form Fields
```
hidden:  stage_val (1=bank, 2=?, 3=final)
hidden:  _token (CSRF)
hidden:  register_token (CS2ABA0-timestamp-hash)
hidden:  contact_country (62)
hidden:  isRegHasBank (1=bypass bank)
text:    user_name (REQUIRED)
password: password (REQUIRED)
password: password_confirm (REQUIRED)
email:   email (REQUIRED)
tel:     mobile_no (REQUIRED)
text:    ref_code (optional)
text:    acc_name (bank account name)
radio:   method (5=bank, 7=e-wallet)
select:  bank_name (50 banks: BCA, BJB, BRI Syariah, Sumsel...)
select:  bank_name (11 e-wallets: DANA, OVO, LINKAJA, GOPAY...)
tel:     acc_no (bank account number)
captcha: captcha
checkbox: terms
```

**Honeypot fields:** Random names like `OoJQUIdDqbhrobEvrsx`, `CMxjEkUhiePr`, `nIwwuGVm` — DO NOT fill these.

## False Positive Patterns

### /checkExistingEmail Size Variation
**WRONG:** "Response size differs = email exists/doesn't exist"
**RIGHT:** Size differences are from DYNAMIC content in the full page response:
- Timestamps change every request (`02/06/2026 10:54:1 am` → `10:54:4 am`)
- Poker jackpot amount fluctuates (`35,887,855,561` → `35,887,855,322`)
- Captcha URL has timestamp parameter (`?v=1780397637` → `?v=1780397641`)
- Visitor counters change (`207,466` → `196,182`)

**How to verify:** Send 5 requests with the SAME email. If sizes vary ±500 bytes = dynamic content, NOT enumeration.

### /checkExistingUser
Always returns exactly 1461 bytes regardless of username. No enumeration possible.

## Staging URL Patterns
ONIX sites often have staging environments exposed in their APK:
- Pattern: `{prefix}.web-sample.live` (e.g. `stg3mplay.web-sample.live`)
- Pattern: `{prefix}.8882928.com` (e.g. `tec188idrstg.8882928.com`)
- Both are Laravel, may have `/register` accessible
- Staging titles: "stagging NS V1", "TEST"
- `.env` redirects to homepage (not exposed)
- `/cashmarket/`, `/campaign/`, `/admin/` paths exist but redirect to homepage

## APK Analysis (Flutter/Dart)
ONIX mobile apps are built with Flutter, which compiles Dart to native code in `libapp.so`.

**Key extraction:**
```bash
# Extract APK
unzip -o target.apk -d target_extracted/

# All hardcoded strings in Flutter binary
strings target_extracted/lib/arm64-v8a/libapp.so | grep 'https://' | sort -u

# SharedPreferences keys (reveals what tokens are stored)
strings target_extracted/lib/arm64-v8a/libapp.so | grep -E '^prefs[A-Z]' | sort -u

# Firebase config
strings target_extracted/lib/arm64-v8a/libapp.so | grep -iE 'firebase|firestore|fcm'
```

**Common SharedPreferences keys found:**
- `prefsCsrfToken` / `prefsXsrfToken` — CSRF token (plaintext!)
- `prefsLaravelToken` — Laravel session token (plaintext!)
- `prefsFireXApiKey` — API key
- `prefsFireDkey` — Encryption/signing key
- `prefsSecondPin` — Second PIN stored locally
- `prefsAgentId` / `prefsAgentUrl` / `prefsWebUrl` — Agent config
- `prefsFireBaseUrl` — Firebase database URL
- `prefsFireApkUrl` — Firebase APK URL

## Firebase Config Leak (CRITICAL)
ONIX apps use Firebase RTDB for mobile app config. Many deployments leave the database OPEN (no auth rules).

**Discovery path:** APK strings → `prefsFireBaseUrl` → Firebase project ID → check RTDB

**Known open database:**
```
https://api-onix-ns2-live2-default-rtdb.firebaseio.com/.json
```

**Multi-app pattern:** One Firebase RTDB contains configs for ALL ONIX apps in the same cluster. Example dump showed 6 apps: jangkar55, asgacor, juara126, leon188, nona55, platinum789. Each app has:
- Unique `d-key` (encryption key, e.g. CS2ABA0, CS2ABCA)
- Shared `x-api-key` (same across all apps)
- Same `baseUrl` (api-onix-ns2.seamless-hptech.com)
- Same payment gateways

**Attack surface from Firebase dump:**
1. API authentication: x-api-key + d-key → authenticate to ONIX API
2. Payment gateways: staging URLs (stageapi.vaderpay.net, stgpay.ug396-api.com) often accessible
3. APK URLs: download ALL 6 apps, compare for additional secrets
4. Referral system: staging referral URL may allow mass registration

**Global config also open:**
```
https://global-configs-2-default-rtdb.asia-southeast1.firebasedatabase.app/new.json
```
Contains: game exit regex, provider images, wallet config, version info.

**Pitfall:** ONIX API (`api-onix-ns2.seamless-hptech.com`) requires `agent_id` and `domain_key` server-side. Passing them as HTTP headers does NOT work — the API returns "Invalid access (domain_key - empty, agent_id - empty)" even with `d-key`, `agent_id`, `domain_key` headers set. The Flutter app sends these differently (likely in request body as form-encoded, or via a custom mechanism not visible in `strings` output). **Do NOT waste time on header combos** — the API validation reads from a different source.

**Firebase is READ-ONLY:** Open Firebase RTDB allows GET (read all data) but blocks PUT/PATCH/DELETE with 401 "Permission denied". You cannot modify config, inject backdoors, or test write-based attacks.

**VaderPay staging is LIVE:** `stageapi.vaderpay.net` returns 200 OK for `/` (Payment Page) and `/deposit` (11KB deposit form). No auth required to view. Potential for deposit/withdraw manipulation testing.

**Staging login returns JSON:** `tec188idrstg.8882928.com/login` POST returns `{"s":"f","m":"Username atau kata sandi salah!"}` (JSON, not HTML). This is useful for automated credential testing — parse JSON response instead of HTML.

**cPanel on referral domains:** ONIX referral sites (e.g. jangkarbandot.xyz) often run on LiteSpeed without Cloudflare. `/cpanel`, `/whm`, `/webmail` return cPanel redirect pages (34KB). `.git` returns 403 (exists but blocked). Worth testing for cPanel brute force.

## Companion Domains
ONIX sites typically have:
- Main domain (e.g. joindijangkar55.online)
- Alternate/canonical domain (e.g. jangkar55ori.com)
- Service center domain (e.g. ownerjangkar.art/jangkar55/)
- RTP/pattern site (e.g. ori.rtpjangkar55.host/rtp/)
- Referral site (e.g. jangkarbandot.xyz) — often NO Cloudflare!
- S3 APK storage (e.g. s3-ap-southeast-1.amazonaws.com/apkstore888.net/)
- External APK host (e.g. ios88app.com/android/poker.apk)

## Related Tools & Services
- **Firebase** — Auth, Realtime Database, Messaging, App Check
- **Pusher** — Real-time notifications (key, cluster, secret)
- **Forethought AI** — Chatbot widget
- **Comm100 / LiveChat** — Customer support
- **Matomo / Google Analytics / Facebook Pixel / Kwai Pixel** — Tracking
- **Cloudflare Turnstile** — CAPTCHA (login) + custom captcha image (forgot pw)
