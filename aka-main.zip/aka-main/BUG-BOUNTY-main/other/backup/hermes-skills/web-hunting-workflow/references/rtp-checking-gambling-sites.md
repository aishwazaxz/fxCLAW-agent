# RTP Checking on Gambling Sites

## Overview
RTP (Return to Player) is the percentage of wagered money a slot machine pays back to players over time. Gambling sites can request custom RTP settings from game providers, often using LOWER rates than the theoretical default.

## Why Check RTP
- **Audit finding**: Site advertises "RTP paling tinggi" but uses lower rates = misleading marketing
- **Player exploitation**: Lower RTP = more house edge = less player winnings
- **Regulatory violation**: Many jurisdictions require minimum RTP rates

## Method 1: JavaScript Extraction (Most Reliable)

### Step 1: Login to the gambling site
```bash
# Use browser automation or curl with session cookies
# Example: MPOID (mpoidqz.xyz)
```

### Step 2: Navigate to slot provider page
```
https://TARGET/slot/pragmaticplay
https://TARGET/slot/pgsoft
https://TARGET/slot/microgaming
```

### Step 3: Extract RTP from progress bars
```javascript
// Run in browser console
const allDivs = document.querySelectorAll('div');
let gameData = [];
allDivs.forEach(div => {
    const progressBar = div.querySelector('[role="progressbar"]');
    if (progressBar) {
        const rtp = progressBar.getAttribute('aria-valuenow');
        const img = div.querySelector('img[alt]');
        if (img && img.alt && img.alt.length > 2) {
            gameData.push({
                name: img.alt,
                rtp: rtp + '%'
            });
        }
    }
});
JSON.stringify(gameData);
```

### Step 4: Compare with theoretical RTP
| Game | Theoretical RTP | Actual RTP | Difference |
|------|-----------------|------------|------------|
| The Dog House | 96.51% | 84% | -12.51% |
| Wild West Gold | 96.51% | 89% | -7.51% |
| Sweet Bonanza | 96.48% | 89% | -7.48% |
| Gates of Olympus | 96.50% | 80% | -16.50% |

## Method 2: API Endpoint Discovery

Some gambling sites expose RTP via API endpoints:
```bash
# Check for game config APIs
curl -s "https://TARGET/api/games" | jq '.[] | {name, rtp}'
curl -s "https://TARGET/api/slot/config" | jq '.rtp'
curl -s "https://TARGET/api/provider/pragmaticplay" | jq '.games[] | {name, rtp}'
```

## Method 3: Game Launch Parameter Analysis

When launching a game, check the URL parameters:
```
https://TARGET/game/launch?game=doghouse&rtp=84&operator=TARGET
https://game-provider.com/launch?rtp=84&operator=TARGET&game=doghouse
```

The `rtp` parameter in the launch URL reveals the actual RTP setting.

## Method 4: Network Traffic Analysis

1. Open browser DevTools → Network tab
2. Launch a slot game
3. Filter for XHR/Fetch requests
4. Look for game configuration responses containing RTP values

```javascript
// Intercept fetch calls
const originalFetch = window.fetch;
window.fetch = function(...args) {
    console.log('Fetch:', args[0]);
    return originalFetch.apply(this, args).then(response => {
        response.clone().text().then(body => {
            if (body.includes('rtp') || body.includes('RTP')) {
                console.log('RTP Response:', body.substring(0, 500));
            }
        });
        return response;
    });
};
```

## Common RTP Ranges by Provider

### Pragmatic Play
- **Default**: 96.5% (most games)
- **Range**: 94.5% - 97.5%
- **Custom**: Sites can request 80% - 97%

### PG Soft
- **Default**: 96.7% (most games)
- **Range**: 95.5% - 97.5%
- **Custom**: Sites can request 82% - 97%

### Microgaming
- **Default**: 96.0% (most games)
- **Range**: 95.0% - 97.0%
- **Custom**: Sites can request 85% - 97%

## Example: MPOID (mpoidqz.xyz) RTP Analysis

**Date**: 2026-06-02
**Site**: mpoidqz.xyz (Indonesian gambling site)

### TOP RTP (Highest)
1. Sweet Bonanza 2500 — **97%**
2. Mpoplay Gates Of Olympus — **95%**
3. Gates Of Olympus 1000 — **94%**
4. Mpoplay Starlight Princess 1000 — **93%**
5. Starlight Princess Super Scatter — **93%**
6. Sugar Rush 1000 — **93%**

### LOWEST RTP
1. Gates Of Olympus — **80%**
2. Starlight Princess — **80%**
3. Mahjong Wins 2 — **80%**

### Key Findings
- **Average RTP**: 87.5% (significantly lower than provider defaults)
- **Range**: 80% - 97%
- **Misleading marketing**: Site claims "RTP paling tinggi" but most games are 80-85%
- **Custom settings**: Provider allows site to set custom RTP per game
- **CRITICAL: Values are DYNAMIC** — On page refresh, RTP values CHANGE:
  - Sweet Bonanza 2500: 97% → 91% (different loads)
  - Sweet Bonanza 1000: 84% → 97% (different loads)
  - This proves the "RTP" is NOT real game RTP but a "gacor score" set by operator

## Audit Report Template

```markdown
## RTP Audit Finding

**Site**: [TARGET]
**Date**: [DATE]
**Method**: JavaScript extraction from progress bars

### Summary
- Average RTP: [X]% (vs provider default [Y]%)
- Range: [MIN]% - [MAX]%
- Games below 90%: [COUNT] out of [TOTAL]

### Top 5 Highest RTP
1. [GAME] — [RTP]%
2. [GAME] — [RTP]%
3. [GAME] — [RTP]%
4. [GAME] — [RTP]%
5. [GAME] — [RTP]%

### Top 5 Lowest RTP
1. [GAME] — [RTP]%
2. [GAME] — [RTP]%
3. [GAME] — [RTP]%
4. [GAME] — [RTP]%
5. [GAME] — [RTP]%

### Comparison with Provider Defaults
| Game | Theoretical | Actual | Difference |
|------|-------------|--------|------------|
| [GAME] | [THEO]% | [ACT]% | [DIFF]% |

### Regulatory Impact
- [JURISDICTION] requires minimum [X]% RTP
- [COUNT] games below minimum threshold
- Potential violation of [REGULATION]

### Recommendation
- Players should be informed of actual RTP rates
- Site should not advertise "highest RTP" if using custom lower rates
- Consider regulatory reporting if jurisdiction requires minimum RTP
```

## Tools Required
- Browser with DevTools (Chrome/Firefox)
- JavaScript console access
- Session cookies for authenticated access
- Optional: Burp Suite for traffic interception

## Pitfalls
- **Progress bars may not show RTP** — Some sites use progress bars for popularity, not RTP. Verify by checking multiple games.
- **Dynamic content** — RTP values may change based on time, user, or game state. Capture multiple samples.
- **CRITICAL: MPO sites show DYNAMIC "RTP" that changes per page load!** — On MPO-type sites (mpoidqz.xyz etc.), the progress bar values CHANGE on each page refresh. Sweet Bonanza 2500 showed 97% on first load, 91% on second load. Sweet Bonanza 1000 showed 84% first, 97% second. This means the displayed "RTP" is NOT actual game RTP — it's a **dynamic "gacor score"** set by the operator to mislead players into thinking certain games are "hot". Always capture multiple page loads and note the variance. If values change significantly (±5%), it's operator manipulation, not real RTP.
- **Session expiration** — Login sessions expire fast. Re-login before each extraction.
- **Provider-specific formats** — Different providers use different RTP formats (percentage, decimal, ratio). Normalize to percentage.
- **Custom vs default** — Some sites show "default" RTP but actually use custom settings. Always compare with theoretical values.
- **MPO navigation uses routeNav()** — Game links use `onclick="routeNav('/slot/provider')"` pattern. "Main Sekarang" links don't have onclick — click the game CARD div instead. Use browser console to find game images by `img[src*='gamecode']` pattern.
- **linkcdn.cloud game image pattern** — `https://images.linkcdn.cloud/global/game-list/slot/{provider}/{gamecode}.webp`. Example: `vs20swbon2500.webp` = Sweet Bonanza 2500. Use to identify specific games for clicking.
- **gamePlay() function** — MPO-type sites launch games via `gamePlay(url, newtab=false)` JavaScript function. The function does `window.location.href = playUrl` or `window.open(playUrl, '_blank')`. Find it in page source or call it directly from console: `gamePlay('/play/pragmaticplay/vs20swbon2500')`.
- **MPOID session timeout is ~30 seconds** — Login sessions expire extremely fast. Do ALL authenticated work in ONE browser session. Don't navigate away from the game page. If using curl, re-login before each request.
- **MPOID balance format** — Balance shows as `IDR X.XX` where X.XX is in THOUSANDS. So `IDR 3.86` = Rp 3,860 (enough for 4-5 spins at minimum bet Rp 200-800). Don't dismiss low-looking balances.
- **MPOID login via browser** — The site uses JavaScript-based login (no standard form POST). Use browser automation, not curl. Click LOGIN button → fill username/password → click submit. The login modal is hidden by default — click the LOGIN button in the header to reveal it.
