# Indonesian Gambling Site (Judol) Patterns

## Detection: SPA Catch-All vs Real Site

Most judol sites are SPAs that return 200 for ALL paths. To detect:

```python
# Get main page
r1 = requests.get(target, timeout=10)
# Get random path
r2 = requests.get(f"{target}/nonexistent_check_12345", timeout=5)

# If sizes are similar → catch-all (SKIP)
if abs(len(r1.text) - len(r2.text)) < 300:
    print("CATCH-ALL SPA - fake findings")
```

## Platform Classes

### Class 1: N1TRO Engine (Small/Medium judol)
Many judol sites use N1TRO engine (n1troengine.com):

**Indicators:**
- JS bundles: `/static/js/index.*.js?company=XXXXX` (company ID)
- Config inline script: `lotteryfoapi.n1troengine.com` + `wss://lbfos.n1troengine.com`
- API response: `{"data": null, "err": "net/http: abort Handler", "success": false}`

**Domains:**
- `lotteryfoapi.n1troengine.com` — Backend API (Go/Fiber)
- `lbfos.n1troengine.com` — WebSocket
- `lbstatic.n1troengine.com` — Static CDN
- `lapp.n1troengine.com` — Load balancer

**Company ID extraction:**
```javascript
// In bundle JS
/static/js/index.3c47f0ef.js?company=519247
//                                    ^^^^^^ company ID
```

### Class 2: Cashmarket API Platform (Large judol — BK8-class)
International judol brands (BK8, etc.) use Spring Boot + React:

**Indicators:**
- Cloudflare WAF + Turnstile CAPTCHA
- Spring Boot error format: `{"timestamp":"...","status":403,"error":"Forbidden","path":"..."}`
- API prefix: `/cashmarket/api/v3/`, `/campaign/api/v2/`
- Merchant codes: 001, etc.
- Forethought AI chatbot (solve-widget.forethought.ai)
- Version string in asset paths (e.g., `10.5.29b`)

**Key difference**: CF WAF blocks curl scanning, BUT static JSON configs are still accessible at `/public/html/settings/*.json`, `/locales/*.json`, etc.

**Full endpoint list**: See `references/cashmarket-api-platform.md`

### Class 3: PHP Custom (Small judol)
Most common for smaller sites. Often Laravel or custom PHP.

**Indicators:**
- `X-Powered-By: PHP` header
- `/login`, `/register` routes (not SPA catch-all)
- `__RequestVerificationToken` (ASP.NET) or CSRF tokens (Laravel)

### Class 5: ONIX Platform (Medium/Large judol — Jangkar55-class)
Indonesian judol sites using Laravel PHP backend with jQuery/Bootstrap frontend:

**Indicators:**
- jQuery + Bootstrap + SweetAlert2 frontend
- Laravel PHP backend (CSRF `_token` field, `register_token`)
- Cloudflare WAF (usually)
- Agent code in meta tags (e.g. "JANGKAR55")
- CDN: sitestatic.net / cdn.sitestatic.net
- LiveChat: livechatinc.com
- Flutter/Dart mobile app (libapp.so)
- Forms: `stage_val`, `isRegHasBank`, honeypot fields with random names

**Key API endpoints:**
- `/checkExistingEmail` (POST) — returns FULL page HTML, NOT true/false (dynamic content causes size variation — FALSE POSITIVE for enumeration)
- `/checkExistingUser` (POST) — always 1461 bytes (no enumeration)
- `/getPokerJackpotAmt` (POST) — unauthenticated, leaks jackpot amount
- `/getHKBLotteryResults` (POST) — unauthenticated, 12 lottery games
- `/validate-pin` (POST) — 6-digit PIN brute force (no rate limit detected)
- `/captcha-image-forgotpw` (GET) — may be STATIC (same hash across requests)

**Staging URL patterns (from APK):**
- `{prefix}.web-sample.live` (e.g. stg3mplay.web-sample.live)
- `{prefix}.8882928.com` (e.g. tec188idrstg.8882928.com)

**Full pattern details:** See `references/onix-platform-patterns.md`

### Class 4: ASP.NET MVC
Some gambling sites use ASP.NET MVC with `__RequestVerificationToken` CSRF. The login endpoint `/Account/Login` is often vulnerable to SQLi with `#` comment.

## QRIS Payment Flow (otomatis.vip)

Judol sites often use third-party payment via otomatis.vip:

**Script injection chain:**
1. Main page has inline script with:
   - `uuidautodepo = "UUID"`
   - `loadwl = "vigor"` (script name)
   - `domainsystem = "piv.sitamoto.51emarfi"` (reversed string)
2. Loads: `iframe*.otomatis.vip/scriptnwl/vigor.js`
3. vigor.js reads `localStorage['persist:client']` for username
4. Config: `iframe*.otomatis.vip/data/{uuid}.txt` (base64 JSON)
5. Payment iframe: `iframe*.otomatis.vip/nawala.html`
6. QR generation: `qris.otomatis.vip/api/generate`

**QRIS API:**
```
POST https://qris.otomatis.vip/api/generate
Content-Type: application/json

{
    "username": "any_string",  // NOT validated!
    "amount": 50000,
    "uuid": "site-uuid",
    "bonus": 0  // optional
}

Response:
{
    "status": true,
    "data": "000201010212..."  // QRIS TLV data
}
```

**Findings:**
- Username NOT validated against database
- Amount min/max not enforced (Rp 1 works)
- Rotating merchants (different merchant per transaction)
- Fee (e.g. Rp 3500) applied on site side, not in QR

**QRIS TLV parsing:**
```python
def parse_qris(qris_str):
    i = 0
    tags = {}
    while i < len(qris_str):
        tag = qris_str[i:i+2]
        length = int(qris_str[i+2:i+4])
        value = qris_str[i+4:i+4+length]
        tags[tag] = value
        i += 4 + length
    return tags
# Tag 54 = Amount, Tag 59 = Merchant Name, Tag 60 = City
```

## Source Code Leak Patterns

Judol sites often leak source via related domains:

1. Check metadata for related domains (og:url, canonical, schema.org)
2. Check for `.zip` files on related domains (directory listing)
3. Common leak: `misteryboxunsur.org/lootbox.zip` pattern
4. PHP source often includes `config.php` with DB credentials

## Common Vulnerabilities Found

1. **SQL Injection** in PHP apps (lootbox, admin panels)
   - Voucher/code fields often unprotected
   - `' OR '1'='1` bypass pattern
   
2. **Source code disclosure** via:
   - Directory listing on related domains
   - `.zip` files with full source
   - Error logs with file paths
   
3. **Payment flow manipulation**:
   - No username validation on QRIS API
   - Amount limits not enforced
   - Merchant rotation for anti-detection
   
4. **Supply-chain injection**:
   - External scripts control deposit flow
   - Obfuscated JavaScript
   - Data sent to third-party domains

## Hunting Workflow for Judol

1. Search Exa for judol keywords + low-sec TLDs
2. Filter out Cloudflare (Server header check) — BUT if user explicitly asks for a CF target, use static config enumeration
3. Detect SPA catch-all (path size comparison)
4. **Identify platform class**: N1TRO (Go), Cashmarket (Spring Boot), PHP custom, ASP.NET, ONIX (Laravel)
5. For real sites: check metadata for related domains
6. Check related domains for directory listings / .zip files
7. **Check for APK download links** (S3, CDN, companion domains) — APK analysis reveals staging URLs, API endpoints, plaintext tokens, Firebase config
8. If PHP found: test SQLi on login/voucher forms
9. If N1TRO: extract company ID, check API endpoints
10. If Cashmarket: enumerate static JSON configs + public API endpoints (see `references/cashmarket-api-platform.md`)
11. If ONIX: check /getPokerJackpotAmt, /getHKBLotteryResults (unauthenticated), test static captcha, check staging URLs from APK (see `references/onix-platform-patterns.md`)
12. If QRIS payment: test API for username validation bypass
