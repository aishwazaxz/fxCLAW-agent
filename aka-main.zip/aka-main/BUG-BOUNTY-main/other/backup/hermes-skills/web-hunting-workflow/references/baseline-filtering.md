# Baseline Filtering Technique

When a site returns 200 for ALL paths (Laravel catch-all), use baseline filtering to find real endpoints.

## Step 1: Get Baseline
```bash
# Request a random path that definitely doesn't exist
BASELINE_SIZE=$(curl -s "https://target/xyzrandom123test" | wc -c)
BASELINE_WORDS=$(curl -s "https://target/xyzrandom123test" | wc -w)
BASELINE_LINES=$(curl -s "https://target/xyzrandom123test" | wc -l)
```

## Step 2: Run FFUF with Filters
```bash
ffuf -u "https://target/FUZZ" \
  -w wordlist.txt \
  -mc all \
  -fs $BASELINE_SIZE \    # Filter by response SIZE
  -fw $BASELINE_WORDS \   # Filter by word count
  -fl $BASELINE_LINES \   # Filter by line count
  -o ffuf.json
```

## Step 3: Analyze Results
```bash
# Parse JSON output
cat ffuf.json | python3 -c "
import sys, json
data = json.load(sys.stdin)
for r in data.get('results', []):
    print(f\"[{r['status']}] {r['url']} ({r['length']} bytes)\")
"
```

## Example Output
```
[302] https://target/dashboard (850 bytes)    ← REAL (redirect)
[200] https://target/login (113753 bytes)     ← REAL (login page)
[200] https://target/register (169086 bytes)  ← REAL (registration)
[200] https://target/.htaccess (603 bytes)    ← REAL (config file)
[200] https://target/web.config (1194 bytes)  ← REAL (config file)
[200] https://target/sitemap.xml (5504 bytes) ← REAL (sitemap)
[200] https://target/robots.txt (87 bytes)    ← REAL (robots)
```

## Why This Works
- Laravel catch-all route returns same response for all unknown paths
- Real endpoints have different sizes (login page, registration, etc.)
- Static files (.htaccess, web.config) have different sizes
- Filtering by size/words/lines removes false positives

## Common Baseline Sizes
- Laravel error page: ~17,000 bytes
- WordPress 404: ~50,000 bytes
- Custom 404: varies

## Pitfalls
- Some sites have multiple catch-all sizes (check both size and words)
- Dynamic content might change size between requests
- Always verify findings manually
