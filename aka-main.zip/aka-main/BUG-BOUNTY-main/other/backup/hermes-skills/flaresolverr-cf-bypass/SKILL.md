---
name: flaresolverr-cf-bypass
description: Bypass Cloudflare WAF using FlareSolverr proxy. Solves CF challenges automatically and returns cookies/headers for subsequent requests.
tags: [cloudflare, bypass, waf, flaresolverr, judol, web-hunting]
---

# FlareSolverr — Cloudflare Bypass

## Setup
```bash
docker pull flaresolverr/flaresolverr:latest
docker run -d --name flaresolverr -p 8191:8191 -e LOG_LEVEL=info flaresolverr/flaresolverr:latest
```

## Usage

### GET request
```bash
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"request.get","url":"https://target.com","maxTimeout":60000}'
```

### POST request
```bash
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"request.post","url":"https://target.com/login","postData":"user=admin&pass=123","maxTimeout":60000}'
```

### Python wrapper
```python
import requests
r = requests.post("http://localhost:8191/v1", json={
    "cmd": "request.get",
    "url": "https://target.com",
    "maxTimeout": 60000
}, timeout=90)
data = r.json()
html = data["solution"]["response"]
cookies = data["solution"]["cookies"]
user_agent = data["solution"]["userAgent"]
```

### Extract cookies for curl
```python
cookies = "; ".join(f"{c['name']}={c['value']}" for c in data["solution"]["cookies"])
```

## Tool script
`/workspaces/BUG-BOUNTY/tools/web/flare_bypass.py`

## Pitfalls
- FlareSolverr needs ~10-30s per request (browser-based)
- Rate limit: don't hammer, CF will block the IP
- Cookies expire — re-solve periodically
- maxTimeout default 60000ms, increase for slow sites
- Docker container uses Chromium internally
- **CRITICAL for POST requests**: Default mode creates NEW session per request. CSRF-protected sites return "Page expired" because token doesn't match session. MUST use `sessions.create` for multi-request flows. See `cf-auto-bypass` skill for full persistent session technique and Python helper class.

## Persistent Sessions (for CSRF-protected sites)
```bash
# Create session
curl -s http://localhost:8191/v1 -X POST -d '{"cmd":"sessions.create"}'
# GET with session
curl -s http://localhost:8191/v1 -X POST -d '{"cmd":"request.get","url":"URL","session":"SESSION_ID","maxTimeout":60000}'
# POST with same session (CSRF works!)
curl -s http://localhost:8191/v1 -X POST -d '{"cmd":"request.post","url":"URL","session":"SESSION_ID","postData":"data","maxTimeout":60000}'
# Destroy session
curl -s http://localhost:8191/v1 -X POST -d '{"cmd":"sessions.destroy","session":"SESSION_ID"}'
```
