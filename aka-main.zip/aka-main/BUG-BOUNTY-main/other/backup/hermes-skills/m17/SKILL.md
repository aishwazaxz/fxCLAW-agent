---
name: m17
description: "m17 — Power Pack: Planner · Swarm · Automation · Backtest · Dashboard · Voice (NEW in v4.0)"
tags: [agent, m17]
---

# m17 — Power Pack: Planner · Swarm · Automation · Backtest · Dashboard · Voice (NEW in v4.0)

Fitur "premium-feel" yang bikin agent kerasa mikir, ngerencanain, dan jalan sendiri. Semua yang nyentuh dana TETAP lewat governor; yang nge-drive eksekusi (planner/swarm/automation/skill_forge) masuk FROZEN_PATHS.

| Fitur | Script | Inti |
|---|---|---|
| Workflow planner | `tools/planner.py` | tujuan NL → plan multi-step → eksekusi bertahap (gated) |
| Multi-agent swarm | `tools/swarm.py` | specialist lane paralel + pemisahan key |
| Skill forge | `tools/skill_forge.py` | agent draft skill baru → proposal (gak auto-apply) |
| Automation engine | `tools/automation.py` | WHEN trigger THEN actions |
| Backtester | `tools/backtest.py` | replay strategi di data historis |
| Live dashboard | `tools/dashboard.py` | HTML real-time (portfolio/gas/governor/audit) |
| Voice mode | `tools/voice.py` | STT→LLM→TTS, ngobrol kayak nelpon |
| Explainability | `tools/explain.py` | rangkum audit trail "apa & kenapa" |

## 1. Workflow planner (Tier 1)

```python
from planner import make_plan, execute_plan
plan = make_plan("isi base lalu beli token 0xABC di 5 wallet")   # LLM via model_registry
print(plan.summary())                                            # step 💸 = nyentuh dana
await execute_plan(plan, handlers, confirm_cb)                   # checkpoint + gated
```

Agent dekomposisi tujuan jadi langkah dari skill library, tiap step fund lewat handler yang governor-gated. Plan ditampilin dulu sebelum jalan.

## 2. Multi-agent swarm (Tier 1)

```python
from swarm import Swarm, Specialist
sw = Swarm([Specialist("researcher", researcher_fn),
            Specialist("monitor", monitor_fn),
            Specialist("executor", executor_fn, holds_keys=True)])
await sw.dispatch({"researcher": {...}, "monitor": {...}})   # PARALEL
sw.safety_report()   # warning kalau lane non-executor pegang key
```

Pemisahan key: lane watcher/monitor (selalu online) **gak pegang key**; cuma executor yang sign.

## 3. Skill forge (Tier 1, gated)

```python
from skill_forge import forge_proposal
forge_proposal("belum bisa baca Chainlink oracle", "m18")   # → proposal, REVIEW dulu
```

Agent numbuhin kemampuannya sendiri — tapi lewat proposal (x4/frozen-paths), operator yang acc + re-lock.

## 4. Automation engine (Tier 3)

```python
from automation import AutomationEngine
ae = AutomationEngine()
ae.add_rule("gas murah → swap", "price", {"metric": "gas"},
            actions=[{"action": "swap", "params": {...}, "funds": True}])
await ae.fire(event, action_handlers, confirm_cb)   # aksi fund → governor
```

IFTTT buat crypto/ops: trigger (webhook/schedule/price/onchain_event/custom) → rangkaian aksi.

## 5. Backtester (Tier 3)

```python
from backtest import backtest
res = backtest(my_strategy, candles, initial=1000)
res.metrics()   # return_pct, win_rate, trades, drawdown
```

Tes strategi di data historis sebelum live. Bukan ramalan — alat validasi.

## 6. Live dashboard (Tier 2)

```python
from dashboard import build_dashboard_html, gather
html = build_dashboard_html(gather(governor=gov, alert_engine=ae, ...))
# serve dari VPS (m2/m9). KASIH AUTH, jangan public polos.
```

Real-time: portfolio, gas, status governor, alert aktif, proposal pending, audit. Auto-refresh 30s.

## 7. Voice mode (Tier 2)

```python
from voice import converse
converse("voice_note.ogg")   # STT (Whisper lokal) → LLM (cascade) → TTS (pyttsx3 lokal)
```

Dua arah: lo ngomong, agent jawab suara. Lengkapin voice input m15.

## 8. Explainability (Tier 2/3)

```python
from explain import explain
print(explain())   # "apa yang agent lakuin & kenapa" dari audit trail
```

## Catatan

- Planner/skill-forge/swarm decomposition pakai LLM via `model_registry` (m7/v4.0) — `add model` dulu kalau cascade kosong.
- Dashboard butuh port di-expose — amanin dengan auth, default localhost.
- Voice TTS: `pip install pyttsx3` (gratis, offline). Backtester & explain keyless.
- Swarm multi-proses pakai delegate OpenClaw — verify API current saat scale.
