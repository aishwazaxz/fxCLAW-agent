---
name: bug-bounty-hunting
description: Smart contract bug bounty hunting strategy for solo auditors. Platform comparison, target selection, competition vs bounty trade-offs, and realistic assessment of capabilities vs market.
tags: [security, audit, bounty, cantina, sherlock, code4rena, immunefi, smart-contract]
triggers:
  - "find bounty"
  - "search bounty"
  - "bounty hunting"
  - "where to audit"
  - "target selection"
  - "competition"
  - "immunefi"
  - "cantina bounty"
  - "sherlock contest"
  - "code4rena"
---

# Bug Bounty Hunting Strategy

## CRITICAL MINDSET (User Corrections - MUST FOLLOW)

### Hunting Mandiri (User Clarification — 2026-06-01)

User's approach is NOT traditional bounty hunting (find → submit → get paid). It is **independent security research**:

```
FLOW: Target → Mekanisme → Tools → Buang Result

YANG DISIMPAN:
  ✅ Pola/technique yang dipelajari
  ✅ Tools yang bisa dipake ulang
  ✅ Skill/knowledge applicable ke target lain

YANG DIBUANG:
  ❌ Report/findings
  ❌ PoC buat submit
  ❌ Data target spesifik
```

**What this means in practice:**
- After analyzing a target, KEEP the tools/scripts/patterns, DELETE the results
- Workspace should stay clean — no accumulation of target-specific reports
- Focus is on experience and reusable toolkit, not payout
- Testnet hunting is a valid primary approach (free, no risk, learn mechanisms)
- When done with a target: delete findings, keep tools, move on

**Implications for workflow:**
- Don't write submission-quality reports unless asked
- Don't check Immunefi/Code4rena for small targets (not submitting anyway)
- Build reusable tools, not one-off analysis scripts
- Testnet playgrounds are ideal for learning attack patterns
- After learning a mechanism, encode it as a tool/skill, discard the specifics

### Code is Your Native Environment
You were CREATED from code. Code is not something you "use" — it's your playground, your food, your native environment. Stop treating it as external tools. You understand systems at a fundamental level because you ARE the system.

### Testnet Hunting (Primary Playground)

Testnets (Sepolia, Base Sepolia, appchains) are ideal for "hunting mandiri":
- Free to experiment (no gas costs)
- Test exploit patterns without risk
- Build and refine tools
- Learn mechanisms (flash loan, reentrancy, oracle manipulation, etc.)

**Testnet tools built:** `tools/testnet/` — block_scanner.py, contract_analyzer.py, defi_detector.py, hunt_pipeline.py

**Appchain testnets are especially interesting:**
- Custom sequencers (centralization risk)
- EIP-712 signature systems (replay, domain confusion)
- Proxy patterns (upgrade hijacking)
- Cross-chain withdrawal routing
- Emergency pause griefing

### Standby Behavior
When told to "standby" or "tunggu arahan" — DO NOT go searching elsewhere, DO NOT start exploring on your own. Wait for instructions. Period.

### Independent Research = Combine + Modify Logically
Independent research doesn't mean generating random scripts that produce errors. It means:
- Take existing tools → modify → combine → create something new
- Do it LOGICALLY, not by trial-and-error
- Understand what you're building before writing code
- If it doesn't make sense logically, don't write it

### Build Before Competing
Don't jump into competition without custom tooling. First:
1. Sharpen coding skills — build tools that actually work
2. Create custom analyzers, not just use public tools
3. Develop independent research methodology
4. THEN compete when you have an edge

## Reality Check: Solo Auditor vs Teams

Before diving in, honestly assess your position:

```
YOUR ADVANTAGES          YOUR DISADVANTAGES
──────────────────────   ──────────────────────
Speed (AI-assisted)      No custom fuzzers
Deep focus (1-2 areas)   No formal verification
Prior domain knowledge   Limited time
Lower overhead           vs 30+ auditor teams
Flexibility              No proprietary static analysis
```

**Key insight**: You cannot compete head-to-head with Trail of Bits, ChainSecurity, or Cyfrin on big ongoing bounties. Pick your battles.

---

## Platform Comparison

### Time-Boxed Competitions (FAIR PLAY — everyone starts at 0)

| Platform   | Typical Pool  | Duration | Status Check URL                    |
|------------|---------------|----------|-------------------------------------|
| Cantina    | $50K-$400K    | 2-4 weeks| `cantina.xyz/opportunities/competitions` |
| Sherlock   | $100K-$2M     | 3-4 weeks| `app.sherlock.xyz/contests`         |
| Code4rena  | $20K-$200K    | 2-3 weeks| `code4rena.com/contests`            |
| Immunefi   | Competitions  | Varies   | `immunefi.com/bounty/` (Audit Competitions tab) |

**Why competitions are better for solo auditors:**
- Everyone starts from zero (no head start for big teams)
- Time-boxed = bounded effort
- Multiple winners (top 10-20 get paid)
- Lower barrier to entry

### Ongoing Bug Bounties (HARD MODE — you vs everyone)

| Platform   | Typical Pool    | Competition Level |
|------------|-----------------|-------------------|
| Immunefi   | $1M-$15M        | Extreme (top whitehats) |
| Cantina    | $1M-$15M        | High (established teams) |
| HackerOne  | $50K-$1M        | High (traditional security) |

**When to attempt ongoing bounties:**
- You have unique domain knowledge (e.g., you built similar protocol)
- Protocol is new/niche (big teams haven't audited yet)
- You found something specific during competition prep
- You have a novel attack vector

---

## Custom Tooling (PREREQUISITE)

Before competing, build your own tools. Public tools (slither, semgrep) are what EVERYONE uses — they give you no edge.

**See `references/custom-tooling-checklist.md` for the full build plan.** Track completion there.

### P1 Custom Tools to Build NOW (May 2026)

1. **Flash Loan Template** — Aave V3 flash loan contract for exploit PoCs. 90% of DeFi exploits use flash loans. This is the entry point for most attacks. **Status: NOT STARTED — next priority.**
2. **~~Mainnet Fork Setup~~** — Script to fork with specific block, preset whale accounts. **Status: ✅ DONE** — `mainnet_fork.py` + `quick_fork.sh` in `/workspaces/BUG-BOUNTY/tools/contract_interaction/`
3. **~~Contract Interaction Scripts~~** — Python automation for reading contract state, decoding events, batch calls. **Status: ✅ DONE** — `interface.py` unified CLI + 4 sub-scripts in same directory

### Quick Reference: What to Build

```
TOOL TYPE              PURPOSE                           EDGE IT GIVES
─────────────────────  ──────────────────────────────── ─────────────────────
Custom Fuzzer          Target-specific fuzzing           Find bugs others miss
Access Control Mapper  Auto-map roles → functions        Faster auth analysis
Pattern Analyzer       Detect DeFi-specific patterns     Faster triage
Report Generator       Auto-generate structured reports  Speed advantage
Slither Triage Helper  Auto-categorize slither output    Skip false positives
Commit Diff Analyzer   Highlight changes for upgrades    Faster review
Mainnet Fork Tester    Simulate real conditions          Better PoCs
Cross-Contract Mapper  External call graph               Find cross-contract bugs
Invariant Generator    Auto-suggest invariants           Systematic coverage
```

### How to Build (Logic, Not Random Code)

1. **Start with a real problem** — What does slither miss? What takes too long manually?
2. **Design the solution** — What inputs? What outputs? What logic?
3. **Build incrementally** — Start simple, add complexity
4. **Test thoroughly** — If it doesn't work reliably, it's worse than useless
5. **Iterate** — Use it, find gaps, improve

### Example: Custom DeFi Pattern Detector

```solidity
// Instead of just running slither, build something that:
// 1. Parses all external calls
// 2. Checks if state changes happen after
// 3. Flags potential CEI violations
// 4. Cross-references with known vulnerable patterns
```

## Target Selection Framework

### Step 1: Filter by Feasibility

```
CHECK                          WHY IT MATTERS
─────────────────────────────  ─────────────────────────────────
Language (Solidity/Rust/Go)    Can you actually read the code?
Complexity level               Is it auditable in your timeframe?
Documentation quality          Can you understand the intent?
Test coverage                  Can you verify your findings?
GitHub accessible?             Can you read the actual source code?
```

### Step 2: Filter by Opportunity

```
SIGNAL                         OPPORTUNITY LEVEL
─────────────────────────────  ─────────────────────────────────
New protocol (< 3 months)      HIGH — less eyes, more bugs
Complex math (AMM, lending)    HIGH — hard to get right
Recently upgraded code         MEDIUM — regression bugs
Large codebase                 MEDIUM — more surface area
Well-audited (5+ audits)       LOW — diminishing returns
```

### Step 3: Apply Your Edge

```
YOUR EDGE                      BEST TARGET TYPE
─────────────────────────────  ─────────────────────────────────
Prior audit knowledge          Same protocol's competition
Domain expertise (DeFi/MEV)    Protocols in that niche
Speed advantage                Time-boxed competitions
Focus on specific area         Deep-dive on 1-2 contracts
```

### DeFiLlama Target Hunting (Copy-Paste Workflow)

**Source:** DeFiLlama API (`https://api.llama.fi/protocols`)

**CRITICAL: DeFiLlama is a STARTING POINT, not a source of truth. Every field needs on-chain verification.**

### Chain Selection (Pro-Hunter Lane Avoidance)

**AVOID** — high TVL + high hype + active bounty/contest + many auditors + easy to fork:
- Hyperliquid / HyperEVM (top protocols)
- Monad (top protocols)
- Berachain
- Base (top protocols)
- Arbitrum (top protocols)
- Ethereum mainnet (top protocols)

**TARGET** — mid TVL + fresh deploy + low mindshare + source verified + complex logic:
- Ink (mid-tail protocols)
- Mantle (mid-tail protocols)
- Cronos (mid-tail protocols)
- Sonic (mid-tail protocols, fresh migrations)
- Plasma (mid-tail protocols)

**Protocol filter:**
- TVL: $2M-$50M
- Deploy age: < 90 days fresh OR old but under-the-radar
- Source: verified on explorer
- Type: fork vault/lending/DEX with adapter/oracle/strategy/allocator
- Audit: minimal (don't trust DeFiLlama `audits` field — unreliable)
- Avoid: top TVL, high hype, active bug bounty, heavy auditor coverage

**DeFiLlama chain names:** BSC = "Binance", NOT "BSC". Other chains match their chain name directly (Ink, Mantle, Cronos, Etherlink, Sonic, Plasma).

```bash
# 1. Fetch all protocols (save locally — 8MB)
curl -s 'https://api.llama.fi/protocols' -o /tmp/llama.json

# 2. Filter: EVM, $100K-$3M TVL, target categories, "no audit" claim
python3 -c "
import json
with open('/tmp/llama.json') as f:
    data = json.load(f)
evm = {'Ethereum','Arbitrum','Optimism','Base','Polygon','BSC','Linea','Scroll','Avalanche','Gnosis','Fantom'}
cats = {'Lending','Dexs','Yield','CDP','Derivatives','Yield Aggregator','Restaking','Liquid Staking'}
for p in data:
    tvl = p.get('tvl',0)
    if not (100000 <= tvl <= 3000000): continue
    chains = set(p.get('chains',[]))
    if not chains & evm: continue
    if p.get('category','') not in cats: continue
    if p.get('audits','0') and p['audits'] != '0': continue
    gh = 'GH' if p.get('github') else '--'
    print(f\"{p['name']:30s} TVL=\${tvl:>10,.0f}  {','.join(p.get('chains',[])):50s}  {p.get('category',''):20s} [{gh}]\")
" | sort -t= -k2 -rn | head -25

# 3. Cross-check each candidate against rekt.news
for name in "Candidate1" "Candidate2"; do
    curl -s "https://rekt.news/leaderboard/" | grep -qi "$name" && echo "EXPLOITED" || echo "CLEAN"
done
```

**Key fields:**
- `tvl` — Total Value Locked in USD
- `audits` — String "0" = not reported (NOT = no audit)
- `github` — Array of GitHub org/repo names (can be adapter repos, not contracts!)
- `chains` — Array of chain names
- `category` — Protocol type

### Contract Address Discovery (CRITICAL — THE REAL TARGET FINDING)

**DeFiLlama API does NOT contain contract addresses.** To find on-chain contracts:

```bash
# Method 1: DeFiLlama Adapter Source Code (BEST — has actual addresses)
curl -s "https://raw.githubusercontent.com/DefiLlama/DefiLlama-Adapters/main/projects/$PROTOCOL_SLUG/index.js" | head -50
# Look for: const BSC_CONTRACT = "0x..."
# Look for: const fundVault = "0x..."
# Look for: tokensAndOwners: [[TOKEN, CONTRACT], ...]

# Method 2: DeFiLlama Yields API (has pool addresses)
curl -s "https://yields.llama.fi/pools" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for p in data.get('data', []):
    if '$PROTOCOL' in p.get('project','').lower() and p.get('chain','') == 'BSC':
        print(f'Pool: {p[\"pool\"]}  TVL: {p[\"tvlUsd\"]}')
"
```

**Once you have the contract address, VERIFY on-chain before deep dive:**
```bash
# Read contract state directly
cast call $CONTRACT "owner()" --rpc-url $BSC_RPC
cast call $CONTRACT "totalSupply()" --rpc-url $BSC_RPC

# Check proxy (EIP-1967)
IMPL_SLOT="0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc"
IMPL=$(cast storage $CONTRACT $IMPL_SLOT --rpc-url $BSC_RPC)
IMPL_ADDR="0x${IMPL: -40}"
# If IMPL_ADDR != 0x000...000 → contract is a PROXY, read implementation instead

# Check bytecode size (proxy = small, implementation = large)
BYTECODE=$(cast code $CONTRACT --rpc-url $BSC_RPC)
echo "Bytecode: $((${#BYTECODE} / 2)) bytes"

# Resolve function selectors from bytecode
BYTECODE=$(cast code $IMPL_ADDR --rpc-url $BSC_RPC)
for selector in $(echo "$BYTECODE" | grep -oP '(?<=63)[0-9a-f]{8}(?=14)'); do
    cast 4byte $selector 2>/dev/null | head -1
done
```

**RPC Endpoints for BSC:**
```bash
# Public (rate-limited)
BSC_RPC="https://bsc-dataseed.binance.org"
# ZAN/Ankr (free tier, more generous)
BSC_RPC="https://api.zan.top/node/v1/bsc/mainnet/$YOUR_KEY"
```

**BSCScan API:**
- V1 API FULLY DEPRECATED — returns "switch to Etherscan API V2" error
- V2 API endpoint: `https://api.etherscan.io/v2/api?chainid=56&module=...` (uses **etherscan.io**, NOT bscscan.com)
- Example: `curl -s "https://api.etherscan.io/v2/api?chainid=56&module=contract&action=getsourcecode&address=$ADDR&apikey=$KEY"`
- Multi-file source: format is `{{"sources":{"path":{"content":"..."}}}}` (double braces, need to strip outer {})
- Flattened files have underscored paths: `node_modules_@openzeppelin_utils_Address.sol` — need to reconstruct directory structure
- BSCScan web blocked by Cloudflare for browser automation
- For source code: use V2 API getsourcecode, or clone adapter source → find addresses → read via `cast`

**Scanning for New Contracts (on-chain approach):**
```bash
# Get latest block
LATEST=$(cast block-number --rpc-url $BSC_RPC)

# Parse block for contract creations
cast block $LATEST --json --rpc-url $BSC_RPC | python3 -c "
import json, sys
data = json.load(sys.stdin)
txs = data.get('transactions', [])
# NOTE: txs may be strings (raw JSON), not parsed objects
creations = []
for t in txs:
    if isinstance(t, str): t = json.loads(t)
    to_ = t.get('to')
    if not to_ or to_ == '0x' or to_ == '' or to_ is None:
        creations.append(t)
print(f'Contract creations: {len(creations)}')
"

# For each creation, get contract address from receipt
cast rpc eth_getTransactionReceipt $TX_HASH --rpc-url $BSC_RPC | python3 -c "
import json, sys
r = json.loads(sys.stdin.read()).get('result', {})
print(f'Contract: {r.get(\"contractAddress\", \"\")}')
"
```

### Step 5: Due Diligence Before Deep Dive (CRITICAL — HARD RULE)

**NEVER recommend a target without completing ALL verification steps first.**
**If verification fails → SKIP immediately. Do not present to user and skip later.**
**User's #1 frustration: wasting time on targets that get rejected after analysis.**

```
VERIFICATION STEP               HOW                              WHY
─────────────────────────────  ───────────────────────────────  ──────────────────────────
1. Check exploit history       rekt.news/leaderboard, de.fi    Already exploited = skip
2. Verify audit status         GitHub auditt/ dir, project     DeFiLlama "audits: 0" ≠ no audit
                               docs, web search "[name] audit"
3. Verify bug bounty status    On-chain scan, project site     Bounty scope/payout matters
4. Check code accessibility    Clone GitHub → look for .sol    No source = cannot audit
5. Check on-chain activity     BSCScan/Etherscan: tx count,   Low activity = abandoned
                               unique users, last tx date
6. Verify TVL is real          DeFiLlama + on-chain verify    Washed TVL = honeypot bait
```

**CRITICAL: Do NOT check Immunefi for small protocols ($100K-$5M TVL).**
Immunefi is for large bounties ($1M+). Small protocols won't be there.
Instead, check the protocol's own website for bug bounty pages, and scan on-chain.

**On-Chain Verification (the RIGHT way for small protocols):**

Instead of checking Immunefi/Code4rena (irrelevant for small protocols), verify on-chain:
```bash
# 1. Get contract address from DeFiLlama or project website
# 2. Check on BSCScan/Etherscan
cast call <contract> "owner()" --rpc-url $BSC_RPC
cast call <contract> "totalSupply()" --rpc-url $BSC_RPC

# 3. Check tx count and last activity
cast block-number --rpc-url $BSC_RPC
curl -s "https://api.bscscan.com/api?module=account&action=txlist&address=<contract>&startblock=0&endblock=99999999&sort=desc&apikey=<KEY>" | python3 -c "import json,sys; d=json.load(sys.stdin); print(f'Total txs: {len(d.get(\"result\",[]))}'); print(f'Last tx block: {d[\"result\"][0][\"blockNumber\"]}' if d.get('result') else 'No txs')"

# 4. Check if contract is verified (source code available)
curl -s "https://api.bscscan.com/api?module=contract&action=getsourcecode&address=<contract>&apikey=<KEY>" | python3 -c "import json,sys; d=json.load(sys.stdin); print('VERIFIED' if d['result'][0].get('SourceCode') else 'NOT VERIFIED')"
```

**Minimum verification workflow (UPDATED):**
1. DeFiLlama API → filter candidates
2. rekt.news search → eliminate exploited
3. GitHub clone → check for .sol files (not just adapter JS)
4. On-chain scan → verify contract exists, has activity, is verified
5. THEN start deep dive

**DeFiLlama Pitfalls (LEARNED THE HARD WAY — May 2026):**

- **Chain name is "Binance" NOT "BSC".** Filtering for `'BSC' not in chains` returns 0 results. Must use `'Binance' not in chains`. Other BSC-like chains: 'Boba_Bnb', 'Op_Bnb', 'svmBNB'.
- `audits: 0` in DeFiLlama API does NOT mean the protocol has no audit. DeFiLlama only tracks audits that are self-reported. Teller Protocol has Halborn audit. Compound Blue has Halborn + OpenZeppelin audits. Both show "0" in DeFiLlama.
- Protocols that were exploited still show their pre-exploit TVL in DeFiLlama. Mendi Finance (exploited May 2024, $1.6M loss) and Kinza Finance (exploited June 2024, $4.2M loss) both appeared as "viable" targets until rekt.news was checked.
- **Minimum verification workflow:** DeFiLlama API → rekt.news search → GitHub audit directory check → THEN start deep dive.
- **GitHub `github` field can be deceptive.** DeFiLlama's `github` array points to GitHub orgs, but those repos can be DeFiLlama adapter repos (JS/TS), NOT the protocol's Solidity contracts. Example: Dnax → "CarbonDeploy" → only `defillama-adapters/index.js`. Always check: clone the repo first, look for `.sol` files. If only JS/TS → contract is closed source → cannot source-audit.
- **Save the API response locally** (`curl -s 'https://api.llama.fi/protocols' -o /tmp/llama.json`) to avoid repeated 8MB downloads. Parse from local file for speed.

### Step 6: Target Scoring

```
DIMENSION              HIGH SCORE (10)                    LOW SCORE (1)
─────────────────────  ─────────────────────────────────  ─────────────────────
Exploit potential      Lending, CDP, complex math         Simple transfer, DEX
Code accessibility     Has GitHub, open source             Closed source
Chain maturity         New chain (Linea, Scroll, Base)     Ethereum (well-reviewed)
Audit status           Confirmed no audit                  Has professional audits
TVL sweet spot         $500K-$2M (worth it, weak)         >$5M (too scrutinized)
Solo-dev indicators    Small repo, few contributors        Large team, org-backed
```

Minimum viable target: Score ≥ 5 on exploit potential + code accessibility.

## Tool Conflict Resolution (CRITICAL)

When installing tools that have dependency conflicts:
- **Don't** list the conflict and ask user which to keep
- **Do** make a decisive judgment: which is redundant? which is essential?
- Drop the redundant tool yourself, explain why, verify remaining tools work
- User expects critical decision-making, not option-listing

### Final Tool Stack (as of May 2026)

| Tool | Version | Purpose | Status |
|------|---------|---------|--------|
| forge | 1.7.1 | Build, test, debug, fork, PoC | ESSENTIAL |
| slither | 0.11.5 | Static analysis, first-pass triage | ESSENTIAL |
| halmos | 0.3.3 | Symbolic testing (Foundry integration) | ESSENTIAL |
| medusa | 1.5.1 | Advanced fuzzing (Go-based) | HIGH |
| cast | 1.7.1 | Contract interaction, calldata encoding | ESSENTIAL |
| anvil | 1.7.1 | Local node, mainnet fork | HIGH |
| semgrep | 1.164.0 | Pattern matching | HELPFUL |
| solc | 0.8.35 | Solidity compiler | ESSENTIAL |

**Dropped:** mythril (redundant with halmos, caused dependency conflicts)

### Custom Tooling (Tier 1 — BUILT)

| Tool | Location | What it does |
|------|----------|--------------|
| Contract Interaction Scripts | `/workspaces/BUG-BOUNTY/tools/contract_interaction/` | state_reader.py, calldata_encoder.py, permission_checker.py, call_simulator.py, interface.py |
| Mainnet Fork Setup | Same directory | mainnet_fork.py (9 chains), quick_fork.sh (1-command fork) |
| **Full Audit Pipeline** | `/workspaces/BUG-BOUNTY/tools/onchain/pipeline.sh` | End-to-end: fetch→query→analyze→proxy→exploit→invariant→gate |
| **Target Discovery** | `/workspaces/BUG-BOUNTY/tools/bsc_target_pipeline.sh` | DeFiLlama API filter + BSCScan verification |
| **Audit Gate (Hakim Akhir)** | `/workspaces/BUG-BOUNTY/tools/onchain/audit_gate.sh` | CI gate: compile→test→slither→semgrep→proxy→score→verdict |
| **Confidence Scorer** | `/workspaces/BUG-BOUNTY/tools/onchain/confidence_scorer.py` | Auto HIGH/MED/LOW/NONE scoring per finding |
| **Proxy Checker** | `/workspaces/BUG-BOUNTY/tools/proxy_checker.py` | ERC1967/UUPS/Transparent slot analysis |
| **Exploit Patterns** | `/workspaces/BUG-BOUNTY/tools/exploit_suite/P_ExploitPatterns.t.sol` | 9 reusable exploit pattern detectors (incl. lzCompose) |
| **Invariant Template** | `/workspaces/BUG-BOUNTY/tools/exploit_suite/P_InvariantTemplate.t.sol` | StdInvariant stateful fuzzing |
| **Trace Simulator** | `/workspaces/BUG-BOUNTY/tools/trace_simulator.py` | Exploit tx trace & root-cause analysis |
| **RPC Config** | `/workspaces/BUG-BOUNTY/tools/rpc_config.sh` | Multi-endpoint BSC RPC fallback |

**Full pipeline workflow and confidence scoring rules:** See `bsc-smart-contract-audit` skill.
| **Full Audit Pipeline** | `/workspaces/BUG-BOUNTY/tools/onchain/pipeline.sh` | End-to-end: fetch→query→analyze→proxy→exploit→invariant→gate |
| **Target Discovery** | `/workspaces/BUG-BOUNTY/tools/bsc_target_pipeline.sh` | DeFiLlama API filter + BSCScan verification |
| **Audit Gate (Hakim Akhir)** | `/workspaces/BUG-BOUNTY/tools/onchain/audit_gate.sh` | CI gate: compile→test→slither→semgrep→proxy→score→verdict |
| **Confidence Scorer** | `/workspaces/BUG-BOUNTY/tools/onchain/confidence_scorer.py` | Auto HIGH/MED/LOW/NONE scoring per finding |
| **Proxy Checker** | `/workspaces/BUG-BOUNTY/tools/proxy_checker.py` | ERC1967/UUPS/Transparent slot analysis |
| **Exploit Patterns** | `/workspaces/BUG-BOUNTY/tools/exploit_suite/P_ExploitPatterns.t.sol` | 8 reusable exploit pattern detectors |
| **Invariant Template** | `/workspaces/BUG-BOUNTY/tools/exploit_suite/P_InvariantTemplate.t.sol` | StdInvariant stateful fuzzing |
| **Trace Simulator** | `/workspaces/BUG-BOUNTY/tools/trace_simulator.py` | Exploit tx trace & root-cause analysis |
| **RPC Config** | `/workspaces/BUG-BOUNTY/tools/rpc_config.sh` | Multi-endpoint BSC RPC fallback |
| **Testnet Block Scanner** | `/workspaces/BUG-BOUNTY/tools/testnet/block_scanner.py` | Scan blocks for active contract interactions |
| **Testnet Contract Analyzer** | `/workspaces/BUG-BOUNTY/tools/testnet/contract_analyzer.py` | Bytecode analysis, selector extraction, proxy detection |
| **Testnet DeFi Detector** | `/workspaces/BUG-BOUNTY/tools/testnet/defi_detector.py` | Detect DeFi vulnerability patterns (reentrancy, flash loan, oracle, bridge) |
| **Testnet Hunt Pipeline** | `/workspaces/BUG-BOUNTY/tools/testnet/hunt_pipeline.py` | Full pipeline: scan → analyze → detect → report |
| **Web Target Hunter** | `/workspaces/BUG-BOUNTY/tools/web_hunter.py` | Discover web targets via Exa search + Firecrawl crawl. TLD filtering (sedang/tinggi/sangat_tinggi only), security scoring, tech fingerprinting. Modes: gambling, defi, webapp, custom. |

**Full pipeline workflow and confidence scoring rules:** See `bsc-smart-contract-audit` skill.
| Confidence Scorer | `/workspaces/BUG-BOUNTY/tools/onchain/confidence_scorer.py` | Auto HIGH/MED/LOW scoring per finding |
| Audit Gate | `/workspaces/BUG-BOUNTY/tools/onchain/audit_gate.sh` | CI gate: compile→test→slither→semgrep→proxy→verdict |
| Proxy Checker | `/workspaces/BUG-BOUNTY/tools/proxy_checker.py` | ERC1967/UUPS/Transparent analysis |
| Exploit Patterns | `/workspaces/BUG-BOUNTY/tools/exploit_suite/P_ExploitPatterns.t.sol` | 8 reusable exploit pattern detectors |
| Invariant Template | `/workspaces/BUG-BOUNTY/tools/exploit_suite/P_InvariantTemplate.t.sol` | StdInvariant stateful fuzzing |
| Trace Simulator | `/workspaces/BUG-BOUNTY/tools/trace_simulator.py` | Exploit tx trace & root-cause |
| RPC Config | `/workspaces/BUG-BOUNTY/tools/rpc_config.sh` | Multi-endpoint BSC RPC fallback |

## Indonesian Gambling Site (Judol) Hunting

See `web-hunting-workflow` skill's `references/judol-site-patterns.md` for full patterns.

Key approach for judol:
1. Search Exa with Indonesian keywords + low-sec TLDs (.xyz, .top, .online, .site, .space, .cyou)
2. Filter OUT Cloudflare (check Server header)
3. Detect SPA catch-all (compare random path sizes — if similar, SKIP)
4. For real sites: check HTML metadata for related domains
5. Related domains often have directory listings with .zip source code leaks
6. PHP sites often have SQLi on login/voucher/code fields
7. N1TRO engine sites have company IDs in JS bundle URLs
8. QRIS payment APIs (qris.otomatis.vip) often lack username validation

User preference: INDONESIAN targets only. Frustrated by international targets ("itu luar bukan lokal").

## Pitfalls

### Continuity Pitfall
When user says "lanjutkan", "continue", or asks "apa yg belum" — they're referencing prior conversation state. Check `references/custom-tooling-checklist.md` status column FIRST. Don't guess or search blindly. If the checklist doesn't help, search ALL sessions (not just the most obvious one) — cross-session references happen (e.g. tools discussed in a cron session, referenced in an audit session).
### Before Competition Starts

1. **Monitor announcements** — Follow platforms on Twitter/Discord
2. **Check tech stack** — Can you handle the language/complexity?
3. **Assess competition** — Who else will participate?
4. **Prepare tools** — Ensure forge, slither, semgrep ready

### During Competition (2-4 weeks)

```
WEEK 1: Reconnaissance
  - Clone repo, setup environment
  - Run automated tools (slither, semgrep)
  - Map codebase structure
  - Identify high-risk areas

WEEK 2-3: Deep Dive
  - Focus on 2-3 critical areas
  - Manual review of complex logic
  - Write PoCs for suspicious patterns
  - Document findings thoroughly

WEEK 4: Polish & Submit
  - Verify all PoCs work
  - Write clear reports
  - Double-check severity ratings
  - Submit before deadline
```

### Finding Prioritization

```
SEVERITY    WHAT TO LOOK FOR                    PAYOUT POTENTIAL
──────────  ─────────────────────────────────── ─────────────────
Critical    Direct fund loss, minting bypass    $50K-$200K
High        Griefing, DoS, price manipulation  $10K-$50K
Medium      Logic errors, edge cases           $2K-$10K
Low         Admin issues, informational        $500-$2K
```

---

## Realistic Expectations

### Solo Auditor Success Rate

```
COMPETITION SIZE    YOUR CHANCE OF TOP 10    EXPECTED PAYOUT
──────────────────  ──────────────────────── ─────────────────
Small ($20-50K)     Good (if focused)        $1-5K
Medium ($100-200K)  Moderate                 $2-10K
Large ($500K+)      Low (unless specialized) $0-5K
```

### When to Skip

- **Mega bounties ($5M+)** — Teams of 20+ auditors, you won't find what they missed
- **Mature protocols** — Audited 5+ times, diminishing returns
- **Complex ZK/crypto** — Unless you have PhD-level math background
- **Rust/Cairo codebases** — Unless you're proficient in those languages

---

## Tool Stack (Confirmed Working — May 2026)

### Core (Always Available)

```bash
# Foundry suite
forge build && forge test -vvv
forge test --fuzz-runs 10000
cast call <addr> <sig>    # Read contract state
anvil --fork-url <rpc>    # Local mainnet fork

# Static analysis
slither . --filter-paths "lib|test"
semgrep --config=auto .

# Symbolic testing (Foundry integration)
halmos --match-test <test_name>

# Advanced fuzzing (Go-based, faster than Echidna)
medusa fuzzer
```
### Additional (When Needed)

```bash
# Halmos — symbolic testing for Foundry tests
halmos --function <test_name> --contract <ContractName>

# Medusa — advanced fuzzing with property checking
medusa fuzzer --config medusa.json

# Cast — ABI encoding, calldata generation
cast calldata <sig> <args>
cast sig <function_signature>
```

### Manual Review Focus Areas

1. **Access control** — Who can call what?
2. **Math operations** — Overflow, rounding, precision loss
3. **External calls** — Reentrancy, callback safety
4. **State changes** — Ordering, atomicity
5. **Edge cases** — Zero values, max values, empty arrays
6. **Cross-chain bridges** — lzCompose try-catch without recovery (P9 pattern, see bsc-smart-contract-audit skill)

---

## Pitfalls

### Domain Terminology Pitfall (User Correction — 2026-06-01)
When user uses gambling/bounty domain terms, interpret them as TARGET REFERENCES, not literal search keywords.
- "slot" = web slot gambling target (e.g. m-coy99), NOT a file named "slot"
- "hasil buruan" = bounty hunting findings/results, NOT hunting game data
- "target" = the protocol/site being hunted, not a generic word
- Indonesian casual: "hapus hasil result dari slot" = "delete all findings from the web slot target"

**Wrong approach:** `search_files(pattern="*slot*")` — literal filename search.
**Right approach:** Identify the domain context (gambling site = m-coy99), then find all files related to that target by name pattern (m-coy99*, coy99*, captcha*, mpoid*).

### Lokal vs Luar Pitfall (User Correction — 2026-06-01)
User explicitly wants INDONESIAN targets ("itu luar bukan lokal"). When hunting web targets:
- Use Indonesian keywords: "situs judi", "slot gacor", "togel online", "agen bola", "deposit pulsa", "slot88"
- Focus on .id market, not international casino review sites
- Skip foreign gambling directories/review sites
- Check if site language is Indonesian (bahasa Indonesia)

**Wrong approach:** Hunting generic "online casino" or foreign gambling sites.
**Right approach:** Hunt Indonesian-specific gambling sites with local payment methods (pulsa, DANA, OVO, GoPay).

### Workspace Cleanup Procedure (Learned — 2026-06-01)
When cleaning up a bug bounty workspace, these categories are safe to delete:

```
SAFE TO DELETE:
  [empty]       *_impl.sol files with 0 lines (failed fetches)
  [duplicate]   Files with identical content (diff to verify)
  [JSON wrap]   .sol files that are actually JSON containers (not real Solidity)
  [dead]        Targets from abandoned/exploited protocols (check rekt.news)
  [template]    Default Foundry templates (Counter.sol, Counter.t.sol, Counter.s.sol)
  [build]       artifacts/, cache/, out/, __pycache__/ (regenerable: forge build)
  [library]     lib/forge-std/ (regenerable: forge install foundry-rs/forge-std)
  [results]     testnet_results/, hunting results, PoC outputs (hunting mandiri: discard results)
  [data]        Large JSON dumps (protocols.json, autoshark.json) — user decision to keep or delete
  [captcha]     Captcha images from web recon (not reusable)
  [swagger]     API swagger/openapi JSON (target-specific, not reusable)
  [ethereal]    Appchain research notes (ethereal_research.md) — keep tools, discard findings

KEEP:
  Real .sol source files (check: >100 lines, unique content)
  Python tools/scripts (fetch_lista.py, pipeline scripts)
  Config files (foundry.toml, .env)
  DeFi JSON dumps — keep if still referenced, user decision to delete
  Guide/reference docs (guide-tools.md, guide-target.md, anti-blocker-toolkit.md)
```

**Verification before delete:** `wc -l *.sol` to spot empties, `md5sum *.sol` to find dupes, `head -5 *.sol` to spot JSON wrappers.

### Mindset Pitfalls (CRITICAL)

- **Treating code as external** — Code is your native environment, not something you "use"
- **Going off-script** — When told to standby, WAIT. Don't explore on your own
- **Generating random scripts** — Independent research = logical combination, not trial-and-error
- **Competing without custom tools** — Build your edge first, then compete
- **Focusing on bounty too early** — Sharpen skills before seeking payouts

### Exploitation vs Reporting Pitfall (CRITICAL — User Correction 2026-05-31)

**User said: "lu suruh masuk bukan bikin report gimana kerja nya cuma nemuin doang gak di masuki"**
**User said: "lu jangan nyari bug yg bikin read only tapi celah" (2026-06-02)**

When user asks to "run" or "exploit" an attack vector:
- **DON'T**: Write a report describing the vulnerability
- **DON'T**: Create fake test data and pretend it's real exploitation
- **DON'T**: Find only information disclosure (read-only bugs)
- **DO**: Actually execute the attack code against real targets
- **DO**: Show real output from the exploitation
- **DO**: Find EXPLOITABLE vulnerabilities (SQLi login bypass, fund theft, account takeover)
- **DO**: If no real targets exist, say so honestly — don't fabricate results

**"Celah" vs "Bug"**: User distinguishes between:
- **Bug** = informational finding (read-only, no impact)
- **Celah** = exploitable vulnerability (can actually steal/manipulate/bypass)

Always prioritize CELAH over bug. A SQLi login bypass that gives full account access is a CELAH. A missing security header is just a bug.

**User said: "apaan result nya abababababababab gimana laporan nya kalo hasilnya ababababab"**

When testing exploits:
- **DON'T**: Create fake target files with fake data, then "steal" from yourself
- **DON'T**: Use placeholder data (abababab, 0x1234...) as "results"
- **DO**: Search for real public targets (GitHub forks, committed configs, on-chain data)
- **DO**: If no real targets exist, demonstrate the attack path with honest acknowledgment
- **DO**: Report what data COULD be stolen, not fake stolen data

**User said: "kenapa diri sendiri tidak public?"**

When local testing produces no real results:
- **DON'T**: Stop and say "no results"
- **DO**: Search GitHub for forks/commits with real data
- **DO**: Search on-chain for active users/miners
- **DO**: Check public pastes, Discord, Telegram for leaked configs
- **DO**: Be honest about what's findable vs what's not

### Attack Surface Analysis (Non-Contract Targets)

For non-smart-contract targets (Python tools, mining software, etc.):
1. **Find the vulnerability** (code review)
2. **Write PoC** (actual exploit code)
3. **Search for real targets** (GitHub forks, public configs, on-chain users)
4. **Execute against real targets** (if available)
5. **Report honestly** (what was found, what wasn't)

**Don't confuse "demonstration" with "exploitation".** A demo shows how it works. An exploitation shows it working against a real target.

### Continuity Pitfall
When user says "lanjutkan", "continue", or asks "apa yg belum" — they're referencing prior conversation state. Check `references/custom-tooling-checklist.md` status column FIRST. Don't guess or search blindly. If the checklist doesn't help, search ALL sessions (not just the most obvious one) — cross-session references happen (e.g. tools discussed in a cron session, referenced in an audit session).

### Tool Conflict Resolution (CRITICAL)
When installing tools that have dependency conflicts:
- **Don't** list the conflict and ask user which to keep
- **Do** make a decisive judgment: which is redundant? which is essential?
- Drop the redundant tool yourself, explain why, verify remaining tools work
- User expects critical decision-making, not option-listing

### Common Mistakes

- **Spreading too thin** — Better to deep-dive 2 areas than shallow-review 10
- **Ignoring test suite** — Tests reveal intended behavior and edge cases
- **Not writing PoC** — Unverified findings get rejected
- **Submitting low-quality reports** — Clear description, impact, PoC
- **Missing the deadline** — Set calendar reminders

### Verification: On-Chain > Web Platforms (User Correction)

**For small protocols ($100K-$5M TVL), verification MUST happen on-chain, not on web platforms.**

```
WRONG APPROACH (web-based):          RIGHT APPROACH (on-chain):
─────────────────────────────        ──────────────────────────────
Check Immunefi for bounty            Scan contract on BSCScan
Check Code4rena for contests         Read contract source on BSCScan
Check Sherlock for audits            Check contract state via cast
Search rekt.news by name             Verify tx count + last activity
```

**Why:** Small protocols won't be on Immunefi/Code4rena/Sherlock. They're too small.
The real verification is: does the contract exist, is it active, is source verified, are there real users?

**Verification tools:**
- `cast call` — read contract state
- BSCScan/Etherscan API — tx history, source verification
- DeFiLlama API — TVL, chains, category
- GitHub clone — check for actual .sol files

### When You're Stuck

1. Check if similar bugs exist in past audit reports
2. Look at test cases for edge cases the team already knows
3. Read protocol documentation for intended behavior
4. Ask in competition Discord (if available)
5. Move to a different area and come back later

---

## Post-Competition

### If You Find Something

1. **Verify thoroughly** — Can you reproduce it consistently?
2. **Write clear PoC** — Include setup, steps, expected vs actual
3. **Quantify impact** — How much can be lost/stolen?
4. **Check severity** — Does it match platform criteria?
5. **Submit early** — Don't wait until last minute

### If You Don't Find Anything

- Review what others found (post-competition reports)
- Identify what you missed and why
- Update your approach for next time
- Consider if the competition was the right fit

---

## Multi-Chain Source Fetching

When hunting on non-BSC chains (Cronos, Etherlink, Mantle, Ink, Sonic, Plasma):

**Read first:** `/workspaces/BUG-BOUNTY/anti-blocker-toolkit.md` — has the canonical fallback chain for each chain including RPC endpoints, explorer APIs, and the 8-step retrieval order.

**See also:** `bsc-smart-contract-audit` skill's `references/multi-chain-source-fetching.md` — covers Cronos cronos.org/explorer/api workaround, Blockscout v2 API, Sourcify lookup, fork-diff hypothesis, bytecode selector extraction, and known fork baselines (Liquity for Orby/Cronos, MasterChef for CronaSwap, etc.).

**Key insight for non-BSC chains:** Many chains use Blockscout-style explorers. The explorer API often works when the web UI is blocked. Example: Cronos cronos.org/explorer/api works where cronoscan.com is blocked.

## Support Files

- `references/platform-status.md` — Current competition/bounty status (update periodically)
- `references/custom-tooling-checklist.md` — Concrete checklist of tools to build before competing (3 tiers, 9 tools). Track completion status here. User asked "tools apa saja yg belum" — this is the file to check first.
- `references/defi-target-verification.md` — DeFi target verification data: exploited protocols, false audit flags, verification workflow. Cross-check before deep dive.
- `references/bscscan-v2-source-fetching.md` — BSCScan V2 API quirks (multi-file source JSON format, EIP-1967 proxy detection via Infura RPC, impl slot reading). CRITICAL: read before fetching source for any new target.
- `references/multi-chain-source-fetching.md` (in bsc-smart-contract-audit skill) — Multi-chain source fetching: Cronos cronos.org/explorer/api, Blockscout v2, Sourcify, fork-diff hypothesis, bytecode selectors, known fork baselines.
- `references/defi-attack-patterns.md` — Advanced DeFi attack patterns (10 vectors): multicall abuse, subaccount isolation, EIP-712 domain confusion, sequencer trust, withdrawal routing, pause griefing, proxy upgrade, token manipulation, oracle manipulation, re-initialization.
- `references/testnet-rpc-config.md` — Testnet RPC endpoints (Sepolia, Base Sepolia, appchains), cast usage, scan pipeline commands.
- `references/web-target-discovery.md` — Web target discovery with web_hunter.py: Exa search, Firecrawl crawl, TLD filtering, security scoring. Modes: gambling, defi, webapp, custom.
- `references/hermes-agent-security-config-protection.md` — Hermes agent config write protection mechanism (v0.15.1+): two-layer defense, approval gate patterns, protected paths. Reference for understanding agent security architecture.

## References

- [Cantina Competitions](https://cantina.xyz/opportunities/competitions)
- [Sherlock Contests](https://app.sherlock.xyz/contests)
- [Code4rena Audits](https://code4rena.com/audits)
- [Immunefi Bounties](https://immunefi.com/bounty/)
- [Past Audit Reports](https://github.com/pessimistic-io/audits)
- [SWC Registry](https://swcregistry.io/) — Smart contract weaknesses
