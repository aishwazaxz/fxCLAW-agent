# Web Target Discovery with web_hunter.py

## Overview

`tools/web_hunter.py` discovers web targets using Exa search + Firecrawl crawl.
Focus on serious targets (sedang/tinggi/sangat_tinggi TLDs only).

## Modes

| Mode | Purpose | Example |
|------|---------|---------|
| gambling | Find gambling/betting sites | `python3 tools/web_hunter.py gambling -r indonesia -n 20 --analyze` |
| defi | Find DeFi protocols | `python3 tools/web_hunter.py defi -c bsc -n 10 --analyze` |
| webapp | Find new web apps | `python3 tools/web_hunter.py webapp --category fintech -n 10` |
| custom | Custom search query | `python3 tools/web_hunter.py custom -q "new betting site" -n 10` |

## Options

- `--analyze`: Analyze each target (server, tech, security score)
- `--crawl`: Crawl discovered targets for endpoints (limit 5)
- `-o FILE`: Save results as JSON
- `-r REGION`: Region for gambling mode (default: indonesia)
- `-c CHAIN`: Chain for DeFi mode (default: bsc)
- `--category CATEGORY`: Web app category (general, ecommerce, fintech, gaming)

## Security Scoring

Each target gets a score 0-6 based on security headers:
- strict-transport-security: +2
- content-security-policy: +2
- x-frame-options: +1
- x-xss-protection: +1
- x-content-type-options: +1

**Levels:**
- LOW (0-1): Missing most headers — easiest targets
- MEDIUM (2-3): Some headers present
- HIGH (4+): Good security posture

## TLD Filtering

Blacklist TLDs (spam/scam): .xyz, .top, .icu, .cfd, .sbs, .click, .link, etc.
See `references/tld-filtering.md` in webapp-bug-bounty skill for full list.

## Output

Without `-o`: prints to terminal with analysis
With `-o FILE`: saves JSON with all data (url, title, analysis, endpoints)

## Prerequisites

- EXA_API_KEY in .env
- FIRECRAWL_API_KEY in .env
- Python packages: firecrawl-py, exa-py, requests, beautifulsoup4

## Example Workflow

```bash
# 1. Find targets
python3 tools/web_hunter.py gambling -n 20 --analyze -o targets.json

# 2. Review results
cat targets.json | python3 -m json.tool

# 3. Pick target with lowest security score
# 4. Deep dive with webapp-bug-bounty skill methodology
```
