# Custom Tooling Checklist

Track completion status. When user asks "tools apa saja yg belum" — check this file first.

## Tier 1: Core Pipeline (DONE ✅)

| # | Tool | Status | Location |
|---|------|--------|----------|
| 1 | Full Audit Pipeline | ✅ DONE | `tools/onchain/pipeline.sh` |
| 2 | Target Discovery (DeFiLlama) | ✅ DONE | `tools/onchain/bsc_target_pipeline.sh` |
| 3 | Audit Gate (hakim akhir) | ✅ DONE | `tools/onchain/audit_gate.sh` |
| 4 | Confidence Scorer | ✅ DONE | `tools/onchain/confidence_scorer.py` |
| 5 | Proxy Checker | ✅ DONE | `tools/onchain/proxy_checker.py` |
| 6 | Exploit Pattern Suite | ✅ DONE | `tools/onchain/exploit_suite/P_ExploitPatterns.t.sol` |
| 7 | Invariant Template | ✅ DONE | `tools/onchain/exploit_suite/P_InvariantTemplate.t.sol` |
| 8 | Trace Simulator | ✅ DONE | `tools/onchain/trace_simulator.py` |
| 9 | RPC Config | ✅ DONE | `tools/onchain/rpc_config.sh` |

## Tier 2: Contract Interaction (DONE ✅)

| # | Tool | Status | Location |
|---|------|--------|----------|
| 1 | State Reader | ✅ DONE | `tools/onchain/contract_interaction/state_reader.py` |
| 2 | Calldata Encoder | ✅ DONE | `tools/onchain/contract_interaction/calldata_encoder.py` |
| 3 | Permission Checker | ✅ DONE | `tools/onchain/contract_interaction/permission_checker.py` |
| 4 | Call Simulator | ✅ DONE | `tools/onchain/contract_interaction/call_simulator.py` |
| 5 | Unified Interface | ✅ DONE | `tools/onchain/contract_interaction/interface.py` |
| 6 | Mainnet Fork Setup | ✅ DONE | `tools/onchain/contract_interaction/mainnet_fork.py` |
| 7 | Quick Fork Script | ✅ DONE | `tools/onchain/contract_interaction/quick_fork.sh` |

## Tier 3: Advanced (NOT STARTED)

| # | Tool | Status | Purpose |
|---|------|--------|---------|
| 1 | Flash Loan Template | ❌ NOT STARTED | Aave V3 flash loan PoC scaffold |
| 2 | Storage Layout Differ | ❌ NOT STARTED | Diff storage between proxy upgrades |
| 3 | Selector Resolver | ❌ NOT STARTED | Auto-decode bytecode selectors to function names |
| 4 | Cross-Contract Mapper | ❌ NOT STARTED | External call graph across contracts |
