# Testnet RPC Configuration

## Active Testnet RPCs (verified working 2026-06-01)

| Chain | Chain ID | RPC | Explorer |
|-------|----------|-----|----------|
| Ethereum Sepolia | 11155111 | https://ethereum-sepolia-rpc.publicnode.com | https://sepolia.etherscan.io |
| Base Sepolia | 84532 | https://sepolia.base.org | https://sepolia.basescan.org |

## Appchain Testnets

| Protocol | Chain ID | RPC | Explorer |
|----------|----------|-----|----------|
| Ethereal | 13374202 | https://rpc.etherealtest.net | https://explorer.etherealtest.net |
| Ethereal Mainnet | 5064014 | https://rpc.ethereal.trade | https://explorer.ethereal.trade |

## Usage with cast

```bash
# Set RPC in .env
SEPOLIA_RPC=https://ethereum-sepolia-rpc.publicnode.com
BASE_SEPOLIA_RPC=https://sepolia.base.org

# Basic commands
cast chain-id --rpc-url $SEPOLIA_RPC
cast block-number --rpc-url $SEPOLIA_RPC
cast block latest --rpc-url $SEPOLIA_RPC --json

# Contract interaction
cast code <address> --rpc-url $RPC
cast call <address> "function()(type)" --rpc-url $RPC
cast storage <address> <slot> --rpc-url $RPC

# Transaction analysis
cast tx <hash> --rpc-url $RPC
cast receipt <hash> --rpc-url $RPC
```

## Appchain Notes

- Appchains often have custom sequencers (check miner address)
- Gas tokens may be custom (e.g., USDe for Ethereal)
- EIP-712 domains include chainId + verifyingContract
- Proxy patterns are common (EIP-1967, UUPS)
- Block production may use system contracts (e.g., startBlock)

## Scan Pipeline

```bash
# Scan blocks for active contracts
python tools/testnet/block_scanner.py -b 10 -m 3 -o results.json

# Analyze specific contract
python tools/testnet/contract_analyzer.py <address> -c sepolia

# Detect DeFi vulnerabilities
python tools/testnet/defi_detector.py <address>

# Full pipeline
python tools/testnet/hunt_pipeline.py -c sepolia -b 5 -n 5
```
