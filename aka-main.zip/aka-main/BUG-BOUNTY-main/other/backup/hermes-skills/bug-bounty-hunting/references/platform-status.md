# Platform Status Reference

Last updated: 2026-05-30

## Active Competitions (as of May 2026)

### Cantina
- Morpho Midnight — $400K USDC, ends ~June 12, 2026
- (Check `cantina.xyz/opportunities/competitions` for latest)

### Sherlock
- All contests finished/judging as of May 2026
- (Check `app.sherlock.xyz/contests` for new ones)

### Code4rena
- K2 (Stellar, Rust) — $135K, judging phase
- Jupiter Lend (Solana, Rust) — $107K, judging phase
- (Check `code4rena.com/audits` for latest)

### Immunefi
- 217 ongoing bug bounty programs
- 1 live audit competition (check site)
- (Check `immunefi.com/bounty/` → Audit Competitions tab)

## Top Ongoing Bounties (Cantina)

| Protocol          | Pool            | Started    |
|-------------------|-----------------|------------|
| Uniswap Labs      | $15,500,000     | Nov 2024   |
| Reserve Protocol  | $10,000,000     | Mar 2026   |
| Euler             | 7.5M + tokens   | Aug 2024   |
| Polymarket        | $5,000,000      | Apr 2026   |
| Coinbase          | $5,000,000      | Jul 2025   |
| Morpho            | $2,500,000      | Mar 2024   |
| Pendle Finance    | $2,000,000      | Jun 2024   |
| dYdX              | $1,000,000      | May 2026   |
| Paxos             | $1,000,000      | Mar 2026   |
| OKX Labs          | $1,000,000      | Jan 2026   |

## Cantina Leaderboard Top 5 (May 2026)

| Rank | Researcher      | Earnings      | Findings | High | Medium |
|------|-----------------|---------------|----------|------|--------|
| 1    | zigtur          | $932,505.92   | 109      | 57   | 52     |
| 2    | Haxatron        | $656,891.08   | 86       | 39   | 47     |
| 3    | alexfilippov314 | $542,256.27   | 28       | 11   | 17     |
| 4    | hash            | $471,225.36   | 45       | 16   | 29     |
| 5    | dontonka        | $408,490.81   | 30       | 9    | 21     |

**Reality check**: These auditors have years of experience, custom tooling, and track record. Solo auditors with only public tools cannot compete head-to-head.

## Fresh Targets (Low Competition)

Based on start date analysis:
- **dYdX** (May 2026) — Very fresh, less competition
- **Polymarket** (Apr 2026) — Relatively new
- **Reserve Protocol** (Mar 2026) — Large pool, newer

## Competition vs Bounty Decision Matrix

```
IF (solo auditor AND limited tools):
  PREFER competitions (time-boxed, fair start)
  AVOID mega bounties ($5M+) unless domain expert
  
IF (have prior knowledge of protocol):
  PREFER that protocol's competition/bounty
  
IF (new protocol, < 3 months old):
  HIGHER opportunity (less eyes on it)
```
