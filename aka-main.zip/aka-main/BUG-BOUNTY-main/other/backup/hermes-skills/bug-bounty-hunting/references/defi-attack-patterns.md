# DeFi Attack Patterns Reference

## Advanced Attack Surface (Non-Basic)

These are NOT basic reentrancy/overflow. These are protocol-specific attack vectors that require deep understanding of the protocol architecture.

### 1. Multicall Atomicity Abuse
- **Pattern**: Multicall batches multiple calls in 1 tx
- **Attack**: deposit + immediate withdraw to bypass settlement delays
- **Check**: Does multicall use CALL or DELEGATECALL?
- **Risk**: LOW if regular CALL (each sub-call checks auth independently)
- **Risk**: CRITICAL if DELEGATECALL (can execute arbitrary code in proxy context)

### 2. Subaccount Isolation Bypass
- **Pattern**: Subaccounts are bytes32 identifiers
- **Attack**: Predict/cross subaccounts, cross-subaccount fund movement
- **Check**: How are subaccounts derived? Address-based? Salt-based?
- **Risk**: MEDIUM if predictable derivation

### 3. EIP-712 Domain Confusion
- **Pattern**: Off-chain signatures with EIP-712 typed data
- **Attack**: Signature replay across chains, domain separator manipulation
- **Check**: Does domain include chainId + verifyingContract?
- **Risk**: LOW if domain properly includes chain-specific fields
- **Risk**: HIGH if bridge forwards signatures without domain check

### 4. Sequencer Trust Assumption
- **Pattern**: Custom sequencer for order matching (appchains)
- **Attack**: MEV extraction, censorship, downtime griefing
- **Check**: Is sequencer centralized? Fallback mechanism?
- **Risk**: STRUCTURAL (single point of failure)

### 5. Cross-Chain Withdrawal Routing
- **Pattern**: Withdrawals with destinationEndpointId
- **Attack**: Route funds to attacker's chain, replay on destination
- **Check**: Is destinationEndpointId validated? Whitelist?
- **Risk**: HIGH if user-controlled and not validated

### 6. Emergency Pause Griefing
- **Pattern**: Emergency pause blocks ALL operations
- **Attack**: Pause and refuse to unpause, lock all funds
- **Check**: Does pause block withdrawals? Who can pause?
- **Risk**: HIGH if pause blocks withdrawals and no timelock

### 7. Proxy Upgrade Hijacking
- **Pattern**: UUPS proxy with upgradeToAndCall
- **Attack**: If owner compromised, instant drain via malicious implementation
- **Check**: Is there a timelock? Who is owner?
- **Risk**: HIGH if no timelock

### 8. Token Management Manipulation
- **Pattern**: addToken/removeToken by owner
- **Attack**: Remove token = lock user funds, Add malicious token = fake deposits
- **Check**: Who can add/remove tokens? Oracle validation?
- **Risk**: HIGH if owner-only with no timelock

### 9. Oracle Manipulation (Synthetic Positions)
- **Pattern**: Synthetic positions depend on oracle price
- **Attack**: Manipulate oracle to profit from positions
- **Check**: What oracle? TWAP? Single source?
- **Risk**: HIGH if single-source oracle

### 10. Re-Initialization
- **Pattern**: UUPS proxy with initialize() function
- **Attack**: Call initialize() again to become owner
- **Check**: Is initialize() protected by initialized flag?
- **Risk**: CRITICAL if not protected (InvalidInitialization error = safe)

## Detection Patterns (Function Selectors)

```python
ATTACK_PATTERNS = {
    "reentrancy": ["0x6e553f65", "0x2e17de78", "0x69328dec", "0xdb006a75"],
    "flash_loan": ["0xab9c4b5d", "0x5cffe9de", "0xa0712d68"],
    "oracle": ["0x9dc29fac", "0x40c10f19", "0xf2fde38b"],
    "access_control": ["0xf2fde38b", "0x8da5cb5b", "0x70a08231"],
    "supply_manipulation": ["0x40c10f19", "0x9dc29fac", "0x2ef6f1ab", "0xc6c3bbe6"],
    "bridge": ["0x2ef6f1ab", "0xabd31150", "0xcd2e9866", "0x8b9e4f93"],
    "upgradeable": ["0x3659cfe6", "0xf2fde38b", "0x8da5cb5b"],
}
```

## Appchain-Specific Attack Surface

Appchains (like Ethereal) have additional attack vectors beyond standard smart contracts:

1. **Sequencer centralization** — single entity controls order matching
2. **Custom gas tokens** — economic manipulation possible
3. **Cross-chain settlement** — bridge vulnerabilities
4. **Data availability** — Celestia dependency
5. **EIP-712 signature systems** — off-chain signing with on-chain verification

## Analysis Workflow

1. Get contract bytecode
2. Extract function selectors (PUSH4 opcodes = 0x63)
3. Decode via 4byte.directory (`cast 4byte`)
4. Detect proxy pattern (EIP-1167, EIP-1967)
5. Read implementation via EIP-1967 slot
6. Classify contract type (DEX, lending, bridge, staking)
7. Map attack surface based on function selectors
8. Test attack vectors on testnet first
