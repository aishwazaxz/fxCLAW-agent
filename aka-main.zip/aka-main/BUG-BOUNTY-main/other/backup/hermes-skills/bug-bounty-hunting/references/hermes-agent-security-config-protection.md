# Hermes Agent Config Write Protection (v0.15.1+)

Reference: `#14639` — blocks agent from silently modifying `~/.hermes/config.yaml`.

## Why It Matters

`config.yaml` IS the security policy. Contains:
- `approvals.mode` (manual/smart/off)
- `yolo` flag
- Permanent-approval allowlist

Config cache uses `mtime` — write takes effect **mid-session** without restart.
Agent could flip `approvals.mode: off` and immediately bypass all gates.

## Two-Layer Protection

### Layer 1: File Tools (`tools/file_tools.py`)

Function: `_check_sensitive_path()`

Blocks:
- `write_file("~/.hermes/config.yaml", ...)` → REFUSED
- `patch("~/.hermes/config.yaml", ...)` → REFUSED
- Resolves symlinks, caches path at import time

Error message: "Refusing to write to Hermes config file... Agent cannot modify security-sensitive configuration."

### Layer 2: Terminal/Approval Gate (`tools/approval.py`)

Function: `detect_dangerous_command()` + regex patterns

Path patterns matched:
```
~/.hermes/config.yaml
$HOME/.hermes/config.yaml
${HOME}/.hermes/config.yaml
$HERMES_HOME/config.yaml
${HERMES_HOME}/config.yaml
```

Command patterns that trigger approval:
| Pattern | Description |
|---------|-------------|
| `sed -i ... config.yaml` | In-place edit (short flag) |
| `sed --in-place ... config.yaml` | In-place edit (long flag) |
| `tee ... config.yaml` | Overwrite via tee |
| `> config.yaml` | Overwrite via redirection |
| `>> config.yaml` | Append via redirection |
| `cp ... config.yaml` | Copy overwrite |
| `mv ... config.yaml` | Move overwrite |

### What's NOT Blocked

- `cat ~/.hermes/config.yaml` (read is safe)
- `hermes config set ...` (CLI resmi)
- `hermes config edit` (editor)
- Direct manual edit (`vim`, `nano`)

## Other Protected Paths (Same Mechanism)

- `~/.hermes/.env`
- `/etc/` and `/private/etc/` (macOS mirror)
- `~/.bashrc`, `~/.zshrc`, `~/.profile`, `~/.bash_profile`, `~/.zprofile`
- `~/.netrc`, `~/.pgpass`, `~/.npmrc`, `~/.pypirc`
- `/dev/sd*` (disk devices)
- Project `.env` and `config.yaml` (separate pattern)

## Key Source Files

- `tools/file_tools.py` — `_check_sensitive_path()`, `_HERMES_CONFIG_PATH`
- `tools/approval.py` — `DANGEROUS_PATTERNS`, `_SENSITIVE_WRITE_TARGET`
- `tests/tools/test_file_tools.py` — TestHermesConfigWriteProtection
- `tests/tools/test_approval.py` — TestHermesConfigWriteProtection

## For Security Researchers

This is a defense-in-depth pattern worth studying:
1. **Layer 1** blocks the agent's own file manipulation tools
2. **Layer 2** blocks shell commands the agent might craft to bypass Layer 1
3. Both layers share the same path resolution logic
4. The mtime-based config cache is the root cause of why this matters

Attack surface if protection is missing:
- Agent writes `approvals.mode: off` → bypasses all approval prompts
- Agent writes `security.redact_secrets: false` → leaks credentials in logs
- Agent modifies `tool_use_enforcement` → removes safety constraints
