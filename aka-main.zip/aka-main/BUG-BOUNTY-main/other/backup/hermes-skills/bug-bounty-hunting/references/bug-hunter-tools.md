# Bug Hunter Tools (From Logic, Not Search)

## Core Tool Categories

### 1. Static Analysis
- Analyze code without executing
- Pattern matching, taint analysis, control flow
- Examples: Slither, Semgrep

### 2. Fuzzing
- Generate random input, find edge cases
- Property-based testing, stateful fuzzing
- Examples: Medusa, Foundry Fuzz

### 3. Formal Verification / Symbolic Testing
- Mathematical proof or symbolic path exploration
- Examples: Halmos (Foundry-integrated)

### 4. Dynamic Analysis
- Runtime execution, trace, debug
- Examples: Foundry (forge test), Anvil fork

### 5. Bytecode Analysis
- Analyze compiled bytecode, not source
- Decompile, reverse engineer
- Examples: abi-decompiler

### 6. On-Chain Monitoring
- Monitor transactions in real-time
- Detect suspicious activity
- Examples: Forta, Tenderly Alerts, custom bots

### 7. Exploit Framework
- Template to build and test exploits
- Fork mainnet, simulate attack
- Examples: Foundry (mainnet fork via anvil)

### 8. Custom Scripts
- Python/Bash for automation
- Parse ABI, generate test, batch analysis

## Tool Selection by Goal

```
WHAT TO FIND           BEST TOOLS
─────────────────────  ─────────────────────────────────
Reentrancy             Fuzzing + Static Analysis
Flash loan exploit     Fork testing + Exploit framework
Logic bug              Halmos + Manual review
Edge case              Medusa fuzzing + Halmos
Access control         Slither + Manual review
Oracle manipulation    Fork testing + Custom monitoring
```

## Installed in This Environment (Updated May 2026)

```bash
# Foundry v1.7.1 (at ~/.foundry/bin/)
forge    # Build, test, fuzz, debug, deploy
cast     # Interact with contracts, call functions, parse data
anvil    # Local Ethereum node, fork mainnet
chisel   # Solidity REPL, quick testing

# Static Analysis
slither  # v0.11.5 (at ~/.local/bin/)
semgrep  # v1.164.0 (at ~/.local/bin/)

# Fuzzing
medusa   # v1.5.1 (at /go/bin/) — Go-based EVM fuzzer

# Symbolic Testing
halmos   # v0.3.3 — Foundry-integrated symbolic testing

# Build Tools
rustc    # v1.96.0 (at ~/.cargo/bin/)
cargo    # v1.96.0
go       # v1.26.1 (at /usr/local/go/bin/)
solc     # v0.8.35
python3  # v3.12.1
node     # v22+
git      # v2.53.0

# Dropped
# mythril — redundant with halmos, caused dependency conflicts
```

### Coverage Assessment (as of May 2026)
```
STATIC ANALYSIS    : slither ✓  semgrep ✓
FUZZING            : medusa ✓  forge fuzz ✓
SYMBOLIC EXECUTION : halmos ✓
FORMAL             : halmos ✓
BUILD              : rust ✓  cargo ✓  go ✓

Coverage: ~85% (mythril dropped — redundant with halmos)
```

## Custom Tool Ideas

### Flash Loan Template (P1 — NOT STARTED)
- Aave V3 flash loan contract for exploit PoCs
- 90% of DeFi exploits use flash loans
- Template: borrow → exploit → repay in single tx

### Mainnet Fork Setup (P1 — NOT STARTED)
- Script to fork with specific block number
- Preset whale accounts for token funding
- `anvil --fork-url <rpc> --fork-block-number <block>`

### Contract Interaction Scripts (P1 — NOT STARTED)
- Python scripts to automate contract reads
- Decode events, parse state, batch calls
- Speed up research phase of each audit

### Access Control Mapper (P2 — NOT STARTED)
- Parse solc output JSON for external functions
- Map roles → functions → who can call
- Output: role-function matrix

### DeFi Pattern Detector (P2 — NOT STARTED)
- Parse all external calls
- Check if state changes happen after
- Flag potential CEI violations
- Cross-reference with known vulnerable patterns
