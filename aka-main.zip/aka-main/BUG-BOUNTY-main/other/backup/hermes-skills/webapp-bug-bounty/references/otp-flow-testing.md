# OTP Flow Testing & Username Enumeration

## OTP Login Flow Architecture

Many gambling/betting sites use OTP-based login (Telegram, WhatsApp, SMS) instead of traditional passwords.

```
User → Click "Login with Telegram"
     → Modal opens (data-target="#telegram_login_popup_modal")
     → Enter username
     → POST /login-otp/request/{channel}
     → Server sends OTP via Telegram bot
     → User enters OTP
     → POST /Account/OtpLogin (form action)
     → Server verifies OTP → session created
```

## Username Enumeration via OTP Endpoint

### Discovery Pattern

```python
otp_url = base + "/login-otp/request/Telegram"

# Test with X-Requested-With header to get JSON response
data = urllib.parse.urlencode({
    "Username": username,
    "VisitorId": fingerprint,  # ThumbmarkJS or similar
}).encode()

req = urllib.request.Request(otp_url, data=data, headers={
    "User-Agent": "Mozilla/5.0",
    "Content-Type": "application/x-www-form-urlencoded",
    "X-Requested-With": "XMLHttpRequest",
    "Accept": "application/json, */*",
})
```

### Error Code Mapping (Real-World Example: Griffin/MPOPlay)

| errorCode | Message | Account Status |
|-----------|---------|----------------|
| 0 | Success | Active, OTP sent |
| 10 | "Anda belum pernah mendaftar melalui Telegram App" | Exists, not linked to channel |
| 39 | "Akun Anda tidak aktif" | Exists, inactive/disabled |
| (HTML) | "Akun Anda telah ditangguhkan" | Exists, locked (too many attempts) |

### Response Structure

```json
{
    "errorCode": 0,
    "message": "OTP sent successfully",
    "expiryInSeconds": 120,
    "receiver": "***",
    "otpId": "abc123",
    "statusReason": "",
    "resendThreshold": 3,
    "resendCount": 0
}
```

Key fields:
- `expiryInSeconds`: OTP validity window (brute force window)
- `resendThreshold`: Max resends before lockout
- `otpId`: Reference for verification endpoint
- `receiver`: Masked contact info (leaks partial data)

## OTP Verification Endpoint Discovery

```python
# Common patterns
otp_verify_paths = [
    "/login-otp/verify",
    "/login-otp/confirm",
    "/login-otp/validate",
    "/Account/VerifyOtp",
    "/Account/ConfirmOtp",
    "/Account/ValidateOtp",
    "/api/v1/Player/VerifyContactDetail",
    "/api/v1/Telegram/VerifyContactDetail",
    "/api/v1/Player/LoginWithOTP",
]
```

## ASP.NET MVC Login Form Structure

```html
<!-- Standard login form -->
<form action="/Account/Login" method="post">
    <input name="__RequestVerificationToken" type="hidden" value="..." />
    <input name="Username" type="text" />
    <input name="Password" type="password" />
    <input name="VisitorId" type="hidden" class="visitor_id_input" />
</form>

<!-- OTP login form (Telegram) -->
<form action="/Account/OtpLogin" id="login_otp_form" method="post">
    <input name="__RequestVerificationToken" type="hidden" value="..." />
    <input name="Username" id="login_otp_username" type="text" />
    <input name="otp" type="hidden" class="otp_hidden_input" data-channel-type="Telegram" />
    <input name="VisitorId" type="hidden" class="visitor_id_input" />
    <input type="button" id="telegram_login_get_otp_submit_button" 
           data-otp-channel="Telegram" value="Kirim" />
</form>

<!-- Social login form -->
<form action="/Account/SocialLogin" id="social_login_form" method="post">
    <input name="__RequestVerificationToken" type="hidden" value="..." />
    <input name="Token" type="hidden" id="login_social_token_input" />
    <input name="SocialLinkClient" type="hidden" id="login_social_link_client_input" />
    <input name="VisitorId" type="hidden" class="visitor_id_input" />
</form>
```

## Registration Flow Analysis

ASP.NET MVC registration often returns JSON:

```json
{
    "status": true,
    "message": "Registration successful",
    "statusText": "Berhasil",
    "externalUrl": "https://...",  // Open redirect if controllable
    "desktopUrl": "/desktop/home",
    "mobileUrl": "/mobile/home",
    "redirectUrl": "..."
}
```

### Registration Form Fields (Typical Gambling Site)

```
_token (CSRF)
ipAddress (hidden - can manipulate!)
username (6-15 alphanumeric)
password (8-25 chars)
password_confirmation
email
phone (required)
accName (bank account name - required)
accNumber (bank account number - required)
bank (required)
referral (optional)
captcha (required)
term (checkbox - required)
```

## Browser Fingerprinting Detection

```javascript
// Check for fingerprinting libraries
typeof ThumbmarkJS !== 'undefined'  // ThumbmarkJS v1.3.x
typeof FingerprintJS !== 'undefined'  // FingerprintJS
typeof Fingerprint2 !== 'undefined'  // Fingerprint2

// Get fingerprint value
ThumbmarkJS.getThumbmark(function(hash) { 
    document.querySelector('.visitor_id_input').value = hash; 
});

// Check if fingerprint is set
document.querySelector('.visitor_id_input').value
```

## Telegram Login Widget Detection

```javascript
// Check for Telegram Login Widget
document.querySelector('#telegram_login_popup_modal')
document.querySelector('#telegram_login_button')
document.querySelector('[data-otp-channel="Telegram"]')

// Modal attributes
modal.dataset.socialLinkClient  // "Telegram", "Google", etc.
modal.dataset.title  // Modal title

// Hidden inputs
document.querySelector('#login_social_token_input')
document.querySelector('#login_social_link_client_input')
document.querySelector('.otp_hidden_input')
```

## Attack Venarios

### 1. Username Harvesting
- Enumerate all usernames via OTP endpoint
- Build database of valid accounts
- Categorize: active, inactive, suspended, Telegram-linked

### 2. Account Targeting
- Focus on SUSPENDED accounts (may have weak passwords)
- Focus on INACTIVE accounts (may be abandoned)
- Focus on active accounts with Telegram linked (highest value)

### 3. OTP Brute Force
- If OTP is 6 digits: 1,000,000 combinations
- If expiry is 120 seconds: ~8,333 attempts/second needed
- Rate limiting is critical defense

### 4. Social Login Bypass
- If `SocialLinkClient` can be manipulated
- If `Token` field accepts arbitrary values
- If callback URL not validated

## Remediation Recommendations

1. **Unify error messages**: "If account exists, OTP sent"
2. **Rate limit enumeration**: Per IP, per username, CAPTCHA after N attempts
3. **Hide error codes**: Don't expose errorCode to client
4. **OTP rate limiting**: Max attempts per OTP, exponential backoff
5. **Fingerprint validation**: Verify VisitorId matches session
