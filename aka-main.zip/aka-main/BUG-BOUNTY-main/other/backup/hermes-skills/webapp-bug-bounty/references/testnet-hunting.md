# Testnet Hunting Tools

Tools for autonomous smart contract hunting on testnets (Sepolia, Base Sepolia, custom appchains).

## Tools

### block_scanner.py
Scans recent blocks for active contract interactions.
```bash
python3 tools/testnet/block_scanner.py -b 10 -m 3 -o results.json
```

### contract_analyzer.py
Deep analysis of individual contracts — bytecode, selectors, proxy detection, storage.
```bash
python3 tools/testnet/contract_analyzer.py 0xCONTRACT -c sepolia -o analysis.json
```

### defi_detector.py
Detects DeFi vulnerability patterns — reentrancy, flash loan, oracle, access control, bridge risks.
```bash
python3 tools/testnet/defi_detector.py 0xCONTRACT -o vulns.json
```

### hunt_pipeline.py
Main pipeline — scan → analyze → detect → report.
```bash
python3 tools/testnet/hunt_pipeline.py -c sepolia -b 10 -n 10
python3 tools/testnet/hunt_pipeline.py -c base_sepolia -b 5 -n 5
python3 tools/testnet/hunt_pipeline.py -c both -b 3 -n 3
```

## Chain Configs

| Chain | RPC | Chain ID |
|-------|-----|----------|
| Sepolia | https://ethereum-sepolia-rpc.publicnode.com | 11155111 |
| Base Sepolia | https://sepolia.base.org | 84532 |

## Key Patterns Detected

- **DEX**: swap, addLiquidity, removeLiquidity
- **Lending**: borrow, repay, liquidate, deposit, withdraw
- **Bridge**: mint (cross-chain), supplyToBacking, bridgeTokens
- **Staking**: stake, unstake, claim, withdraw
- **Token**: transfer, approve, balanceOf, mint, burn

## Appchain Hunting

For custom appchains (like Ethereal):
1. Check chain ID and RPC from docs
2. Find verifying contract from API config
3. Analyze proxy pattern (EIP-1967, UUPS)
4. Decode all function selectors
5. Check sequencer/owner centralization
6. Test emergency pause behavior
7. Analyze withdrawal routing (cross-chain)

## Output

Results saved to `testnet_results/`:
- `{chain}_contracts.json` — Active contracts
- `{chain}_analysis_{addr}.json` — Contract analysis
- `{chain}_vulns_{addr}.json` — Vulnerability findings
- `{chain}_report_{timestamp}.json` — Full report
- `{chain}_report_{timestamp}.md` — Markdown summary
