# Case Study: kemonbet.com (Indonesian Gambling Site)

## Target Profile
- Domain: kemonbet.com
- Server: Cloudflare (WAF)
- Framework: Laravel (PHP)
- Session: gp_slot_session
- Related domains: kemonbetawi.com, durenkocok.com
- Asset CDN: media.mediatelekomunikasisejahtera.com

## Recon Results

### Real vs Catch-All Endpoints (Baseline Filtering)
Baseline: 16881 bytes, 1823 words, 2 lines

REAL endpoints (different from baseline):
- /dashboard → 302 (850 bytes) — requires auth
- /login → 200 (113KB) — real login page
- /register → 200 (169KB) — real registration
- /.htaccess → 200 (603 bytes) — real file
- /web.config → 200 (1194 bytes) — real file
- /sitemap.xml → 200 (5504 bytes) — real file
- /robots.txt → 200 (87 bytes) — real file

ALL other paths (/.env, .git/config, phpmyadmin, admin, api, etc.) = catch-all (same 17383 bytes)

### Confirmed Vulnerabilities

1. **User Enumeration (MEDIUM)**
   - Endpoint: POST /register/check_user
   - 13 users found: admin, user, bandar, boss, manager, deposit, withdraw, referral, hoki, gacor, maxwin, jackpot, slot
   - No rate limiting

2. **Clickjacking (LOW-MEDIUM)**
   - X-Frame-Options header MISSING on all pages

3. **CSRF Token Not Enforced (MEDIUM)**
   - Login accepts requests without CSRF token (302 redirect)

4. **Server Error 500 (LOW)**
   - /games/slot and /games/casino return 500 (generic error page)

5. **Bank Account Validation Leak (LOW)**
   - POST /register/check_bank_account accepts any input

6. **No Rate Limiting (MEDIUM)**
   - All API endpoints callable without limits

### False Positives
- Login brute force: ALL FALSE (login always returns 326-byte redirect)
- SSRF in bank_account: NOT FETCHED (just stored and returned)
- SQLi in bank_name: NOT VULNERABLE (input returned as-is)
- Path traversal: NOT VULNERABLE
- Command injection: NOT VULNERABLE

### Key Lessons
1. TLD (.xyz vs .com) doesn't determine security — Cloudflare WAF protects both
2. Laravel catch-all routes return 200 for everything — must use baseline filtering
3. Login forms may return redirect regardless of credentials — verify with garbage input
4. User enumeration is often the only real finding on well-protected sites
5. Shared infrastructure (multiple domains, shared CDN) expands attack surface
