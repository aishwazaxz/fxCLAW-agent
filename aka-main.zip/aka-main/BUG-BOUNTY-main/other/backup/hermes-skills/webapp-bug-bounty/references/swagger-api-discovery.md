# Swagger / API Documentation Discovery

## Discovery Checklist

### Paths to probe (every domain + subdomain)
```
/api, /api/v1, /api/v2
/swagger, /swagger/v1/swagger.json, /swagger/v2/swagger.json
/api-docs, /api/docs, /api/documentation
/api/openapi.json, /api/openapi.yaml
/graphql, /graphiql, /graphql/playground
/health, /status, /info, /version
```

### Subdomains to check
Image CDNs, URL shorteners, game launchers, asset hosts — ALL may have exposed APIs.

## Swagger JSON Extraction

```python
import json, urllib.request, ssl
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

url = "https://api2-target.imgnxb.com/api/v1"
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
resp = urllib.request.urlopen(req, timeout=30, context=ctx)
body = resp.read(500000).decode('utf-8', errors='replace')
swagger = json.loads(body)

# Extract metadata
print(f"Title: {swagger.get('info', {}).get('title')}")
print(f"Version: {swagger.get('info', {}).get('version')}")
print(f"Host: {swagger.get('host')}")

# Extract all endpoints
paths = swagger.get('paths', {})
for path, methods in sorted(paths.items()):
    for method, details in methods.items():
        tags = details.get('tags', [])
        params = [p.get('name') for p in details.get('parameters', [])]
        print(f"  {method.upper()} {path} [{tags}] params={params}")

# Extract database models
definitions = swagger.get('definitions', {})
for name, schema in sorted(definitions.items()):
    props = list(schema.get('properties', {}).keys())
    print(f"  {name}: {props}")
```

## Key Attack Patterns

### 1. Scheduler/SecretKey endpoints
```
GET /api/v1/Scheduler/TestAPI/{MerchantCode}/{Currency}/{SecretKey}
```
SecretKey in URL = logged in server logs, browser history, proxy logs.

### 2. Version information leak
```
GET /api/v1/Version/Current
Response: "AppName:v1.28.16/eb2da30b-89c3-448c-a0a3-868f9249ae1e"
```

### 3. Admin endpoints without auth
Some admin endpoints may respond without authentication.

### 4. Library version from $ref paths
```json
{"$ref": "#/definitions/...Newtonsoft.Json, Version=11.0.0.0"}
```

### 5. Database schema from definitions
Each definition = a database table/model. Fields reveal column names, types, relationships.

### 6. WAF bypass patterns
Different endpoints have different WAF rules. Test ALL — WAF may only block "dangerous" ones.

## Real-World Example: Griffin Web API

Target: `api2-coy.imgnxb.com`
- API: Griffin Web API v1.28.16
- Endpoints: 323, Models: 347
- Namespaces: NexusCom.Api.Griffin.Entities.*
- Findings: Full DB schema, admin endpoints accessible, SecretKey in URL, version leak

### Griffin API Endpoint Categories

| Category | Count | Key Endpoints |
|----------|-------|---------------|
| Admin | 21 | ChangeTemplate, UpdateAdminPassword, Reset2FA, GetBankList, GetWhitelistIP |
| Player | 45 | Login, Registration, ForgotPassword, GetProfile, DepositForm, WithdrawalForm |
| Scheduler | 22 | TestAPI, AutoDepositReferralClaim, JackpotWinner, WinOverThreshold |
| Affiliate | 18 | Login, Register, GetReferreeListing, Withdraw |
| Game | 18 | SlotGame, GetJackpot, GetJackpotWinner, GetLotteryDrawInfo |
| Vendor | 18 | Login, UpdateGameList, UpdateGameStatus |
| Telegram | 4 | Login, Registration, SendOtp, VerifyContactDetail |
| Staff | 5 | CheckStaffExist, UpdateStaffRole, UpdateStaffStatus |
| Message | 9 | TicketCreate, GetMessageList, InsertTicketMessage |
| Report | 20 | GetTransaction, GetDepositHistory, GetWithdrawalHistory |
| Loyalty | 20 | ClaimLoyaltyPoint, Redeem, GetMissionList |

### Griffin API Authentication

All requests require:
```json
{
    "timestamp": "1234567890",
    "checksum": "md5(timestamp + merchantCode)",
    "merchantCode": "merchant-id"
}
```

### Griffin API Sensitive Fields in Models

```
password, oldPassword, newPassword
secretKey, salt, checksum, heimdallAuthToken
bankAccountNumber, bankAccountName
contactNumber, email, address
ipAddress, mac, browser, deviceId, visitorId
otp, referralCode, merchantCode
```

### Griffin Scheduler SecretKey Pattern

```
GET /api/v1/Scheduler/{action}/{MerchantCode}/{Currency}/{SecretKey}
```

Accessible endpoints:
- `/api/v1/Scheduler/UpdateBuildVersion` → errorCode=0 (no auth!)
- `/api/v1/Scheduler/TestAPI/{mc}/{cur}/{key}` → errorCode=2 (InvalidRequest with wrong key)

### Griffin Version Endpoint

```
GET /api/v1/Version/Current
Response: "Griffin:v1.28.16/eb2da30b-89c3-448c-a0a3-868f9249ae1e"
```

### Griffin WAF Behavior

- Player/Admin/Affiliate endpoints: 403 (blocked by WAF)
- Scheduler endpoints: 200 (accessible)
- Version endpoints: 200 (accessible)
- Swagger JSON: 200 (accessible)
