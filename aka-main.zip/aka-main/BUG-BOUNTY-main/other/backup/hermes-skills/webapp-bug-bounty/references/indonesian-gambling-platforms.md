# Indonesian Gambling Platform Patterns

## Platform Identification

### MPOPlay (Laravel-based)
- **X-Powered-By**: `MPOPlay V2.0 Final Release`
- **Session cookie**: `mpoplay_frontend_session`
- **CSRF cookie**: `XSRF-TOKEN` (Laravel standard)
- **Backend**: Laravel (PHP)
- **Server**: Often LiteSpeed on AWS EC2
- **CDN**: Cloudflare + images.linkcdn.cloud
- **APK hosting**: S3 buckets (apk-depot.s3.*.amazonaws.com)

**Registration fields**:
```
_token, ipAddress (hidden, controllable!), username (6-15 chars),
password (8-25 chars), password_confirmation, email, phone,
accName (bank account name), accNumber (bank account number),
bank (select), referral (optional), captcha, term (checkbox)
```

**Key endpoints**:
```
/register (POST - Laravel form)
/login (POST - Laravel form)
/forgot-password
/help, /contact, /event
```

**Common subdomains**: mantap*.com, mpoid*.xyz, klickmpo.me

### Griffin Web API (ASP.NET)
- **API**: `api2-{prefix}.imgnxb.com/api/v1`
- **Swagger**: `/api/v1` (JSON, often 400KB+)
- **Version**: `Griffin:v1.28.16/{git-hash}`
- **Auth**: timestamp + checksum (md5?) + merchantCode in POST body
- **CDN**: images.linkcdn.cloud/V2/{merchantId}/

**Merchant code locations**:
- Image CDN path: `V2/{merchantId}/` (e.g., V2/276/)
- API CDN path: `images/{merchantCode}/` (e.g., images/mbskzr3xtvc/)
- Game launcher: `casinoid={id}` parameter

**Endpoint categories**:
- Admin (21): ChangeTemplate, UpdateAdminPassword, Reset2FA
- Player (45): Login, Registration, ForgotPassword, GetProfile
- Scheduler (22): TestAPI, AutoDepositReferralClaim (SecretKey in URL!)
- Affiliate (18): Login, Register, Withdraw
- Game (18): SlotGame, GetJackpot, GetLotteryDrawInfo
- Vendor (18): Login, UpdateGameList, UpdateGameStatus
- Telegram (4): Login, Registration, SendOtp

**Scheduler SecretKey pattern**:
```
GET /api/v1/Scheduler/{action}/{MerchantCode}/{Currency}/{SecretKey}
```
- UpdateBuildVersion often accessible without auth
- TestAPI returns errorCode=2 (InvalidRequest) with wrong key

### Common Game Providers
- Pragmatic Play: demogamesfree-{region}.pragmaticplay.net
- JILI: jiligames.com/plusplayer/
- Habanero: d24m60q82dzu8y.cloudfront.net/launcher/
- Spade Gaming: spade-event.com
- PG Soft: public.pg-demo.com
- Hacksaw, NoLimitCity, Microgaming, FiveGG, Playtech

### External Services Pattern
- **Image upload**: plcl.me (PHP, has login/register)
- **URL shortener**: linkyurl.com (IIS)
- **Jackpot API**: jp-api2.namesvr.dev/progressive-jackpot
- **Telegram bot**: t.me/{site}_bot
- **WhatsApp**: wa.me/{number}

## Attack Surface Summary

1. **Exposed Swagger API** = full database schema leak
2. **phpinfo.php** = origin IP + server config leak
3. **Registration with bank account** = phishing target
4. **CAPTCHA-only protection** = bypass with solving services
5. **ipAddress field controllable** = IP spoofing
6. **Multiple domain aliases** = each is attack surface
7. **APK download from S3** = reverse engineering target
8. **Telegram bot** = social engineering vector

## OTP Login Flow (Griffin/MPOPlay)

Both platforms support OTP-based login via Telegram:

**Endpoints**:
```
POST /login-otp/request/{channel}  # Send OTP (channel = Telegram, WhatsApp, SMS)
POST /Account/OtpLogin             # Verify OTP and login
GET  /Account/TelegramLogin        # Telegram login page
GET  /Account/TelegramCallback     # Telegram OAuth callback
```

**Username enumeration via OTP**:
- errorCode=10: Account exists, not linked to Telegram
- errorCode=39: Account exists, inactive
- SUSPENDED: Account exists, locked (too many attempts)
- No rate limiting = full user database harvestable

**Response structure**:
```json
{
    "errorCode": 0,
    "expiryInSeconds": 120,
    "receiver": "***",
    "otpId": "abc123",
    "resendThreshold": 3,
    "resendCount": 0
}
```

### ONIX Platform (Laravel + Flutter + Cloudflare)
- **API**: `api-onix-ns2.seamless-hptech.com`
- **Backend**: Laravel (PHP) + MongoDB
- **Mobile**: Flutter APK (com.jangkar55, etc.)
- **Firebase**: `api-onix-ns2-live2-default-rtdb.firebaseio.com` (often READ OPEN)
- **CDN**: `css.apkstore888.com` (HTTP!), `files.sitestatic.net`
- **Payment**: VaderPay (stageapi.vaderpay.net), Help2Pay (stgpay.ug396-api.com)

**Critical headers (ALL THREE required):**
```
d-key: CS2ABA0          # Domain key (unique per app)
domain_key: CS2ABA0      # Same value as d-key
agent_id: CS2ABA0        # Same value as d-key
```
Without all three → 500 with "Invalid access (domain_key - empty, agent_id - empty)"

**CSRF handling:**
```
1. GET /ajaxCSRFToken (with all 3 headers) → {"data": "token_value"}
2. POST to any endpoint with _token=token_value in BODY (header alone does NOT work)
```

**Username enumeration via login:**
```
POST /login with wrong password:
  "tidak terdaftar" = username NOT registered
  "password salah"  = username EXISTS (different error!)
```

**Config leak via GET /register (returns JSON, not HTML):**
- 49 banks with MongoDB ObjectIDs
- 10 e-wallet fund methods (DANA, OVO, GOPAY, etc.)
- OTP disabled flag (`is_disable_otp: true`)
- Honeypot field structure (4 fields, 1 with hardcoded value)
- Password/account name regex patterns
- Registration token format: `CS2ABA0-{timestamp}-{random}`
- Admin usernames in `created_by`/`updated_by` fields

**Apps sharing same infrastructure:**
jangkar55 (CS2ABA0), asgacor (CS2ABCA), juara126 (CS2ABAJ),
leon188 (CS2ABA1), nona55 (CS2ABAG), platinum789 (CS2ABAH)

**Payment gateway infrastructure:**
- `stgapicurr.seamlesss-hptech.com` (45.194.53.26) — CF 403 / HTTPS 500
- `stgapi.seamlesss-hptech.com` (45.194.53.52) — HTTPS 500
- `admin.seamlesss-hptech.com` (45.194.53.26) — admin panel exists
- All HTTPS endpoints return 500 (backend down but infrastructure confirmed)

## Severity Quick-Ref

| Finding | Severity |
|---------|----------|
| Swagger API exposed | CRITICAL |
| phpinfo.php accessible | CRITICAL |
| DOM XSS (innerHTML sink) | CRITICAL |
| Open redirect (externalUrl) | HIGH |
| Origin IP leaked | HIGH |
| Session cookie no Secure | HIGH |
| Missing CSP | HIGH |
| Scheduler SecretKey in URL | HIGH |
| Version info leak | MEDIUM |
| Bank account in registration | MEDIUM |
| ONIX /register config leak | CRITICAL |
| ONIX username enum via login | HIGH |
| ONIX CSRF no-auth token | MEDIUM |
| Payment gateway subdomains (500) | MEDIUM |
