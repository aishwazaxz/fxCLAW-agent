# TLD Filtering for Web Target Selection

## Philosophy

**Low-security TLDs = TARGETS** (easier to find bugs). High-security TLDs = SKIP (serious operators). This is the REVERSE of traditional thinking — we WANT the poorly-secured sites.

## TARGET TLDs (Low Security — Our Hunting Ground)

These TLDs cost $1-3/year, have minimal verification, and attract less serious operators.

### Ultra-cheap ($1-3/year)
```
.xyz  .top  .icu  .cfd  .sbs  .click  .link
.surf  .rest  .cam  .bond  .monster  .buzz
.space  .website  .press  .fun  .online  .site
.store  .tech  .club  .pw  .cc  .ws
```

### Free/abused
```
.tk  .ml  .ga  .cf  .gq
```

### Low-quality generic
```
.work  .gdn  .bid  .download  .racing  .review
.stream  .win  .accountant  .science  .party
.trade  .date  .faith  .loan  .men
.vip  .wang  .ren  .kim  .mom  .dad
.zip  .mov  .game  .lol  .rocks
.cheap  .farm  .estate
```

## SKIP TLDs (High Security — Avoid)

These TLDs cost $5-20+/year or require verification. Serious operators with security teams.

### Premium ($10-20+/year)
```
.com  .net  .org  .de  .uk  .fr  .it  .es
.nl  .be  .se  .no  .dk  .fi  .pl  .cz
.at  .ch  .ie  .pt  .gr  .ro  .hu  .sk
.ca  .br  .mx  .ar  .cl  .pe
.za  .ng  .ke  .eg
```

### Regional ($5-15/year)
```
.io  .co  .me  .info  .biz  .asia
.id  .my  .sg  .ph  .th  .vn  .in
.kr  .jp  .tw  .hk  .au  .nz
```

### Institutional (requires verification)
```
.edu  .gov  .mil  .bank  .insurance
```

## Why Target Low-Security TLDs

1. **Cheaper domains** → less serious operators
2. **Admin jarang update** → default configs, unpatched software
3. **No compliance** → don't care about security headers, SSL config
4. **Many automated setups** → exposed debug endpoints, default credentials
5. **Target audience doesn't care** → users won't report security issues
6. **Higher turnover** → sites abandoned with exposed data

## Implementation in web_hunter.py

```python
# LOW security = our targets
TLD_TARGETS = [
    "xyz", "top", "icu", "cfd", "sbs", "click", "link",
    "surf", "rest", "cam", "bond", "monster", "buzz",
    "space", "website", "press", "fun", "online", "site",
    "store", "tech", "club", "pw", "cc", "ws", "tk",
    "ml", "ga", "cf", "gq", "work", "gdn", "bid",
    "download", "racing", "review", "stream", "win",
    "accountant", "science", "party", "trade", "date",
    "faith", "loan", "men", "vip", "wang", "ren",
    "kim", "mom", "dad", "zip", "mov", "game",
    "lol", "rocks", "cheap", "farm", "estate",
]

# HIGH security = skip these
TLD_SKIP = [
    "com", "net", "org", "de", "uk", "fr", "it", "es",
    "nl", "be", "se", "no", "dk", "fi", "pl", "cz",
    "at", "ch", "ie", "pt", "gr", "ro", "hu", "sk",
    "ca", "br", "mx", "ar", "cl", "pe", "za", "ng",
    "edu", "gov", "mil", "bank", "insurance",
    "io", "co", "me", "info", "biz", "asia",
    "id", "my", "sg", "ph", "th", "vn", "in",
    "kr", "jp", "tw", "hk", "au", "nz",
]

def is_target(url):
    tld = get_tld(url)
    if tld in TLD_TARGETS:
        return True  # Low security = our target
    if tld in TLD_SKIP:
        return False  # High security = skip
    return True  # Unknown = might be interesting
```

## Target Categories by TLD

### Indonesian Gambling Sites
Best TARGET TLDs: .xyz, .online, .site, .fun, .top
Common patterns: situs judi, slot online, agen bola, togel, poker

### DeFi/Web3
Note: .xyz is used by many legitimate Web3 protocols (exception to the rule)
Best TLDs: .finance, .app, .xyz (for Web3 only)

### General Web Apps
Best TARGET TLDs: .online, .site, .tech, .club, .store
