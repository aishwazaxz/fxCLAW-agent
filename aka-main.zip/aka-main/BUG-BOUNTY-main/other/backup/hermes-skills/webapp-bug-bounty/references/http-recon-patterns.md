# HTTP Recon Patterns — Copy-Paste Ready

## 1. Full HTTP Recon (headers, cookies, body extraction)

```python
import urllib.request, ssl, re
from urllib.parse import urlparse

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

url = "https://TARGET/"
parsed = urlparse(url)

req = urllib.request.Request(url, headers={
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
})
resp = urllib.request.urlopen(req, timeout=15, context=ctx)
body = resp.read(200000).decode('utf-8', errors='replace')

# Headers
for h in ['Server','X-Powered-By','X-AspNet-Version','X-AspNetMvc-Version',
          'Content-Security-Policy','X-Frame-Options','Strict-Transport-Security',
          'X-Content-Type-Options','Referrer-Policy','Permissions-Policy','X-XSS-Protection']:
    print(f"  {h}: {resp.headers.get(h,'MISSING')}")

# Cookies with security flags
cookies = resp.headers.get_all('Set-Cookie') or []
for c in cookies:
    print(f"  Cookie: {c[:150]} | Secure={'Secure' in c} HttpOnly={'HttpOnly' in c} SameSite={'SameSite' in c}")

# Extract links, scripts, forms, APIs
links = re.findall(r'href=["\']([^"\']+)["\']', body)
scripts = re.findall(r'src=["\']([^"\']*\.js[^"\']*)["\']', body)
forms = re.findall(r'<form[^>]*action=["\']([^"\']*)["\'][^>]*>', body, re.I)
ajax = re.findall(r'url:\s*["\']([^"\']+)', body)
```

## 2. Endpoint Brute Probe

```python
import urllib.request, ssl

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

paths = [
    "/api", "/api/v1", "/swagger", "/swagger/v1/swagger.json",
    "/.env", "/robots.txt", "/sitemap.xml",
    "/.git/config", "/.git/HEAD", "/web.config",
    "/elmah.axd", "/trace.axd",
    "/admin", "/panel", "/dashboard",
    "/graphql", "/.well-known/security.txt",
    "/crossdomain.xml", "/clientaccesspolicy.xml",
]

for path in paths:
    req = urllib.request.Request(base + path, headers={"User-Agent": "Mozilla/5.0"})
    try:
        resp = urllib.request.urlopen(req, timeout=10, context=ctx)
        body = resp.read(500).decode('utf-8', errors='replace')
        interesting = any(kw in body.lower() for kw in ['password','token','secret','admin','error','exception','config'])
        print(f"  {resp.status} {path} {'***' if interesting else ''}")
    except urllib.error.HTTPError as e:
        print(f"  {e.code} {path}")
    except: pass
```

## 3. CORS Misconfiguration Check

```python
for origin in ["https://evil.com", "https://TARGET", "null"]:
    req = urllib.request.Request(base + "/", headers={
        "User-Agent": "Mozilla/5.0", "Origin": origin
    })
    resp = urllib.request.urlopen(req, timeout=10, context=ctx)
    acao = resp.headers.get('Access-Control-Allow-Origin', 'N/A')
    acac = resp.headers.get('Access-Control-Allow-Credentials', 'N/A')
    print(f"  Origin={origin} -> ACAO={acao} ACAC={acac}")
```

## 4. Registration Form Extraction (AJAX with session)

```python
import http.cookiejar, urllib.parse

cj = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(cj),
    urllib.request.HTTPSHandler(context=ctx)
)

# Get homepage (establish session)
resp = opener.open(urllib.request.Request(base, headers={"User-Agent": "Mozilla/5.0"}))

# Get registration form via AJAX
req = urllib.request.Request(base + "/Register/AjaxRegisterPopup?language=id",
    data=urllib.parse.urlencode({"hostname": parsed.netloc}).encode(),
    headers={
        "User-Agent": "Mozilla/5.0",
        "X-Requested-With": "XMLHttpRequest",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Origin": base,
        "Referer": base + "/",
    })
resp = opener.open(req, timeout=15)
form_html = resp.read(20000).decode('utf-8', errors='replace')

# Extract fields, CSRF, validation rules
fields = re.findall(r'name="([^"]+)"', form_html)
csrf = re.findall(r'__RequestVerificationToken.*?value="([^"]+)"', form_html)
patterns = re.findall(r'data-val-regex-pattern="([^"]*)"', form_html)
remote_urls = re.findall(r'data-val-remote-url="([^"]*)"', form_html)
```

## 5. Cookie Security Audit (automated)

```python
def audit_cookies(resp):
    cookies = resp.headers.get_all('Set-Cookie') or []
    findings = []
    for c in cookies:
        name = c.split('=')[0]
        issues = []
        if 'Secure' not in c: issues.append('NO_SECURE')
        if 'HttpOnly' not in c and 'Session' in name: issues.append('NO_HTTPONLY')
        if 'SameSite' not in c: issues.append('NO_SAMESITE')
        if issues:
            findings.append(f"  [HIGH] {name}: {', '.join(issues)}")
    return findings
```

## 6. Username Enumeration via Remote Validation

```python
# ASP.NET MVC remote validation endpoint
for username in ["admin","test","support","operator","root"]:
    val_data = urllib.parse.urlencode({"UserName": username}).encode()
    req = urllib.request.Request(base + "/validate/username",
        data=val_data,
        headers={
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "RequestVerificationToken": csrf_token,
        })
    resp = opener.open(req, timeout=10)
    body = resp.read(500).decode('utf-8', errors='replace')
    # JSON true = valid, false = taken
    print(f"  '{username}': {body[:50]}")
```

## 7. External Asset Mapping

```python
# Extract all external domains from HTML
external_domains = set()
for match in re.findall(r'https?://([^/"\'>\s]+)', body):
    if not match.endswith(parsed.netloc):
        external_domains.add(match)

# Probe each for info disclosure
for domain in sorted(external_domains):
    req = urllib.request.Request(f"https://{domain}/", headers={"User-Agent": "Mozilla/5.0"})
    try:
        resp = urllib.request.urlopen(req, timeout=10, context=ctx)
        server = resp.headers.get('Server', 'N/A')
        cors = resp.headers.get('Access-Control-Allow-Origin', 'N/A')
        print(f"  {resp.status} {domain} Server={server} CORS={cors}")
    except: pass
```

## 8. Open Redirect Testing

```python
redirect_tests = [
    "/Account/Login?ReturnUrl=//evil.com",
    "/Account/Login?returnUrl=https://evil.com",
    "/Account/Login?ReturnUrl=/%2f/evil.com",
    "/Account/Login?ReturnUrl=\\evil.com",
    "/?redirect=https://evil.com",
    "/?next=https://evil.com",
    "/?url=https://evil.com",
    "/?goto=https://evil.com",
]
for path in redirect_tests:
    req = urllib.request.Request(base + path, headers={"User-Agent": "Mozilla/5.0"})
    try:
        resp = urllib.request.urlopen(req, timeout=10, context=ctx)
        loc = resp.headers.get('Location', 'none')
        if 'evil.com' in str(loc):
            print(f"  !!! OPEN REDIRECT: {path} -> {loc}")
    except urllib.error.HTTPError as e:
        loc = e.headers.get('Location', 'none')
        if 'evil.com' in str(loc):
            print(f"  !!! OPEN REDIRECT: {path} -> {loc}")
```

## 10. Username Enumeration via OTP Endpoint

```python
# OTP-based login enumeration (Telegram, WhatsApp, SMS)
otp_url = base + "/login-otp/request/Telegram"

for username in ["admin", "test", "user", "member", "support", "operator", "root"]:
    data = urllib.parse.urlencode({
        "Username": username,
        "VisitorId": "0b856761004212db8cfc24c3f5fe92eef78c596433059bae4fe7738ba1e40b9a",
    }).encode()
    
    req = urllib.request.Request(otp_url, data=data, headers={
        "User-Agent": "Mozilla/5.0",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json, */*",
    })
    resp = opener.open(req, timeout=10)
    result = json.loads(resp.read())
    
    # Error code mapping (site-specific):
    # errorCode=0:  Success (OTP sent) → account active
    # errorCode=10: Not registered via channel → account exists
    # errorCode=39: Inactive account → account exists but disabled
    # SUSPENDED:    Locked account → too many attempts
    print(f"  {username}: errorCode={result.get('errorCode')} msg={result.get('message','')[:50]}")
```

## 11. Browser-based API Interception

```javascript
// Set up interceptors BEFORE triggering action
(function() {
    var intercepted = [];
    var originalXHR = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        intercepted.push({type: 'xhr', method: method, url: url, time: Date.now()});
        return originalXHR.apply(this, arguments);
    };
    var originalFetch = window.fetch;
    window.fetch = function(url, options) {
        intercepted.push({type: 'fetch', method: (options && options.method) || 'GET', url: url.toString()});
        return originalFetch.apply(this, arguments);
    };
    var originalOpen = window.open;
    window.open = function(url, target, features) {
        intercepted.push({type: 'window.open', url: url, target: target});
        return originalOpen.apply(this, arguments);
    };
    window._intercepted = intercepted;
})();

// After triggering action, check captured requests:
JSON.stringify(window._intercepted)
```

## 12. Brand/Merchant ID Extraction

```python
# From CDN image paths
# https://images.linkcdn.cloud/V2/276/logo/... → merchant ID = 276
# https://api2-coy.imgnxb.com/images/mbskzr3xtvc/... → merchant code = mbskzr3xtvc

# From game launcher URLs
# ?casinoid=1135 → casino ID = 1135
# ?brandid=825cc3ca-3cb4-ee11-b660-6045bd5af406 → brand ID (UUID)

# These IDs are often the merchantCode for API authentication
cdn_paths = re.findall(r'(?:images\.linkcdn\.cloud|api2-[^.]+\.imgnxb\.com)/([^/]+)', body)
game_ids = re.findall(r'(?:casinoid|brandid|merchantid)=([^&"\']+)', body, re.I)
```

## 13. Tech Stack Fingerprinting Quick Reference

```python
tech_signals = {
    'ASP.NET': ['ASP.NET_SessionId', '__RequestVerificationToken', 'data-ajax=', 'X-AspNet-Version'],
    'PHP': ['PHPSESSID', 'X-Powered-By: PHP', '/wp-content/', '/wp-includes/'],
    'Node.js': ['X-Powered-By: Express', 'connect.sid', '__next'],
    'Django': ['csrftoken', 'django', '__django'],
    'Rails': ['_rails_session', 'X-Powered-By: Phusion Passenger'],
    'Laravel': ['laravel_session', 'XSRF-TOKEN'],
    'WordPress': ['wp-content', 'wp-includes', 'wp-json'],
    'Drupal': ['Drupal', 'X-Drupal-Cache', 'X-Generator: Drupal'],
    'AWS': ['AWSALB', 'AWSALBCORS', 'AWSELB'],
    'Cloudflare': ['Server: cloudflare', 'cf-ray', '__cfduid'],
    'CloudFront': ['cloudfront.net', 'X-Amz-Cf-Id'],
}
```
