---
name: solana-mining-protocol-attack
description: "Attack patterns for Solana Proof-of-Activity mining protocols - re-attest abuse, score manipulation, hashrate decay bypass"
metadata:
  hermes:
    tags: [solana, mining, defi, attack, re-attest, score-manipulation]
---

# Solana Mining Protocol Attack Patterns

## Kairo Protocol Case Study

### Protocol Architecture
- **Type**: Proof-of-Activity Mining (SPL token)
- **Program ID**: 6MS8n87aRsXE5RjyVXuf9wcfARn5ut4m2YhBFE3kairo
- **Token**: $KAIRO (6 decimals, 21M cap)
- **Emission**: Front-loaded (300K day1 → 50K day10)
- **Hashrate decay**: Halves every 36h
- **Fees**: 0.1 SOL init, 0.02 SOL top-off

### Scoring Formula
```
raw = 0.25*age + 0.20*trades + 0.30*volume + 0.25*hold
hash_rate = round(100 + raw * 9900)
```

Weights: Volume 30% (highest), Age 25%, Hold 25%, Trades 20%

### Anti-Gaming Measures (and bypasses)
1. MIN_TRADE_USD = $10 → Just make $10+ trades
2. log1p scaling → Diminishing returns but still worth it
3. Bought-only hold time → Actually buy and hold
4. MAX_HR cap (10,000) → Can't bypass, but achievable
5. 0.1 SOL init fee → Tiny compared to rewards
6. Hashrate decay (36h) → Top-off every 36h (0.02 SOL)

## Attack Vector 1: Re-attest Abuse (HIGH)

### Root Cause
- re_attest costs 0 SOL (no fee)
- No cooldown between re-attestations
- No rate limiting on scorer API
- Scorer measures CURRENT activity only
- On-chain doesn't validate activity history
- Attestation expiry = 15 min (forces re-attestation)

### Attack Flow
1. **Build Activity** (30+ days)
   - Create wallet, wait for age
   - Make 50+ trades ≥$10 each
   - Accumulate $10K+ volume
   - Hold tokens for 30+ days
   - Score: ~7000-8000

2. **Initialize Miner** (0.1 SOL)
   - POST /score → get attestation
   - initialize_miner with attestation

3. **Coast & Top-off**
   - Mine at high hashrate
   - Top-off every 36h (0.02 SOL)

4. **Pulse Re-attestation** (FREE)
   - Temporarily resume activity (wash trade)
   - POST /score → get new attestation
   - re_attest on-chain (FREE)
   - Stop activity again
   - Repeat indefinitely

### Cost-Benefit (30 days, score=8000, 10% pool)
- KAIRO mined: ~160,939 (~$16,094)
- SOL cost: 0.40 SOL (~$60)
- Net profit: ~$16,034
- ROI: 26,723%

## Attack Vector 2: Early Entry Advantage

- Day 1 emission: 300,000 KAIRO
- Day 30 emission: ~34,000 KAIRO
- First month = 2x later months
- Front-loaded emission = early miners win

## Attack Vector 3: Score Optimization

Volume has highest weight (30%) but log1p scaling:
- $1K volume → score 5902 (59%)
- $1M volume → score 10000 (100%)
- Focus on volume, but diminishing returns

## Attack Vector 4: Hashrate Decay Bypass

- Hashrate halves every 36h
- After 7 days without top-off: 6.25% of original
- Top-off every 36h = maintain full hashrate
- Cost: 0.02 SOL per top-off

## Attack Vector 5: Oracle Key Compromise

If ORACLE_SECRET_KEY leaked:
- Sign fake attestations for any wallet
- Set max score (10,000) for attacker wallet
- Mine disproportionate rewards
- Drain emission pool

## Attack Vector 6: Admin Centralization

Admin can:
- Change oracle pubkey (sign fake scores)
- Change treasury (redirect fees)
- Change params (manipulate min/max score)
- Pause mining (freeze all)
- Transfer authority (full control)
- No timelock → instant rug possible

## Tools Needed
- Solana wallet (Phantom, Solflare)
- SOL for fees (0.1 SOL init + 0.02 SOL/top-off)
- Access to scorer API (POST /score)
- Helius API key for activity measurement

## Detection Indicators
- Wallet with high score but low recent activity
- Frequent re-attestations (every block)
- Top-off every 36h (maintenance pattern)
- Score/activity ratio anomaly

## Mitigation Recommendations
1. Add re_attest fee (e.g., 0.01 SOL)
2. Add cooldown (e.g., 24h between re-attests)
3. Rate limit scorer API (1 attestation/wallet/day)
4. Validate activity history on-chain
5. Decay score automatically (no re-attestation needed)
6. Timelock for admin actions
7. Multi-sig for oracle key management
