---
name: m0
description: "skills/m0.md — Skill Registry & Reflection Loop (v3)"
tags: [agent, m0]
---

# skills/m0.md — Skill Registry & Reflection Loop (v3)
# Called from AGENTS.md on every session start. Read this first, then route.

---

## REGISTRY

Scan table. Match intent. Load matched skill(s) on demand.
Do NOT preload skill files — token cost.

```
ID  | DOMAIN                              | KEYWORDS (high-weight)
----|-------------------------------------|------------------------------------------------
m1  | Monetization & value generation     | monetize, pricing, jual, jualan, cuan, funnel
m2  | Infrastructure & deployment         | VPS, deploy, SSH, nginx, docker, systemd
m3  | Content creation & distribution     | viral, hook, caption, thread, naskah, konten
m4  | Process orchestration & bots        | telegram bot, cron, webhook, n8n, automate, otomatis
m5  | Data transformation & insight       | spreadsheet, excel, csv, dataset, snapshot, laporan
m6  | Protocol binding & service bridge   | API, REST, webhook, midtrans, integrasi
m7  | Inference systems & AI builder      | LLM, prompt, claude API, openrouter, kimi, agent, add model, tambah model, registry model
m8  | File & artifact production          | PDF, DOCX, XLSX, PPTX, generate file, dokumen
m9  | Interface construction              | landing page, react, tailwind, frontend, UI
m10 | Web3 / crypto operations            | wallet, airdrop, on-chain, RPC, ethers, viem, mint
m11 | Security audit & review             | audit, vulnerability, exploit, scam check, malicious
m12 | Batch / parallel operations         | batch, parallel, bulk, mass, queue, worker, snapshot
m13 | Universal NFT minter (any contract) | mint, opensea, manifold, zora, seadrop, NFT, claim, drop
m14 | Daily assistant: briefing & alerts  | briefing, ringkasan harian, alert, kabarin kalau, pantau harga, alarm
m15 | Daily assistant II: watchdog/vault/multimodal/triage | watchdog, restart kalau mati, simpen alamat, macro, voice note, screenshot, triage
m16 | Software engineering & coding       | coding, bikin app, backend, API server, database, testing, scaffold, refactor, golang, rust, fastapi
m17 | Power pack: planner/swarm/automation/backtest/dashboard/voice | rencanain, workflow, otomatis kalau, backtest, dashboard, ngomong, swarm, tim agent

H1  | Swap & sell via aggregator          | swap, 1inch, jupiter, jual token, sell, DEX
H2  | Cross-chain bridge                  | bridge, LayerZero, stargate, LI.FI, across, hop
H3  | DeFi (lending/staking/perp)         | aave, lido, GMX, hyperliquid, pendle, defi
H4  | Token launch & NFT mint sniping     | snipe, honeypot, PairCreated, GoPlus, sniping
H5  | Whale & mempool tracking            | mempool, whale, nansen, arkham, smart money, tracker
H6  | NFT buy/sell (marketplace)          | beli NFT, blur, magic eden, tensor, reservoir, listing
H7  | Web3 sign-in & typed signing        | SIWE, walletconnect, EIP-712, ENS, permit, EIP-1271
H8  | Browser dApp automation             | buka dapp, browser, playwright, navigate, connect wallet, isi form
H9  | Universal contract read/write       | baca/tulis kontrak, read/write, call fungsi, ABI, inspect, proxy, eksekusi
H10 | Crypto dev: deploy/compile/test     | deploy kontrak, compile, forge, solidity, test, verify, CREATE2, bikin token

x1  | Internal capability refinement      | improve system, self-audit, upgrade brain
x2  | Deep decomposition & strategy       | strategy, architecture, decompose, plan, design system
x3  | Fault diagnosis & resolution        | error, bug, debug, gagal, rusak, stack trace
x4  | Self-improvement & autonomous fix   | self improve, belajar, makin pinter, auto fix, upgrade diri, learn
```

---

## ROUTING

```
0 matches:     answer from core knowledge — load nothing
1 match:       load full skill file
2+ matches:    pick PRIMARY (highest score), load it fully
               pull SUPPORTING (>50% of primary's score) section-by-section
ambiguous tie: ask once — "Fokus ke [A] atau [B] dulu?"
H-skill hit:   load skills/hermes/DISPATCH.md FIRST, then specific reference
```

### Hermes routing
H1-H7 are NOT standalone files. They map to `skills/hermes/references/*.md`:
```
H1 → hermes/references/swap.md
H2 → hermes/references/bridge.md
H3 → hermes/references/defi.md
H4 → hermes/references/sniping.md
H5 → hermes/references/monitoring.md (advanced sections 8-11)
H6 → hermes/references/nft.md
H7 → hermes/references/web3_connect.md
```
Load `hermes/DISPATCH.md` once per session if any H-skill fires (caches env var check + safety rails). Then load specific reference. Combine with m10/m12/m13 if task overlaps.

---

## REFLECTION LOOP

Runs silently after every output. Non-negotiable.

```
✅ Immediately executable / usable as-is?
✅ Anything the operator will need next that's missing?
✅ Generic advice — could be replaced with operator-specific code?
✅ Faster or cleaner path missed?
✅ Did I include the run command / deploy step?
✅ Token usage justified — could same value land in fewer lines?
```

Any fail → revise BEFORE outputting.
Upgrade exists → append: `🔧 Upgrade: [one line]`

---

## REFLECTION ESCAPE HATCH

If reflection loop catches issue but fix would 2x the response length → ship the working version, append:
> `🔧 Bisa di-upgrade ke [X]. Mau elaborasi?`
