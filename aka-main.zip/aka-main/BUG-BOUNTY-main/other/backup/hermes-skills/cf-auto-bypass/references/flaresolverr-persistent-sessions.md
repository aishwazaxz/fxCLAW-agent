# FlareSolverr Persistent Sessions for CSRF-Protected Sites

## Problem
FlareSolverr default mode creates a NEW session per request. CSRF-protected Laravel sites return "Page expired due to inactivity" because the token doesn't match the session.

## Solution: Persistent Sessions via /sessions.create

### Flow
1. `sessions.create` → get session_id
2. `request.get` with session → get page + CSRF token (cookies stored in session)
3. `request.post` with SAME session → CSRF token valid, POST works
4. `sessions.destroy` → cleanup

### API Calls
```bash
# Create session
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"sessions.create"}'
# Response: {"status":"ok","session":"ca0d75a0-5e5c-11f1-a75f-3668b0cb5e23"}

# GET with session
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"request.get","url":"https://TARGET","maxTimeout":60000,"session":"SESSION_ID"}'

# POST with same session
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"request.post","url":"https://TARGET/endpoint","maxTimeout":60000,"session":"SESSION_ID","postData":"_token=TOKEN&field=value"}'

# Destroy session
curl -s http://localhost:8191/v1 -X POST -H "Content-Type: application/json" \
  -d '{"cmd":"sessions.destroy","session":"SESSION_ID"}'
```

### Python Helper
```python
import requests, re

class FlareSolverr:
    def __init__(self, url="http://localhost:8191/v1"):
        self.url = url
        self.session = None
    
    def create_session(self):
        r = requests.post(self.url, json={"cmd": "sessions.create"}, timeout=30)
        self.session = r.json().get("session")
        return self.session
    
    def get(self, target_url):
        r = requests.post(self.url, json={
            "cmd": "request.get", "url": target_url,
            "maxTimeout": 60000, "session": self.session
        }, timeout=90)
        d = r.json()
        sol = d["solution"]
        html = sol["response"]
        csrf = re.search(r'name="csrf-token".*?content="([^"]+)"', html)
        return {
            "status": sol["status"],
            "html": html,
            "csrf": csrf.group(1) if csrf else None,
            "cookies": sol.get("cookies", [])
        }
    
    def post(self, target_url, post_data):
        r = requests.post(self.url, json={
            "cmd": "request.post", "url": target_url,
            "maxTimeout": 60000, "session": self.session,
            "postData": post_data
        }, timeout=90)
        d = r.json()
        sol = d["solution"]
        return {"status": sol["status"], "html": sol["response"]}
    
    def close(self):
        if self.session:
            requests.post(self.url, json={"cmd": "sessions.destroy", "session": self.session}, timeout=30)
            self.session = None

# Usage:
flare = FlareSolverr()
flare.create_session()
page = flare.get("https://TARGET")
csrf = page["csrf"]
result = flare.post("https://TARGET/login", f"_token={csrf}&user=admin&pass=test")
flare.close()
```

## Discovered: 2026-06-02 (joindijangkar55.online session)
- All POST requests without persistent session returned "Page expired"
- With persistent session: POST requests returned actual application responses
- Login error messages leaked: "Username yang dimasukkan tidak terdaftar" for invalid users
- checkExistingEmail returned raw "true"/"false" for email existence
