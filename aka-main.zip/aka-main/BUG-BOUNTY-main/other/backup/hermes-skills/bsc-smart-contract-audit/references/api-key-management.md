# BSCScan API Key Management

## Convention
ALL onchain tools read BSCScan API key from (priority order):
1. Environment variable: `BSCSCAN_API_KEY`
2. File: `~/.bscscan_key` (single line, no newline)

## Python Pattern
```python
import os
API_KEY = os.environ.get('BSCSCAN_API_KEY', 
    open(os.path.expanduser('~/.bscscan_key')).read().strip() 
    if os.path.exists(os.path.expanduser('~/.bscscan_key')) else '')
```

## Shell Pattern
```bash
BSCSCAN_KEY="${BSCSCAN_API_KEY:-$(cat ~/.bscscan_key 2>/dev/null)}"
```

## NEVER Do This
```python
# WRONG — hardcoded key will leak to git
API_KEY = "9XVGIPR29HVUUC4ZYBNFTX7KQKQBHUXQM3"

# WRONG — hardcoded path breaks on other machines
API_KEY = open('/workspaces/BUG-BOUNTY/.bscscan_key').read().strip()
```

## Pre-Push Check
```bash
grep -rn '9XVGIP\|BSCSCAN_API_KEY.*=\s*"' --include='*.py' --include='*.sh' tools/
# Should return NOTHING
```

## If Key Gets Leaked
1. `git filter-repo --replace-text <(echo 'LEAKED_KEY=*** 2. `git push --force origin main`
3. Regenerate key on BSCScan immediately
