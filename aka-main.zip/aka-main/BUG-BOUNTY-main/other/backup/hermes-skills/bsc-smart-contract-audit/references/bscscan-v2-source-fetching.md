# BSCScan V2 Source Fetching + Proxy Detection Notes
# Session: 2026-05-31, BTCST/SteakBank/Sable/Horizon/Mars investigation

## BSCScan V2 API (chainid=56)

**Endpoint**: `https://api.etherscan.io/v2/api?chainid=56&module=contract&action=getsourcecode&address=ADDR&apikey=KEY`

NOT `api.bscscan.com` — that's V1 and deprecated.

**Key modules for contract intel**:
- `getsourcecode` — source code + compiler info
- `getabi` — ABI only
- `proxy` + `eth_call` / `eth_getStorageAt` — read contract state (need Infura/Alchemy BSC RPC)

## Source Code Format: Multi-File JSON

BSCScan returns multi-file sources as a JSON object wrapped in double braces:
```
{{
  "language": "Solidity",
  "sources": {
    "contracts/SABLE/SABLEToken.sol": { "content": "// SPDX...\npragma..." },
    "contracts/Dependencies/SafeMath.sol": { "content": "..." }
  },
  "settings": { "optimizer": {...} }
}}
```

**To parse**: Strip first and last char → `json.loads(raw[1:-1])`

Single-file sources return regular Solidity text starting with `// File: contracts/...`

## Proxy Detection (ERC-1967)

**Slots to read** (via `eth_getStorageAt` on proxy address):
- EIP-1967 impl: `0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc`
- EIP-1967 admin: `0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103`
- Beacon: `0xa3f0ad74e5423aebfd80d3ef2346578355a9a72a`

**Critical interpretation**:
- `result = 0x0000...0000` (all zeros, 64 hex chars) → NOT a proxy. The address IS the implementation itself. Use it directly for source fetching.
- `result = 0x0...0` with non-zero code size → check if EIP-1967 slots are genuinely empty (uninitialized proxy) vs. not-a-proxy.
- `result = 0x[40hex chars]` → found proxy. Extract address from last 20 bytes: `0x` + result[-40:]

**Code size check** (via `eth_getCode`): Proxy code is typically ~45-100 bytes (delegatecall dispatch). Full contract code = not a proxy.

## Finding: BTCST (0x78650b139471520656b9e7aa7a5e9276814a38e9)

- **TVL**: ~$950K (CoinGecko: BTC 3,268 / USD $97M — DeFiLlama shows $950K, discrepancy = DeFiLlama vs CoinGecko measurement)
- **Category**: Yield / Hashrate token ($BTCST = 0.1 TH/s Bitcoin mining power)
- **Proxy**: Upgradeable Transparent Proxy
  - Admin (EIP-1967 admin slot): `0xaa4c10aa3de2e4da6b0c0c9d177f1fa77314c9d8` — **EOA, not multisig** ← finding
  - Implementation: `0x85d4f83b0bf400d3af6fa12c44a28b490689c091`
- **Compiler**: Solc 0.6.9 (old, timestamp `now` manipulation risk)
- **Source**: 24 files, StandardHashrateToken → LinearReleaseToken → PeggyToken inheritance chain
- **Security concern**: Single EOA admin = if key compromised, attacker upgrades to malicious impl and drains all. Need to check if timelock exists on upgrade.
- **Note**: BTCST token contract ≠ TVL holder. Actual TVL is in farm/staking contracts (separate addresses). BTCST contract has `changeFarmContract(IFarm)` — onlyOwner.

## Finding: SteakBank Finance (0xbb53fcab7a3616c5be33b9c0af612f0462b01734)

- **TVL**: $305K (DeFiLlama)
- **Category**: Liquid Staking
- **NOT a proxy** — EIP-1967 slots all zero → direct implementation
- **Compiler**: Solc 0.6.12
- **Contract**: SBF (Steak Bank Finance) — standard BEP-20 with EIP-712 delegation
- **Source**: 6 files (OZ Context, Ownable, SafeMath, IBEP20, SBF)
- **Note**: This is the TOKEN contract. Staking logic (actual TVL) is in a different contract. Need to find staking pool / vault address.

## DeFiLlama TVL Filter Notes

- Chain name: `"Binance"` NOT `"BSC"`
- Filter: `if p.get('chain') != 'Binance': continue`
- `tvl` field is a `list` of `{'date': unix_ts, 'totalLiquidityUSD': float}` — get latest with `tvl[-1]['totalLiquidityUSD']`
- `address` field: `"bsc:0x..."` — split on `:` and take last part
- `audits` field from DeFiLlama is **unreliable** — do not filter by it. Many protocols with "2 audits" per DeFiLlama may not have real security audits.
- TVL < $1M + category in (CDP, Lending, Yield, Derivatives) = good candidates
- BTCST shows $950K TVL but CoinGecko shows $97M market cap — difference is token price vs TVL in staking. Need to verify actual protocol TVL from on-chain (not DeFiLlama TVL number alone).

## Workflow: Getting from Protocol Name to Exploitable Contract

1. Get protocol address from DeFiLlama `address` field (format: `"bsc:0x..."`)
2. Check proxy pattern with ERC-1967 slots via Infura RPC
3. If proxy → get implementation → fetch source of implementation
4. If not proxy → fetch source directly
5. **CRITICAL**: The returned contract is often just the TOKEN. For real TVL, need to find staking vault / pool / CDP engine contracts.
   - Check `getsourcecode` for `changeFarmContract`, `setPool`, `setVault` type functions
   - Or search BSCScan for contracts created by proxy admin / deployer
   - Or use DeFiLlama protocol detail endpoint `https://api.llama.fi/protocol/{slug}` for module path