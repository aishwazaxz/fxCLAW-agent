# Proxy Analysis Notes - Batch 2026-05-31

## Known Proxy Patterns on BSC

### LISTA Protocol
- All LISTA pools use UUPS proxies with `init_version = MAX_UINT (18446744073709551615)`
- This means properly initialized, re-initialization permanently blocked
- Implementation contracts share impl `0x212b836dc1ee8c8daefd1284bd27e96a2ea3a126` (StableSwapPool variants)
- SmartProvider_solvBTC uses different impl: `0x3356bf120a6b959b92ec208c04cded08957f6c38`
- StableSwapPoolInfo uses impl: `0x3957208ba04b83796e1d9394baf2a6796467fd70`

### PARALLEL Protocol
- USDp (`0x048C4e...`) is UUPS proxy pointing to TokenP (`0x411dc6...`)
- TokenP and FlashParallelToken are regular contracts (not proxies), init_version=1
- All first 20 storage slots zero (clean)

### SYMMIO Protocol (BSC) — ACTIVE TARGET

**Diamond proxy:** `0x9A9F48888600FC9c05f11E03Eab575EBB2Fc2c8f` on BSC
- Chain TVL: ~$255K (DeFiLlama, 2026-05-31)
- Type: EIP-2535 Diamond (facets pattern, NOT UUPS/Transparent)
- Bytecode: 185 bytes (minimal proxy, delegates to facets)
- Collateral: USDT (`0x55d398326f99059ff775485246999027b3197955`)

**Diamond introspection (forge test results, 2026-05-31):**
- `facets()` → succeeds, returns `[(facetAddr, selectors[])]` array — **14 facets total**
- `facetAddresses()` → succeeds, returns 14 facet addresses
- `owner()` → **reverts** (owner check lives in individual facets, not at Diamond level)
- ERC-1967 impl/admin slots → empty (normal for Diamond, uses EIP-2535 storage layout)

**Facet addresses:**
```
0xf91382e6d8359aeca46a81f105994a4171739c7c
0x9ceb86567606837840505e0a5ed424c75e02d6af
0xdddf591416b18fa71cc6d6608348cbe36bcbf543
0x7195d6cf49af88a1b35eda28207e9147ecb2323d
0x56116be33532982d73e7ff8ffe1a5a7f4a74694e
0x993bc0ab29f22a34e63138f129177767dc59ff5f
0x9f6a2137af842bab85c7a3931a16ab6f5895445c
0x4f77a2cd0635179474874e151a0b02150020a8e2
0x0131fdf62e1de497b536876d5fb5298d91b6cc28
0xcf8226034f188a0b9b7b9442c5f04e08178c84e5
0x064e4d384f1b6151dfb1a5e5063174f21b33b2855
0xaf0d00b18097596758ec39aeb8b5d52a7a7e876f
0x0b7884a7caa481e5a87d45251e57e38614a577980
0x69fce0b9fa1b7ac9f68000c0cdfb5c7c266a194c
```

**Attack surface analysis approach:**
1. Fork BSC at current block
2. For each of 14 facets: extract ABI via `eth_getCode` + selector fingerprinting (PUSH4 opcode extraction)
3. Test each facet's state-changing functions from attacker vs owner context
4. Focus on: BridgeFacet (bridging logic), LiquidationFacet (liquidation engine), allocate/liquidity functions
5. `init_version=0` on facets is EXPECTED — EIP-2535 facets are never initialized directly, only the Diamond proxy is

**Discovery via DeFiLlama adapter config** (reliable for all multi-chain protocols):
```bash
curl -s "https://raw.githubusercontent.com/DefiLlama/DefiLlama-Adapters/main/projects/symm-io/index.js"
# Returns: { bsc: "0x9A9F48888600FC9c05f11E03Eab575EBB2Fc2c8f", ... }
# Contains: `abi: 'address:getCollateral'` → returns collateral token address
```

**Key insight:** For Diamond proxies, `owner()` often reverts at the proxy level — the owner check is in individual facets. Must enumerate facets via `facetAddresses()` and analyze each separately. `init_version=0` on facets is NOT a vulnerability.

**EIP-2535 Loupe Limitation:** `selectorToFacet(bytes4)` is NOT part of the official EIP-2535 standard — it is an optional extension. Many diamonds implement `facets()` and `facetAddresses()` but NOT `selectorToFacet`. When missing, parse the raw hex return of `facetAddresses()` to extract addresses manually (see below).

**Solidity Address Checksum Rule:** When defining address arrays as Solidity constants, ALL addresses MUST have valid EIP-55 checksums or compilation FAILS. Even casting through `uint256` does not bypass — Solidity validates the hex literal before the cast. Workaround: retrieve addresses at runtime via `facetAddresses()` call inside `setUp()`.

**SYMMIO Protocol (inactive):** Previous audit target `0x76bc5889c0cfcC20960b0D81F541595d81a95122` = EOA (no bytecode, dead address)

### SYMMIO BSC Diamond Deep Dive (2026-05-31)

**Target:** `0x9A9F48888600FC9c05f11E03Eab575EBB2Fc2c8f` on BSC  
**TVL:** ~$255K (BSC chain) | **Type:** EIP-2535 Diamond | **Collateral:** USDT

**EIP-2535 Loupe Function Availability:**

| Function | Works? | Notes |
|----------|--------|-------|
| `facets()` | ✅ | Returns `[(facetAddr, selectors[])]` array |
| `facetAddresses()` | ✅ | Returns flat array of 14 facet addresses |
| `selectorToFacet(bytes4)` | ❌ NO | "Diamond: Function does not exist" |

**When `selectorToFacet` is missing** — parse raw hex from `facetAddresses()`:
```python
# Raw hex: 14 addresses × 32 bytes each = 448 chars + 64 char array header
facet_hex = "000000000000000000000000f91382e6d8359aeca46a81f105994a4171739c7c..."
for i in range(14):
    addr = "0x" + facet_hex[i*64+24 : i*64+64]  # skip 12-byte padding per slot
    print(f"facet[{i}] = {addr}")
```

**Known selectors from facets() data** (30 selectors across 14 facets — all revert from attacker):
```
0x2e1a7d4d, 0x13be252b, 0x8da5cb5b, 0xf851a440, 0x5c60da1b,
0x094e2f12, 0x7eff253a, 0x3e5ea8b2, 0x4b5a1e3c, 0x67b9f368,
0x4ce21412, 0xbaa762c0, 0xefac4774, 0xec68a51c, 0x12d19bca,
0x39d6c1a1, 0x6c2eb489, 0xac4c3c5b, 0x9d63fd4a, 0x47316929,
0x9e8aad6c, 0x40c9d60b, 0x1df9addc, 0x2b04e8fa, 0x6bb3e945,
0xc4071a89, 0x2e7e2779, 0x9d1a9320, 0xb2c3e09c, 0x8d6d25e0
```
Result: 0/30 selectors work from attacker context — access control functioning.

**Confidence without source:** LIMITED. Cannot claim HIGH. Need source code for real exploit path identification in derivatives clearing protocol.

### MACH Protocol
- OrderBook (`0xB6A80Ef...`) is NOT a proxy
- Slot 0 = `0x451f52446ebd4376d4a05f4267ef1a03acf1aaf4` (owner address)
- Slot 4 = `0x000000000000000000000000000003e900007596` (config data)
- init_version=0 but "Contract may not be a proxy" recommendation = correct
- OrderBookV2 (`0xC60461...`) is the newer version, also not a proxy

## Verified Cast Storage Output (2026-05-31)

```bash
# LISTA StableSwapPool_slisBNB
cast storage 0x3DcEA6AFBA8af84b25F1f8947058AF1ac4c06131 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc
# → 0x000000000000000000000000212b836dc1ee8c8daefd1284bd27e96a2ea3a126

cast storage 0x3DcEA6AFBA8af84b25F1f8947058AF1ac4c06131 0xf0c57e16840df040f15088dc2f81fe391c3923bec73e23a9662efc9c229c6a00
# → 0x0000000000000000000000000000000000000000000000000000000000000001 (proxy init=1)

cast storage 0x212b836dc1ee8c8daefd1284bd27e96a2ea3a126 0xf0c57e16840df040f15088dc2f81fe391c3923bec73e23a9662efc9c229c6a00
# → 0x000000000000000000000000000000000000000000000000ffffffffffffffff (impl init=MAX_UINT)
```

## proxy_checker.py Interpretation Guide

| Field | Meaning |
|-------|---------|
| `impl = null` + `proxy_type = uups` | Likely NOT a proxy, false positive |
| `impl = 0x...` + `init_version = MAX_UINT` | Proper UUPS proxy, fully initialized |
| `impl = 0x...` + `init_version = 1` | Proxy initialized once (normal) |
| `init_version = 0` on facet | Diamond facet, NOT a vulnerability |
| `init_version = 0` on standalone | CHECK: might be uninitialized proxy |

## Pipeline BLOCKED Pattern

When ALL targets return `Verdict: BLOCKED / Reason: Compilation failed`:
- The bottleneck is BSCScan source fetching, not the contracts
- BSCScan flattened source has broken relative imports
- Fix options:
  1. Reconstruct dir structure from multi-file JSON
  2. `forge install OpenZeppelin/openzeppelin-contracts` into target lib/
  3. Skip compilation, do manual bytecode analysis via proxy_checker + analyze_contracts