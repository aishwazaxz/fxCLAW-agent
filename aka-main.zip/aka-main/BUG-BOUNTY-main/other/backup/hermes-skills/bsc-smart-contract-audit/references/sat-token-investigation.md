# SAT Token Investigation — On-Chain Patterns (2026-05-31)

## Target: `0x14Dc4b4929c664534f1d4D64107d8F36CbF906a0`

## Critical Finding: Transfer Locked

**VERIFIED ON-CHAIN**: `transfer()` and `transferFrom()` always revert for ALL users.

Evidence:
- No successful transfer transactions in 500+ blocks checked
- Transfer to self, zero amount, any address → all REVERTED
- Even the minter with 1 SAT cannot transfer

## Investigation Workflow Used

### 1. Transfer Function Verification
```python
# Standard transfer call
data = "0xa9059cbb" + to_addr + amount
w3.eth.call({"to": token, "data": data})

# Try variants
# - transfer to self
# - transfer 0 amount
# - transfer to address(0)
# All should revert if transfer is blocked
```

### 2. Block-by-Block TX Search
```python
# Search for ANY successful transfer TX in recent blocks
# This is the DEFINITIVE proof - if no successful TX exists,
# transfer is confirmed blocked
for block in range(latest-500, latest):
    block_data = w3.eth.get_block(block, full_transactions=True)
    for tx in block_data.transactions:
        if tx.to == token and tx.input[:4].hex() == "a9059cbb":
            receipt = w3.eth.get_transaction_receipt(tx.hash)
            if receipt['status'] == 1:
                print("SUCCESSFUL TRANSFER FOUND!")
```

### 3. Storage Analysis
```python
# Check slot 11 for vault/reward pool
slot11 = w3.eth.get_storage_at(token, 11)
# Slot 11: 0x0000000000000000000000000000000000000000000000000003baf82d03a000
# = 1050000000000000 raw = 10,500,000 SAT (50% of supply)

# Find admin via selector scanning
# Selector 0x4ef37628 returns admin address
admin = w3.eth.call({"to": token, "data": "0x4ef37628" + "0"*64"})
# Admin: 0x4f923bf4dbd27ab60a733ca9ae7cb70c28d8d1
```

### 4. Challenge Discovery via Events
```python
# Get challenge from latest RewardPaid event
# Event sig: 0xcf6fbb9dcea7d07263ab4f5c3a92f53af33dffc421d9d121e1c74b307e68189d
logs = w3.eth.get_logs({
    "address": token,
    "fromBlock": start,
    "toBlock": latest,
    "topics": [reward_event_sig]
})
challenge = logs[-1]['topics'][1]  # indexed param = challenge bytes32
```

### 5. web3.py Checksum Issue
```python
# This FAILS:
w3.eth.get_code("0x82035F4C3b0958a0dEb3237017d8959E5b9163")
# Error: ENS name invalid (checksum mismatch)

# FIX:
addr = w3.to_checksum_address("0x82035f4c3b0958a0deb3237017d8959e5b9163")
w3.eth.get_code(addr)  # Works
```

### 6. LP Pair Discovery
```python
# PancakeSwap Factory: 0xca143ce32fe78f1f7019d7d551a6402fc5350c73
factory = w3.to_checksum_address("0xca143ce32fe78f1f7019d7d551a6402fc5350c73")
wbnb = w3.to_checksum_address("0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c")

# getPair(tokenA, tokenB)
getpair_data = "0xe6e1d3c5" + wbnb[2:] + token[2:]
pair = w3.eth.call({"to": factory, "data": getpair_data})
# If pair == 0x0...0 → no LP exists
```

## SAT Token Storage Layout

| Slot | Value | Interpretation |
|------|-------|----------------|
| 0 | 0x0 | Unused |
| 1 | 0x0 | _balances mapping (base) |
| 2 | 2100000000000000 | _totalSupply = 21M SAT |
| 3 | "Satoshi" | _name |
| 4 | "SAT" | _symbol |
| 5 | 8 | _decimals |
| 6 | 0x60c45e7 | Block number related |
| 7 | 0x8c24 | 35876 - difficulty |
| 8 | 0x13176cf0... | Challenge seed |
| 9 | 0x6b96a651... | Admin nonce or salt |
| 11 | 1050000000000000 | Vault pool: 10.5M SAT |

## Important: When User Claims "Can Sell"

User said "other people can sell, why can't I?"

**CORRECT RESPONSE**: Verify thoroughly, don't just assert "can't":
1. Search for ANY successful transfer TX (definitive proof)
2. Check for LP pair on DEX
3. Check for wrapper contract
4. Check if trading is via P2P/OTC
5. Only after ALL checks fail → conclude "transfer blocked"

## Key Files

- Bug report: `/workspaces/BUG-BOUNTY/work/SAT_MINER_BUG_REPORT.txt`
- Config: `/workspaces/BUG-BOUNTY/work/satminer_repo/config.yaml`
- Miner repo: `/workspaces/BUG-BOUNTY/work/satminer_repo/`

## SAT Miner Findings Summary

| Finding | Severity | Status |
|---------|----------|--------|
| SAT transfer always reverts | CRITICAL | On-chain confirmed |
| Keccak constants 24/24 wrong | MEDIUM | Code analysis |
| Private key base64 exfil | HIGH | Code analysis |
| Auto-pip RCE | HIGH | Code analysis |
| Config poisoning | MEDIUM | Code analysis |
| Admin key exposed | INFO | On-chain confirmed |

## Conclusion

**SAT token is a mining scam** or pre-launch lock:
- Mining works (PoW valid)
- Difficulty is LOW (2^47)
- But transfer is BLOCKED for everyone
- No DEX listing (no LP pair)
- 10.5M SAT (50%) in locked vault
- Admin key known but not exploitable

**No realistic exploit path** for extracting value.