# SAT Miner Audit — Attack Surface Methodology

## Target Type: Client-Side Mining Software (Python)

Unlike smart contracts, client-side software has different attack vectors:
- Supply chain (malicious packages)
- Config file exposure (plaintext keys)
- RPC/WS manipulation (fake data injection)
- Memory exposure (process dump)

## Attack Priority Matrix

```
ATTACK                      | DIFFICULTY | IMPACT    | PRIORITY
---------------------------|------------|-----------|----------
Supply chain (auto-pip)     | Medium     | Total loss| P0
Config file key theft       | Easy       | Total loss| P0
Keccak mismatch (C ext)     | Easy       | Gas waste | P0
RPC fake challenge          | Medium     | Gas waste | P1
RPC fake target             | Medium     | Resource  | P1
BNB drain via gas           | Medium     | BNB waste | P1
Timing attack               | Medium     | Compete   | P1
Memory dump key             | Easy       | Total loss| P1
WS event injection          | Hard       | Compete   | P2
Nonce griefing              | Hard       | Compete   | P2
```

## Real Target Discovery

When testing client-side software exploits:
1. Search GitHub for forks with committed configs
2. Search on-chain for active users/miners
3. Check public pastes, Discord, Telegram
4. If no real targets → be honest, don't fabricate

## Key Findings (SAT Miner)

1. Auto-pip install → RCE (CRITICAL)
2. Config file plaintext key → exfil (HIGH)
3. No chain_id validation → wrong chain (HIGH)
4. Keccak C ext wrong constants → invalid hash (MEDIUM)
5. WS spoofing → challenge injection (MEDIUM)

## Files

- Full report: `/workspaces/BUG-BOUNTY/work/satminer_audit_report.md`
- Attack surface: `/workspaces/BUG-BOUNTY/work/satminer_attack_surface.md`
- Attack PoC: `/workspaces/BUG-BOUNTY/work/satminer_attack_poc.py`
