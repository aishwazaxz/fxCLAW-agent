# SYMMIO BSC Diamond Investigation Case Study (2026-05-31)

## Protocol Overview

- **Name:** SYMMIO (hybrid derivatives clearing protocol)
- **Website:** symm.io
- **Chain:** BSC
- **Vault Address:** `0x9A9F48888600FC9c05f11E03Eab575EBB2Fc2c8f`
- **TVL (BSC):** ~$255K (DeFiLlama, 2026-05-31)
- **Category:** Derivatives (intent-based bilateral leveraged trading)
- **Source:** NOT verified on BSCScan. Confidence = LIMITED.

## Contract Type

**EIP-2535 Diamond Proxy** — 14 facets, 185 bytes bytecode.

```
Diamond (proxy) → delegates to → [facet₀, facet₁, ..., facet₁₃]
```

## Investigation Steps (Reproducible)

### Step 1: Find Address via DeFiLlama Adapter

```bash
curl -s "https://raw.githubusercontent.com/DefiLlama/DefiLlama-Adapters/main/projects/symm-io/index.js"
# Returns: { bsc: "0x9A9F48888600FC9c05f11E03Eab575EBB2Fc2c8f", ... }
```

### Step 2: Quick On-Chain Recon (forge test)

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
import "forge-std/Test.sol";

contract SymmioTest is Test {
    address constant VAULT = 0x9A9F48888600FC9c05f11E03Eab575EBB2Fc2c8f;
    string constant BSC_RPC = "https://bsc-mainnet.infura.io/v3/<KEY>";
    
    function setUp() public { vm.createSelectFork(BSC_RPC); }
    
    function test_vault_info() public {
        uint256 codeSize;
        assembly { codeSize := extcodesize(VAULT) }
        emit log_named_uint("Bytecode size", codeSize);
        // Expected: ~185 bytes (minimal proxy)
    }
    
    function test_get_collateral() public {
        (bool ok, bytes memory data) = VAULT.staticcall(
            abi.encodeWithSignature("getCollateral()")
        );
        emit log_named_uint("getCollateral success", ok ? 1 : 0);
        // Expected: ok=1, data = USDT address 0x55d398326f99059ff775485246999027b3197955
    }
    
    function test_diamond_check() public {
        // EIP-2535 loupe functions
        (bool facetsOk, ) = VAULT.staticcall(abi.encodeWithSignature("facets()"));
        emit log_named_uint("facets() success", facetsOk ? 1 : 0);
        
        (bool addrOk, bytes memory addrData) = VAULT.staticcall(
            abi.encodeWithSignature("facetAddresses()")
        );
        emit log_named_uint("facetAddresses() success", addrOk ? 1 : 0);
        // addrData = raw hex: [offset, len, addr₀, addr₁, ..., addr₁₃]
        
        (bool selOk, ) = VAULT.staticcall(
            abi.encodeWithSignature("selectorToFacet(bytes4)", bytes4(0x2e1a7d4d))
        );
        emit log_named_uint("selectorToFacet() success", selOk ? 1 : 0);
        // Expected: 0 (function does not exist in SYMMIO diamond)
    }
    
    function test_storage_scan() public view {
        for (uint i = 0; i < 20; i++) {
            bytes32 val = vm.load(VAULT, bytes32(uint256(i)));
            if (uint256(val) != 0) {
                emit log_named_bytes32(string(abi.encodePacked("slot ", i)), val);
            }
        }
        // Expected: slots 0-8 non-zero (Diamond storage), impl/admin slots zero
    }
}
```

### Step 3: Parse facetAddresses() Raw Return

```python
# From the raw hex returned by facetAddresses():
# Array layout: [offset(32), length(32), addr₀(32), addr₁(32), ...]
facet_hex = (
    "0000000000000000000000000000000000000000000000000000000000000020"  # offset
    "000000000000000000000000000000000000000000000000000000000000000e"  # 14 elements
    "000000000000000000000000f91382e6d8359aeca46a81f105994a4171739c7c"   # facet[0]
    "0000000000000000000000009ceb86567606837840505e0a5ed424c75e02d6af"   # facet[1]
    # ... 12 more
)

for i in range(14):
    addr = "0x" + facet_hex[64 + i*64 + 24 : 64 + i*64 + 64]  # skip array header + padding
    print(f"facet[{i}] = {addr}")
```

### Step 4: Selector Scan via Diamond

```solidity
function test_selector_scan() public {
    bytes4[30] memory sels = [
        bytes4(0x2e1a7d4d), bytes4(0x13be252b), bytes4(0x8da5cb5b),
        // ... all 30 from facets() data
    ];
    
    for (uint i = 0; i < sels.length; i++) {
        (bool ok, ) = VAULT.call(abi.encodeWithSelector(sels[i]));
        // All expected to revert — access control is functioning
    }
}
```

**Result:** 0/30 selectors work from attacker → access control is properly implemented.

## Key Findings

| Finding | Severity | Notes |
|---------|----------|-------|
| `selectorToFacet(bytes4)` not implemented | Info | Optional EIP-2535 extension, not always present |
| `owner()` reverts at Diamond level | Info | Owner check lives in individual facets |
| All 30 selectors revert from attacker | Info | Access control is functioning |
| Source not verified | Limitation | Cannot claim HIGH confidence |

## Methodology Summary

```
1. DeFiLlama adapter → find vault address
2. cast call getCollateral() → verify on-chain
3. fork test → check bytecode size (~185 = proxy)
4. fork test → call facets() + facetAddresses()
5. fork test → try selectorToFacet() (may not exist)
6. parse facets() raw data → get selector→facet mapping
7. selector scan via diamond proxy (attacker prank)
8. if no exploitable selectors → LIMITED confidence
```

## SYMMIO Architecture (Known from Public Info)

Symmio is a bilateral perpetual agreement protocol. Key entities:
- **Party A / Party B** — traders with opposing positions
- **Solver** — matches bilateral agreements
- **Liquidator** — processes liquidations when margin is breached
- **Collateral** — USDT (single asset)

Without source code, cannot determine:
- Liquidator access control (who can liquidate?)
- Solvency check logic (when does liquidation trigger?)
- Fee distribution mechanism
- Force action path (can solver/liq grief users?)

**Confidence without source:** LIMITED (cannot claim HIGH severity findings).