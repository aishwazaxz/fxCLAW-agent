# Ethereal Protocol — On-Chain Analysis

**Date:** 2026-06-01
**Type:** Perpetual Futures DEX (EVM Appchain)
**Status:** Testnet active, mainnet rolling out

## Architecture

- **Execution**: EVM appchain with custom sequencer
- **Settlement**: Arbitrum One
- **Data Availability**: Celestia
- **Gas Token**: USDe (18 decimals)
- **Sequencer Address**: `0xA4b000000000000000000073657175656e636572` (ASCII: "sequencer")

## Chain Config

| | Mainnet | Testnet |
|-|---------|---------|
| Chain ID | 5064014 | 13374202 |
| RPC | https://rpc.ethereal.trade/ | https://rpc.etherealtest.net |
| WS | wss://ws.ethereal.trade | wss://rpc.etherealtest.net |
| Explorer | https://explorer.ethereal.trade/ | https://explorer.etherealtest.net |
| Contract | 0xB3cDC82035C495c484C9fF11eD5f3Ff6d342e3cc | 0x1F0327A80e43FEF1Cd872DC5d38dCe4A165c0643 |

## Contract Analysis (Testnet)

- **Proxy**: `0x1F0327A80e43FEF1Cd872DC5d38dCe4A165c0643` (EIP-1967)
- **Implementation**: `0x83e1bc3cb19be0208548c6151212203206fff7f3` (16,137 bytes)
- **Admin slot**: `0x0...0` (no admin set — decentralized or not yet configured)

### Key Functions (from implementation bytecode)

```
getPerpProduct(uint32)          — Get perpetual product info
getToken(bytes32)               — Get token info
removeToken(bytes32)            — Remove token
isClaimer(address)              — Check claimer role
addClaimer(address)             — Add claimer
getFeeCollector()               — Get fee collector
isEmergencyPaused()             — Check emergency pause
requestOwnershipHandover()      — Ownership transfer
startBlock(uint256,uint64,uint64,uint64) — Block production (system call)
```

### System Contracts

- `0x00000000000000000000000000000000000A4B05` — System precompile (`0xfe` = INVALID opcode)
  - Function: `startBlock(uint256,uint64,uint64,uint64)`
  - Called every block by sequencer

## EIP-712 Signature Types

```solidity
TradeOrder(address sender, bytes32 subaccount, uint128 quantity, uint128 price,
           bool reduceOnly, uint8 side, uint8 engineType, uint32 productId,
           uint64 nonce, uint64 signedAt)

CancelOrder(address sender, bytes32 subaccount, uint64 nonce)

InitiateWithdraw(address account, bytes32 subaccount, address token, uint256 amount,
                 uint64 nonce, uint64 signedAt, bytes32 destinationAddress,
                 uint32 destinationEndpointId)

LinkSigner(address sender, address signer, bytes32 subaccount, uint64 nonce, uint64 signedAt)

RevokeLinkedSigner(address sender, address signer, bytes32 subaccount, uint64 nonce, uint64 signedAt)

RefreshLinkedSigner(address sender, address signer, uint64 nonce, uint64 signedAt)

ExtendLinkedSigner(address sender, uint64 nonce, uint64 signedAt)

EIP712Auth(address sender, uint8 intent, uint64 signedAt)
```

## Attack Surface Analysis

1. **Signature Replay**: Nonce management across subaccounts — race condition between LinkSigner and TradeOrder?
2. **Signer Management**: LinkSigner/RevokeLinkedSigner/RefreshLinkedSigner — can a revoked signer still execute?
3. **Cross-Chain Withdrawal**: `InitiateWithdraw` has `destinationEndpointId` — cross-chain routing vulnerability?
4. **Emergency Pause**: Who can call `isEmergencyPaused()`? Can it be griefed to freeze all trading?
5. **Sequencer Trust**: Centralized sequencer = single point of failure for order matching
6. **Fee Manipulation**: `getFeeCollector()` — who sets fees? Can fee collector be changed?
7. **Subaccount Isolation**: Are subaccounts isolated? Can one subaccount affect another?
8. **Token Removal**: `removeToken(bytes32)` — what happens to open positions when token is removed?

## SDK References

- **Rust SDK**: https://github.com/8ball030/ethereal_rust_sdk (public, 268 commits, active)
- **Go SDK**: https://github.com/qiwi1272/ethereal-go
- **Python SDK**: Official (in docs)

## Notes

- GitHub org `etherealdex` has NO public repos — private codebase
- Community SDKs reveal contract ABIs and EIP-712 types
- 33 followers on GitHub
- USDe used as BOTH margin AND gas token
- "Reward-bearing margin" — earn APR by holding USDe
- Docs: https://docs.ethereal.trade/
- Discord: https://discord.com/invite/etherealdex
