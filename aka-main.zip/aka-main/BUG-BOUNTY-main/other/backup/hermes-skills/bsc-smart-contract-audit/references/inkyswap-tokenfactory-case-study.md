# InkySwap TokenFactory Investigation (2026-05-31)

## Target

- **Protocol**: InkySwap (Ink chain)
- **Contract**: TokenFactory (proxy)
- **Proxy**: 0x1D74317d760f2c72A94386f50E8D10f2C902b899
- **Implementation**: 0x3c235b5017064516218f0bf4179bae8d8b80392b
- **Chain**: Ink (chain ID 57073)
- **RPC**: QuickNode managed - `https://crimson-solitary-isle.ink-mainnet.quiknode.pro/c58c6f3d31844addbec45521ea20c278a7fe6670/`
- **TVL**: ~$507K (per DeFiLlama)
- **Type**: Token factory with bonding curve + graduation to Uniswap

## Investigation Steps

### 1. Precheck via RPC

```python
# Check bytecode size to distinguish proxy vs implementation
cast code 0x1D74317d760f2c72A94386f50E8D10f2C902b899 --rpc-url <INK_RPC>
# Result: 170 bytes → PROXY

cast code 0x3c235b5017064516218f0bf4179bae8d8b80392b --rpc-url <INK_RPC>
# Result: 16445 bytes → IMPLEMENTATION
```

### 2. Read EIP-1967 Implementation Slot

```python
# Via eth_getStorageAt
slot = "0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc"
result = eth_getStorageAt(proxy, slot, "latest")
# Result: 0x0000000000000000000000003c235b5017064516218f0bf4179bae8d8b80392b
```

### 3. Explorer API Check

- Source NOT verified on explorer.inkonchain.com for implementation
- Proxy IS verified (TransparentUpgradeableProxy)
- Sourcify: 404 (not indexed)

### 4. Function Selector Fingerprinting

Called 43 function selectors via `eth_call` to determine contract type:

**Working (9/43):**
| Selector | Result | Interpretation |
|----------|--------|----------------|
| 0x8da5cb5b (owner) | 0x1137d318222e93078ee9452aaec13744d5b025f3 | Contract has owner |
| 0x146101f8 (pairFor) | Large uint | DEX factory function |
| 0x296c53ce (create) | Large uint | Token creation |
| 0x2f3a3d5d (pairFor) | Large uint | Pair address calculation |
| 0x4282af14 (allPairs) | REVERT | — |
| 0x4f1ef286 (allPairsLength) | REVERT | — |
| 0x59d0f713 (createPair) | Large uint | Creates trading pair |
| 0xeff1d50e (unpause) | Large uint | Returns large value |

**Revert (standard ERC20 selectors - confirms NOT ERC20):**
- name() = 0x06fdde03
- symbol() = 0x95d89b41
- totalSupply() = 0x18160ddd
- balanceOf() = 0x70a08231
- transfer() = 0xa9059cbb
- transferFrom() = 0x23b872dd
- approve() = 0x095ea7b3

**Conclusion: This is a Factory contract (UniSwap V2 style), NOT an ERC20 token.**

## Fork Testing Results (forge --fork-url)

`forge test --fork-url <INK_RPC>` confirmed:

| Test | Result |
|------|--------|
| owner() | 0x1137d318222e93078Ee9452aAec13744D5B025F3 ✅ |
| implementation slot | 0x3c235b5017064516218F0bf4179bAE8d8b80392b ✅ |
| admin slot | 0x0000000000000000000000000000000000000000 (empty) |
| setFeeTo(owner) as owner | **SUCCEEDS** ✅ |
| feeTo() via interface | REVERT (wrong selector encoding) |
| updateFee() via interface | REVERT (wrong selector encoding) |
| getToken() via interface | REVERT (wrong selector encoding) |

**Storage inspection (vm.load on factory proxy):**
- slot 0: 0x5b39a78911c4eed30a9b0965013a41fc6b042ca6
- slot 1: 0xa8c1c38ff57428e5c3a34e0899be5cb385476507
- slot 2: 0x458c5d5b75ccba22651d2c5b61cb1ea1e0b0f95d
- slot 3: 0x1db8f9a6f0289d118311ea7bba97919e54456051

All 4 slots contain non-zero address values — contract has 4 address state variables (or is storing addresses in struct packing).

**Key finding: setFeeTo() works when called as owner.** This is a potential access control finding — if the owner is an EOA (not multisig/timelock), anyone who compromises the owner key can redirect protocol fees.

## RPC Access Summary (2026-05-31)

| Method | Status | Notes |
|--------|--------|-------|
| QuickNode managed (user-provided) | ✅ Works | Ink RPC functional |
| Public RPC (rpc-gel.inkonchain.com) | ❌ 403 Forbidden | Blocked |
| Ankr free | ❌ 403 Forbidden | Blocked |
| dRPC free | ❌ 403 Forbidden | Blocked |
| Tatum key (all chains) | ❌ 403 Forbidden | Blocked |
| BSC (bsc-dataseed.binance.org) | ✅ Works | Sanity check passed |
| Mantle (rpc.mantle.xyz) | ✅ Works | Block 96M |
| Etherlink (node.mainnet.etherlink.com) | ✅ Works | Block 44M |
| Sonic (rpc.soniclabs.com) | ✅ Works | Block 71M |
| explorer.inkonchain.com API | ✅ Partial | Proxy verified, impl not |
| Sourcify | ❌ 404 | Not indexed |

**Environment limitation**: Most free RPC providers return 403 in this environment. QuickNode endpoints work reliably. BSC, Mantle, Etherlink, Sonic public RPCs also work.

## Workflow Used (this session)

1. **anti-blocker-toolkit.md** → chain endpoints + fallback order
2. **QuickNode RPC** → eth_getCode (170 bytes = proxy)
3. **eth_getStorageAt** → EIP-1967 slot → implementation address
4. **Bytecode selector extraction** → 57 selectors from PUSH4 opcodes
5. **eth_call fingerprinting** → 9/43 selectors worked, identified factory pattern
6. **forge --fork-url** → confirmed owner, admin, setFeeTo finding
7. **Storage inspection** → 4 non-zero address slots

## Next Steps

1. Get managed Ink RPC for `eth_getCode` on implementation (bytecode still available)
2. Try decompiling bytecode with heimdall if source remains unavailable
3. Test `setFeeTo()` with different addresses as owner to understand fee drainage potential
4. Check if InkySwap has GitHub or audit report
5. Focus on feeTo / updateFee as the most actionable finding