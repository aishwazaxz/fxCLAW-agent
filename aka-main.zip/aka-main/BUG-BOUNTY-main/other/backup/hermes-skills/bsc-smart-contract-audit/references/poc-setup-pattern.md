# PoC Project Setup Pattern

When pipeline returns BLOCKED (compilation failed), create a working PoC project manually.

## Template foundry.toml

```toml
[profile.default]
src = "src"
out = "out"
libs = ["lib"]
solc_version = "0.8.28"
remappings = [
    "@openzeppelin/=lib/openzeppelin-contracts/"
]
```

## Step-by-Step

### 1. Create Structure
```bash
mkdir -p targets/<NAME>_PoC/{src/interfaces,test,lib}
cp targets/MACH_BSC_OrderBookV2/foundry.toml targets/<NAME>_PoC/
```

### 2. Install Dependencies
```bash
cd targets/<NAME>_PoC
forge install foundry-rs/forge-std --no-git
cp -r ../MACH_BSC_OrderBookV2/lib/openzeppelin-contracts lib/
```

### 3. Copy Interfaces
```bash
# From original target (flattened names)
cp ../<TARGET>/src_interfaces_*.sol src/interfaces/
cd src/interfaces
# Rename: src_interfaces_IOptimistic.sol → IOptimistic.sol
for f in src_interfaces_*.sol; do
    mv "$f" "${f#src_interfaces_}"
done
```

### 4. Fix Contract Imports
Common patterns in flattened source:
```solidity
// BROKEN (flattened):
import "./interfaces/IOptimistic.sol";  // ← works if file exists
import { OApp } from "./lzApp//lz-evm-oapp-v2/contracts/oapp/OApp.sol";  // ← double slash
import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";  // ← needs lib/

// FIXED:
import { OApp } from "./lzApp/lz-evm-oapp-v2/oapp/OApp.sol";  // ← remove "contracts/"
import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";  // ← works with remapping
```

### 5. Fix OZ 5.x Constructor
```solidity
// BROKEN (OZ 4.x style):
constructor(...) OApp(_endpoint, _owner) Ownable() {

// FIXED (OZ 5.x):
constructor(...) OApp(_endpoint, _owner) Ownable(_owner) {
```

### 6. Build Mock Contracts

**MockERC20:**
```solidity
contract MockToken {
    string public name;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    
    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
        totalSupply += amount;
    }
    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }
    function transfer(address to, uint256 amount) external returns (bool) {
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }
    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
        allowance[from][msg.sender] -= amount;
        return true;
    }
}
```

**Mock LZ Endpoint (CRITICAL - needs setDelegate):**
```solidity
contract MockLZEndpoint {
    function send(uint32, bytes calldata, bytes calldata, address, address, bytes calldata) external payable {}
    function setDelegate(address) external {}  // ← OApp constructor calls this!
}
```

### 7. Test Patterns

```solidity
contract PoCTest is Test {
    Orderbook public orderbook;
    MockToken public token;
    
    address public user = address(0xA);
    
    function setUp() public {
        // Deploy
        token = new MockToken();
        orderbook = new Orderbook(address(lzEndpoint), address(this), 1);
        
        // Mint & approve (use startPrank for multiple calls)
        token.mint(user, 1000e18);
        vm.startPrank(user);
        token.approve(address(orderbook), type(uint256).max);
        vm.stopPrank();
    }
    
    // Solidity 0.8+ reserved keywords: match, revert, etc.
    // Use: matchResult, revertResult, etc.
    function test_example() public {
        TradeInterface.Order memory order = orderbook.getOrder(...);
        // NOT: Order memory order (won't compile if Order is in interface)
    }
}
```

## Common Compilation Errors

| Error | Fix |
|-------|-----|
| `Source "forge-std/Test.sol" not found` | `forge install foundry-rs/forge-std --no-git` |
| `Identifier not found: OrderDirection` | Use `TradeInterface.OrderDirection` |
| `Expected identifier but got 'match'` | Rename variable (reserved keyword) |
| `Wrong argument count for Ownable()` | Use `Ownable(owner)` for OZ 5.x |
| `unrecognized function selector setDelegate` | Add `setDelegate(address)` to mock |
| `Unable to resolve imports: "../utils/Context.sol"` | Install real OZ in lib/, don't use flattened files |

## Working Baseline

`/workspaces/BUG-BOUNTY/targets/MACH_BSC_OrderBookV2/` — 36 files, solc 0.8.28, compiles clean. Clone its `lib/` and `foundry.toml` for new targets.
