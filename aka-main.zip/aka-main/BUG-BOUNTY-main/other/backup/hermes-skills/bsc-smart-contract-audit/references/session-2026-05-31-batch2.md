# Session: 2026-05-31 Batch 2 — 11 Target Pipeline Run

## Targets (all from user-provided list)

| Target | Address | Proxy Type | Init Verdict | Gate Result |
|--------|---------|------------|--------------|-------------|
| MACH_BSC_OrderBook | 0xB6A80Ef... | Not a proxy | init=0, FP | BLOCKED (compile) |
| PARALLEL_BSC_USDp | 0x048C4e... | UUPS → TokenP | init=1 | BLOCKED (compile) |
| PARALLEL_BSC_TokenP | 0x411dc6... | Not a proxy | init=1 | BLOCKED (compile) |
| PARALLEL_BSC_FlashParallelToken | 0x9ffacb... | Not a proxy | init=1 | BLOCKED (compile) |
| SYMMIO_BSC_BridgeFacet | 0x8cAE94... | Diamond facet | init=0, FP | BLOCKED (compile) |
| SYMMIO_BSC_LiquidationFacet | 0x4d00aD... | Diamond facet | init=0, FP | BLOCKED (compile) |
| LISTA_BSC_StableSwapPoolInfo | 0x73D262... | UUPS | impl=MAX_UINT | BLOCKED (compile) |
| LISTA_BSC_StableSwapPool_slisBNB | 0x3DcEA6... | UUPS | impl=MAX_UINT | BLOCKED (compile) |
| LISTA_BSC_SmartProvider_solvBTC | 0xA5F53c... | UUPS | impl=MAX_UINT | BLOCKED (compile) |
| LISTA_BSC_StableSwapPool_U_USDT | 0x6783a0... | UUPS | impl=MAX_UINT | BLOCKED (compile) |
| LISTA_BSC_StableSwapPool_USCD_USDT | 0xF5448f... | UUPS | impl=MAX_UINT | BLOCKED (compile) |

ALL BLOCKED — root cause is fetch_source.py import path mismatch, not the contracts.

## LISTA Proxy Verification (cast storage proof)

```
LISTA StableSwapPool_slisBNB (0x3DcEA6AFBA8af84b25F1f8947058AF1ac4c06131):
  ERC1967 Impl (0x360894...): 0x212b836dc1ee8c8daefd1284bd27e96a2ea3a126
  ERC1967 Admin (0xb53127...): 0x0000...0000 (NOT SET)
  Initializable (0xf0c57e...): 0x01 (version=1)
  Impl init slot: 0xffffffffffffffff (MAX_UINT, reinit blocked)
```

## MACH OrderBook V1 Deep-Dive (function-level analysis)

### executeMatch() — L154-211
- Public function, only callable by maker (msg.sender == order.sender)
- Pulls maker funds via transferFrom, pays taker
- L191: raw `.call{value}` for native token unwrap (reentrancy surface)
- L206: `order.settled += srcQuantity` (no CEIV protection but settled check at L176)
- L207: sanity check "remove in prod" comment

### confirmMatch() — L213-254
- Finalizes match after challenge window (block.number > validBlock)
- Fee split: applyFee + bondFee functions
- L240-242: sanity checks with "remove in prod" comments
- No reentrancy guard on transfers (L249-251)

### unwindMatch() — L273-293
- Cancel match, refund bond + principal
- Only receiver can call (L282)
- Finalizes match, zeros out funding

### cancelOrder() — L256-271
- **Observation**: Does NOT refund settled funds, only zeros `srcQuantity`
- If order is partially settled, user loses already-settled amounts
- However: this is order-level cancel (pre-match), settled amounts are already transferred out
- Not a vulnerability: settled funds are gone via executeMatch already

## Pipeline Fixes Applied This Session

1. **bscscan_query.py**: Fixed `isinstance(block, dict)` check for eth_getBlockByNumber result
2. **Foundry install**: `foundryup` now works (v1.7.1)
3. **Pipeline diagnostic protocol**: Added 7-question methodology to skill

## Key Insight

When ALL targets return BLOCKED at compilation, the problem is ALWAYS the tooling (fetch_source.py import mismatch), NEVER the contracts. Fix the pipeline first before analyzing more targets.
