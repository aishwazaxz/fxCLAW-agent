# MACH OrderBook Analysis (2026-05-31)

## Contract: Orderbook (0xB6A80EfAAB1d5CC7fC337b9924ef218547F6E9B8)

Cross-chain optimistic orderbook using LayerZero. Diamond pattern NOT used — this is a standalone contract.

## On-Chain Verification (2026-05-31)

**Contract**: `0xB6A80EfAAB1d5CC7fC337b9924ef218547F6E9B8` on BSC

| Check | Result | Status |
|-------|--------|--------|
| Code size | 20,655 bytes | Full implementation ✅ |
| Owner | `0x451F52446EBD4376d4a05f4267eF1a03Acf1aAf4` | EOA (not multisig) |
| srcLzc | 30102 | LayerZero chain ID |
| endpoint | `0x1a44076050125825900e736c501f859c50fE728c` | LayerZero V2 |
| maxFee | 1001 (10.01%) | Configured |
| WBNB/USDT/BUSD balance | 0 | No TVL ❌ |
| getOrder (WBNB/USDT, lzc 0-6) | All revert/empty | No active orders ❌ |
| Storage slots 0-20 | Mostly zeros | Inactive ❌ |

**Verdict: TARGET IS DEAD.** No TVL, no active orders. Contract verified on BSCScan but abandoned.

**PoC findings remain valid**: The `cancelOrder` logic bugs are confirmed real via 6 passing mock tests. They would be exploitable IF the protocol had TVL. Since TVL=0, no real fund loss is possible.

**Confidence: MEDIUM** — bugs confirmed in logic (HIGH via PoC), but no real money at risk. Cannot claim HIGH without active protocol state.

## Key Functions

### placeOrder (L43-79)
- Creates order intent, NO funds pulled
- `isMaker` flag determines flow: true→executeMatch, false→createMatch

### createMatch (L103-152) — Taker flow
- Bonder matches taker order
- Pulls: taker's srcQuantity + bonder's bondAmount
- Requires: `funding.srcQuantity == srcQuantity` (no partial fills for takers)
- Sets `order.settled += srcQuantity` (full settlement)

### executeMatch (L154-211) — Maker flow
- Only `order.sender` (maker) can call
- Pulls maker's srcQuantity, pays counterparty immediately
- Supports `isUnwrap` for native token delivery (reentrancy risk via `.call{value}`)
- **REENTRANCY**: State changes (receipt, settled) happen AFTER external call at L191

### confirmMatch (L213-254)
- Finalizes after challenge window
- Splits: maker payout, bonder fee, bond return
- Sanity checks T1/T2/T5 (comments say "remove in prod")

### cancelOrder (L256-271) — **VULNERABLE**
- Only zeros `srcQuantity`, does NOT refund
- Check: `settled < srcQuantity` (allows cancel after partial executeMatch)
- Does NOT check for active matches
- Does NOT check `srcQuantity > 0` guard

### unwindMatch (L273-297)
- Receiver cancels match, refunds taker
- Uses `_order.funding.srcQuantity` for refund amount

## Verified Findings (PoC PASS - 6/6)

### Finding 1: cancelOrder State Inconsistency
**Severity**: Medium | **Confidence**: HIGH (forge test PASS)
**Location**: cancelOrder L267
**Issue**: After partial executeMatch + cancelOrder, `settled > srcQuantity`
```
Maker: placeOrder(100) → executeMatch(50) → cancelOrder()
State: settled=50, srcQuantity=0 ← INVARIANT VIOLATION
```
**Impact**: Order enters invalid state. No direct fund theft but breaks downstream integrations.

### Finding 2: No Refund for Already-Transferred Funds
**Severity**: Low-Medium | **Confidence**: HIGH (forge test PASS)
**Location**: cancelOrder L267
**Issue**: cancelOrder doesn't refund tokens already pulled by executeMatch
```
Maker loses 50 tokens permanently after cancel
Counterparty keeps the 50 tokens (already transferred)
```
**Impact**: Maker can lose funds if they cancel after partial execution. But arguably expected behavior.

### Finding 3: Zero-Amount Match After Cancel
**Severity**: Low | **Confidence**: HIGH (forge test PASS)
**Location**: createMatch L123 (missing srcQuantity > 0 check)
**Issue**: After cancelOrder (srcQuantity=0), createMatch(0) succeeds
```
Taker: placeOrder → cancelOrder → bonder: createMatch(0) succeeds
Creates meaningless match with zero value
```
**Impact**: Gas griefing. No fund loss.

### Finding 4: Race Condition (Front-run)
**Severity**: Informational | **Confidence**: HIGH (forge test PASS)
**Issue**: Taker can front-run bonder's createMatch with cancelOrder
**Impact**: Bonder wastes gas. Expected behavior for cancelable orders.

## Not Exploitable (Verified Safe)

### unwindMatch After Cancel
- cancelOrder's `settled < srcQuantity` check prevents this
- If check was bypassed, unwindMatch would refund 0 (dangerous)
- Currently safe but worth monitoring in upgrades

## Reentrancy Note
executeMatch L191 has `Counterparty.call{value}` BEFORE state updates (L200-206). If isUnwrap=true and Counterparty is malicious, reentrancy possible. Impact limited because maker pulls from themselves. Worth deeper analysis if protocol becomes active.

## PoC Location
`/workspaces/BUG-BOUNTY/targets/MACH_PoC/test/CancelOrderPoC.t.sol`
All 6 tests PASS.

## Forge Test Pattern (Numeric Address Casting)

When writing forge fork tests against real contracts, Solidity's EIP-55 checksum validation breaks compilation for many addresses. Use numeric uint160 initialization in `setUp()`:

```solidity
address constant ORDERBOOK; // no constant initializer

function setUp() public {
    vm.createSelectFork(BSC_RPC);
    // Compute uint160 value: int("0xB6A80EfAAB1d5CC7fC337b9924ef218547F6E9B8", 16)
    ORDERBOOK = address(uint160(1042784150353337158690537566935212775794416216504));
}
```

Compute uint160 values offline (via `int("0x...", 16)` in Python), store as plain numbers in the test file, initialize in `setUp()`.

**Also**: inline assembly `extcodesize()` cannot reference Solidity constants. Copy to local variable first:
```solidity
address a = ORDERBOOK;
assembly { codeSize := extcodesize(a) }
```