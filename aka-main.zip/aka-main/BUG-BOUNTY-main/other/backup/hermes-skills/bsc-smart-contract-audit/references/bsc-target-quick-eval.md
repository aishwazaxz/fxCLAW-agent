# BSC Target Quick-Evaluation Reference (2026-05-31)

## Bytecode Size Triage

First check: `cast code <addr> --rpc-url <BSC_RPC>` (or equivalent)

| Bytecode Size | Interpretation | Action |
|---------------|----------------|--------|
| < 200 bytes | Proxy (ERC1967/UUPS/Beacon) OR dead address OR wrong contract | Check EIP-1967 slots; if impl slot zero = dead/not-proxy |
| 200-500 bytes | Standard proxy pattern | Read impl slot, fetch impl source |
| 1000-5000 bytes | Token, simple factory | Verify TVL is HERE (tokens ≠ vaults) |
| 5000-20000 bytes | Full DeFi contract (lending, DEX, vault) | Full investigation warranted |
| 20000+ bytes | Complex protocol (diamonds, large factories) | High complexity, plan accordingly |

**Example:** SYMMIO vault at 0x9A9F48888600FC9c05f11E03Eab575EBB2Fc2c8f = **185 bytes** → too small to be real SYMMIO contract. Investigation stopped immediately. Check DeFiLlama for correct address.

## Chain-Specific Patterns Observed (2026-05-31)

### BSC

- **LISTA pools** (StableSwapFactory pattern): Factory at `0x...` uses UUPS + AccessControlEnumerableUpgradeable. Deployer role required for `createSwapPair`. Proxy pattern: ERC1967Proxy. Key storage: `lpImpl`, `swapImpl` (slots 0,1), `stableSwapPairInfos` (mapping). Admin slot often unset (proxy admin = 0 or separate proxy admin contract).
- **THENA AlgebraFactory**: 125-line factory, not proxy. Owner can change farming/vault addresses and fee params. No two-step ownership transfer. DeFiLlama shows no TVL for AlgebraFactory address.
- **MACH OrderBook**: CancelOrder logic bugs (6 PoC passing) — use `mach-orderbook-cancelorder-findings` skill.
- **PARALLEL FlashParallelToken**: Uses AccessManager (OZ 5.x). Complex token with ERC20 + AccessManaged + Upgradeable. 4818-line impl_sources.sol with multiple contracts.

### Ink

- **InkySwap TokenFactory**: 16,445-byte implementation. Factory (UniSwap V2 style). Correct access control confirmed. setFeeTo works from owner only. All mystery selectors are pure getters returning hardcoded values. **VERDICT: CLEAN.**
- QuickNode managed RPC required (public RPCs 403). Working: `https://crimson-solitary-isle.ink-mainnet.quiknode.pro/c58c6f3d31844addbec45521ea20c278a7fe6670`.

### Cross-Chain

- **MoneyFi** (cross-chain vault + router): 34K+ lines total across all files. `MoneyFiStargateCrossChain` uses LayerZero OFT compose pattern. `lzCompose` validates `msg.sender != LZ_ENDPOINT`. Funds flow: user → bridge → lzCompose → fundVault deposit. Complex — requires separate investigation.

## Target Verification Checklist

Before deep investigation, run:

```python
# 1. Bytecode size (proxy vs impl vs dead)
cast code <addr> --rpc-url <RPC>

# 2. EIP-1967 slots (if proxy)
cast storage <addr> <0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc> --rpc-url <RPC>  # impl
cast storage <addr> <0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103> --rpc-url <RPC>  # admin

# 3. Owner (if any)
cast call <addr> "owner()" --rpc-url <RPC>

# 4. TVL check (DeFiLlama vs on-chain balance)
# DeFiLlama chain name: "Binance" for BSC
```

## Common Red Herrings

| Red Herring | Why Misleading | Correct Approach |
|-------------|----------------|-----------------|
| `audit_gate_results/findings.json` = `[]` | Target was scanned but NOT fully analyzed | Run pipeline manually, not just gate check |
| Contract verified but wrong address | DeFiLlama returns token address, not vault | Look for `setPool`, `setVault`, `setStaking` in source |
| EIP-1967 slot = 0x0 | NOT a proxy — IS the implementation | Fetch source directly, not via proxy checker |
| "CONTRACT NOT INITIALIZED" on diamond facet | False positive — facets aren't initialized | `proxy_checker.py` says "may not be a proxy" = real signal |
| 185-byte "vault" | Too small to hold real funds | Stop investigation, find correct address |

## Finding Status (2026-05-31)

| Target | Status | Confidence |
|--------|--------|------------|
| MACH OrderBook cancelOrder | 6 logic bugs confirmed | HIGH (PoC passed) |
| INKYSWAP TokenFactory | Clean — correct access control | N/A |
| SYMMIO BSC vault | Wrong address (185 bytes) | NONE |
| LISTA StableSwapFactory | Needs full pipeline | PENDING |
| moneyfi | Complex cross-chain, needs separate session | PENDING |
| THENA AlgebraFactory | No TVL at address | LOW |