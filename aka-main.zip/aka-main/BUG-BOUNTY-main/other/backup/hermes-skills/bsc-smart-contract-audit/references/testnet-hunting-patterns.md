# Testnet Hunting Patterns

## Workflow

1. **Connect**: Verify RPC connection with `cast chain-id --rpc-url <RPC>`
2. **Scan**: Run `block_scanner.py` on recent blocks (5-20 blocks)
3. **Filter**: Focus on contracts with 2+ calls per block (active DeFi)
4. **Analyze**: Run `contract_analyzer.py` on top contracts
5. **Detect**: Run `defi_detector.py` for vulnerability patterns
6. **Learn**: Study the mechanism, keep tools, discard results

## Function Selector Quick Reference

### DeFi Core
```
0x38ed1739  swapExactTokensForTokens
0x7ff36ab5  swapExactETHForTokens
0x022c0d9f  swap(uint256,uint256,address,bytes)
0x128acb08  swap(address,bool,int256,uint160,bytes)
0xa0712d68  mint(uint256)
0xdb006a75  redeem(uint256)
0x6e553f65  deposit(uint256,address)
0x2e1a7d4d  withdraw(uint256)
0x69328dec  withdraw(uint256,address)
```

### Token (ERC20)
```
0xa9059cbb  transfer(address,uint256)
0x23b872dd  transferFrom(address,address,uint256)
0x095ea7b3  approve(address,uint256)
0x70a08231  balanceOf(address)
0xdd62ed3e  allowance(address,address)
0x18160ddd  totalSupply()
```

### Access Control
```
0xf2fde38b  transferOwnership(address)
0x8da5cb5b  owner()
0x715018a6  renounceOwnership()
0x4300080a  — (unknown, common in appchains)
```

### Bridge
```
0x2ef6f1ab  mint((address,address,address,uint256,uint256))
0xc6c3bbe6  mint(address,address,uint256)
0xabd31150  supplyToBacking(uint256,uint256)
0xcd2e9866  totalBridgedOut()
```

### Staking
```
0xa694fc3a  stake(uint256)
0x2e17de78  unstake(uint256)
0x3d18b912  getReward()
0x2b4eb875  claimRewards()
```

## Bytecode Size Triage

| Size | Interpretation |
|------|---------------|
| < 200 bytes | Suspicious — too small for DeFi (likely dead/placeholder) |
| 200-500 bytes | Likely proxy (ERC1967, UUPS, Beacon) |
| 500-2000 bytes | Medium contract (token, simple vault) |
| 2000-10000 bytes | Full contract (DEX, lending) |
| 10000+ bytes | Complex DeFi (perps, bridge, multi-strategy) |

## Appchain Detection Signs

1. **Custom sequencer address**: e.g., `0xA4b0...73657175656e636572` (ASCII "sequencer")
2. **System precompiles**: Addresses like `0x...A4B05` with `0xfe` (INVALID) bytecode
3. **USDe/ETH as gas token**: Not standard ETH
4. **Custom chain ID**: Not 1 (mainnet) or standard testnet IDs
5. **Block production calls**: `startBlock()` called every block by sequencer

## DeFi Vulnerability Patterns

### Reentrancy Risk Functions
- `deposit()`, `withdraw()`, `redeem()` — modify state before external calls
- `approve()` + `transferFrom()` — approval race condition

### Flash Loan Attack Surface
- `flashLoan()` callbacks
- `safeExecute()` — arbitrary execution
- Price-dependent mint/burn

### Oracle Manipulation
- Spot price from DEX pool (manipulable)
- TWAP with short window
- Single-source oracle

### Supply Manipulation
- `mint(address,uint256)` with weak access control
- `burn(address,uint256)` callable by non-owner
- `setMintable(address,bool)` — who can toggle?

### Bridge Risks
- Cross-chain mint without burn verification
- `supplyToBacking()` — can backing be drained?
- `destinationEndpointId` — routing to wrong chain?

## Testnet-Specific Notes

- **No real value**: Testnet tokens are free — findings have no direct financial impact
- **Different code**: Testnet contracts may differ from mainnet (earlier version, debug mode)
- **Active testing**: Other developers may be testing — observe patterns
- **Faucet bots**: High-nonce addresses are often faucets/bots, not real users
- **USDe on testnet**: Used as gas token on Ethereal testnet — different from mainnet USDe
