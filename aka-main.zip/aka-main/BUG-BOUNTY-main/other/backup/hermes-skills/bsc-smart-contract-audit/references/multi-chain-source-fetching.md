# Multi-Chain Source Fetching Reference

## Retrieval Order (Per anti-blocker-toolkit.md)

1. Protocol docs contract list
2. Chain explorer verified source
3. Blockscout API v2
4. Etherscan-compatible explorer API
5. Sourcify lookup
6. GitHub/source repo baseline if protocol is fork
7. Bytecode + ABI/selectors fallback
8. Decompile only as last resort

## Explorer API Endpoints by Chain

| Chain | Explorer | API Base | API v2 |
|-------|----------|----------|--------|
| Cronos | cronos.org/explorer | `https://cronos.org/explorer/api` | `https://cronos.org/explorer/api/v2/smart-contracts/<ADDR>` |
| Etherlink | explorer.etherlink.com | `https://explorer.etherlink.com/api` | `https://explorer.etherlink.com/api/v2/smart-contracts/<ADDR>` |
| Ink | explorer.inkonchain.com | `https://explorer.inkonchain.com/api` | `https://explorer.inkonchain.com/api/v2/smart-contracts/<ADDR>` |
| Mantle | explorer.mantle.xyz | `https://explorer.mantle.xyz/api` | `https://explorer.mantle.xyz/api/v2/smart-contracts/<ADDR>` |
| Plume | explorer.plume.org | `https://explorer.plume.org/api` | `https://explorer.plume.org/api/v2/smart-contracts/<ADDR>` |

## Sourcify Lookup

```
GET https://sourcify.dev/server/v2/contract/<CHAIN_ID>/<ADDRESS>
```

Chain IDs: Cronos=25, Etherlink=42793, Ink=57073, Mantle=5000, Plume=98866, Rootstock=30.

Returns 200 + metadata if verified, 404 if not.

## Blockscout API v2 Patterns

For chains with blockscout-style explorers (most EVM chains):

```python
# Get contract info + ABI
url = f"{EXPLORER_API}/v2/smart-contracts/{address}"
# Returns: name, abi, source_code, compiler_version, etc.

# Get source code
url = f"{EXPLORER_API}?module=contract&action=getsourcecode&address={address}"
# Returns: SourceCode, ContractName, CompilerVersion, OptimizationUsed

# Get ABI only
url = f"{EXPLORER_API}?module=contract&action=getabi&address={address}"
# Returns: ABI JSON array

# Get contract creation
url = f"{EXPLORER_API}?module=contract&action=getcontractcreation&address={address}"
```

## Cronos-Specific Notes

- cronos.org/explorer/api returns data where cronoscan.com is blocked
- All Orby contracts are TransparentUpgradeableProxy (5 functions only: admin, changeAdmin, implementation, upgradeTo, upgradeToAndCall)
- Implementation addresses found via `ImplementationAddress` field in API response
- Implementation contracts are NOT verified on cronos.org explorer
- Liquity is the known fork baseline for Orby: `https://github.com/liquity/dev`

## Fork-Diff Hypothesis Method

When source is unavailable but target is a known fork:

```python
# 1. Get implementation bytecode selectors
# Option A: via explorer API proxy response
# Option B: via bytecode decode (PUSH4 opcode = 0x63)

# 2. Fetch baseline fork source
baseline_url = f"https://raw.githubusercontent.com/liquity/dev/main/packages/contracts/contracts/{Contract}.sol"

# 3. Extract function signatures from baseline
import re
funcs = re.findall(r'function\s+(\w+)\s*\(', baseline_source)

# 4. Compare selector sets
# Known Liquity selectors: openTrove, withdrawLUSD, repayLUSD, adjustTrove, closeTrove, liquidate, redeemCollateral, etc.
# If Orby has extra/modified selectors → modification point = potential finding

# 5. Build hypothesis
# Example: "Orby modified redemption logic from Liquity → check if redemption edge case still protected"
```

## Bytecode Selector Extraction

```python
def extract_selectors(bytecode_hex):
    """Extract function selectors from contract bytecode."""
    bc = bytecode_hex[2:]  # strip 0x
    selectors = set()
    for i in range(0, len(bc) - 8, 2):
        if bc[i:i+2] == '63':  # PUSH4
            selectors.add('0x' + bc[i+2:i+10])
    return sorted(selectors)
```

## Function Selector Fingerprinting (eth_call Discovery)

When source is unavailable and bytecode is small (~170 bytes = proxy, ~16KB+ = implementation), use `eth_call` with known selectors to determine contract type BEFORE trying to decompile:

```python
KNOWN_ERC20 = ["0x06fdde03", "0x95d89b41", "0x18160ddd", "0x70a08231", "0xa9059cbb", "0x23b872dd"]
KNOWN_FACTORY = ["0x4282af14", "0x4f1ef286", "0x52d1902d", "0x59d0f713", "0x8da5cb5b"]

def fingerprint_contract(address, rpc_url):
    """Call view functions to determine contract type."""
    def eth_call(addr, selector):
        payload = json.dumps({"jsonrpc": "2.0", "method": "eth_call",
            "params": [{"to": addr, "data": selector}, "latest"], "id": 1})
        req = urllib.request.Request(rpc_url, data=payload.encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())
    
    results = {}
    for selector in KNOWN_ERC20 + KNOWN_FACTORY:
        r = eth_call(address, selector)
        results[selector] = 'WORKS' if r.get('result') and r['result'] != '0x' else 'REVERT'
    
    erc20_count = sum(1 for s in KNOWN_ERC20 if results.get(s) == 'WORKS')
    factory_count = sum(1 for s in KNOWN_FACTORY if results.get(s) == 'WORKS')
    
    if erc20_count >= 3: return "ERC20 token"
    if factory_count >= 2: return "Factory (DEX/pair)"
    if results.get("0x8da5cb5b") == 'WORKS': return "Has owner() - likely non-token contract"
    return "Unknown type"
```

**InkySwap TokenFactory case study:**
- Proxy: 0x1D74317d760f2c72A94386f50E8D10f2C902b899 (170 bytes)
- Impl: 0x3c235b5017064516218f0bf4179bae8d8b80392b (16445 bytes)
- `owner()` → 0x1137d318222e93078ee9452aaec13744d5b025f3 ✓
- `name()`, `symbol()`, `totalSupply()`, `balanceOf()` → all REVERT (NOT ERC20)
- `feeTo()` → 0 ✓, `updateFee()` → 3e18 ✓, `createPair()` → large uint ✓
- **Conclusion: Factory contract, not token** — selectors match UniSwap V2 factory pattern

## Chain RPC Status (2026-05-31)

| Chain | Public RPC | Status | Notes |
|-------|-----------|--------|-------|
| BSC | `https://bsc-dataseed.binance.org` | ✅ Works | Primary |
| Mantle | `https://rpc.mantle.xyz` | ✅ Works | Block 96M |
| Etherlink | `https://node.mainnet.etherlink.com` | ✅ Works | Block 44M |
| Sonic | `https://rpc.soniclabs.com` | ✅ Works | Block 71M |
| Cronos | `https://evm.cronos.org` | ❌ 403 | Use managed RPC |
| Ink | `https://rpc-gel.inkonchain.com` | ❌ 403 | Use QuickNode below |
| Plume | `https://rpc.plume.org` | ❌ 403 | Use managed RPC |

**QuickNode managed RPC format:**
```
https://<id>.ink-mainnet.quiknode.pro/<key>/
```
Example: `https://crimson-solitary-isle.ink-mainnet.quiknode.pro/c58c6f3d31844addbec45521ea20c278a7fe6670/`

Same pattern applies for other chains: `<id>.<chain>-mainnet.quiknode.pro/<key>/`.

## Confidence Levels

| Source Available | Method | Confidence |
|-----------------|--------|------------|
| Full source, compiles | Manual + PoC | HIGH |
| Full source, compiles | Fork-diff + PoC on modified fork | HIGH |
| Source unavailable | Fork-diff hypothesis (bytecode selectors vs baseline) | MEDIUM |
| Source unavailable | eth_call fingerprinting + fork-diff hypothesis | MEDIUM |
| Source unavailable | ABI only (from proxy or events) | LOW |
| No source, no ABI, no bytecode | Nothing to work with | LIMITED / skip |

## Common Pitfalls

1. **Proxy ≠ Implementation**: The proxy address has minimal bytecode. You MUST read the implementation slot to get the real contract address.
2. **Implementation not verified**: Most chains only verify proxy contracts, not implementations. Use fork-diff approach.
3. **Blockscout v2 400 Bad Request**: The v2 endpoint may not support all address types. Fall back to v1-style API.
4. **Sourcify 404**: Contract not verified on Sourcify. Use explorer API or bytecode fallback.
5. **RPC 403**: Many public RPCs block. Use explorer API as fallback, or use managed RPC keys (QuickNode, Ankr, dRPC, Tenderly, BlockPI).
6. **Multi-file source JSON**: BSCScan/Etherscan V2 wraps multi-file sources in `{{"language":"Solidity","sources":{...}}}`. Strip first+last char before `json.loads()`.
7. **Small bytecode ≠ no contract**: A 170-byte contract is likely a proxy. Read EIP-1967 impl slot to find the real implementation (16KB+ bytes).
8. **Token contract ≠ TVL contract**: Many protocol addresses from DeFiLlama are the governance/utility token, NOT the vault/pool holding user funds. Always check for `setPool`, `setVault`, `setStaking`, `setCdpEngine` type functions.

## Quick CLI Reference

```bash
# Cronos source via cronos.org explorer API
curl -s "https://cronos.org/explorer/api?module=contract&action=getsourcecode&address=0x80d32B0FE29A56dd4b6eD5BdcfD2D488db4878fb"

# Sourcify lookup (Cronos, address)
curl -s "https://sourcify.dev/server/v2/contract/25/0x80d32B0FE29A56dd4b6eD5BdcfD2D488db4878fb"

# Ink QuickNode RPC (managed)
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
  "https://crimson-solitary-isle.ink-mainnet.quiknode.pro/c58c6f3d31844addbec45521ea20c278a7fe6670/"

# Function selector from known signatures
cast sig "openTrove(uint256,uint256,address)"
# keccak256 output: use first 4 bytes

# Read EIP-1967 impl slot via RPC
cast storage <PROXY_ADDR> 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc --rpc-url <RPC>
```

## Known Fork Baselines

| Target Chain | Target | Fork Of | Baseline URL |
|-------------|--------|---------|--------------|
| Cronos | Orby Network | Liquity | `github.com/liquity/dev` |
| Cronos | CronaSwap | MasterChef | `github.com/cronaswap/crona-contracts` |
| Any | Generic Aave-fork | Aave V3 | `github.com/aave/aave-v3-core` |
| Any | Generic Uniswap-fork | Uniswap V2 | `github.com/Uniswap/v2-core` |
| Any | Generic ERC-4626 vault | OpenZeppelin | `github.com/OpenZeppelin/openzeppelin-contracts` |