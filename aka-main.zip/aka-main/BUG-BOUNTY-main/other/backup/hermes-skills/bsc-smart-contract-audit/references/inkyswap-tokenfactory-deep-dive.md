# InkySwap TokenFactory — Deep Dive Findings (2026-05-31 continued)

## Three Mystery Selectors — Arg-Sensitivity Test

| Selector | Raw Result | Address Arg | Uint Arg | State Change |
|----------|-----------|-------------|----------|-------------|
| 0x7fd6f15c | 0x1f4 (500) | 0x1f4 (500) | 0x1f4 (500) | NO |
| 0xddca3f43 | slot7 addr | slot7 addr | slot7 addr | NO |
| 0xeff1d50e | slot3 addr | slot3 addr | slot3 addr | NO |

**Interpretation:** All three return hardcoded storage values. Data is IDENTICAL regardless of argument type (address, uint256, or no arg). This means the functions IGNORE their input — they are pure getters returning constants. Low exploit potential.

## Initial False Positive Explained

`FeeToAttack.t.sol` reported "SETTER WORKS FROM ATTACKER" for selectors 0x7fd6f15c, 0xddca3f43, 0xeff1d50e. This was a **testing artifact** — raw calldata without proper msg.sender simulation.

**Root cause:** When using raw calldata (`abi.encodeWithSelector(selector)` without a matching Solidity function signature), the proxy's fallback routes to the implementation. The implementation may return data even when the actual function has access control that would revert when msg.sender is checked.

**Fix:** Always verify with `forge test` + `vm.prank(attacker)` + Solidity interface.

## Access Control — Correct Behavior Confirmed

| Function | Attacker (forge test) | Called as Owner | Verdict |
|----------|----------------------|-----------------|---------|
| setFeeTo(address) | REVERT | WORKS | ✅ Correct |
| createPair(address,address) | REVERT | REVERT | ✅ Correct (needs valid tokens) |
| transferAdmin(address) | REVERT | N/A | ✅ Correct |
| pause() | REVERT | N/A | ✅ Correct |
| unpause() | REVERT | N/A | ✅ Correct |

**Implementation bytecode size:** 16,445 bytes (full implementation, not proxy)

## Final Verdict

**InkySwap TokenFactory has CORRECT access control. No exploitable vulnerability found.**

## Key Methodology Lesson

| Testing Method | What It Tests | Limitations |
|---------------|---------------|-------------|
| `cast call 0xselector` (raw) | Does the function exist + return data | Doesn't simulate msg.sender correctly |
| `forge test` + `vm.prank(attacker)` | Full access control + state changes | Requires Solidity interface |
| Arg-sensitivity test | Does function read its arguments? | Detects pure getters vs state readers |

**Rule:** Raw calldata screening → `forge test` verification → THEN claim vulnerability.

## InkySwap GitHub

- Org: https://github.com/inkyswap
- Repos: `swap-token-list` (token list JSON), `pump-mcp` (MCP server)
- **No Solidity source code published**

## QuickNode RPC Confirmation

Working Ink RPC (2026-05-31):
```
https://crimson-solitary-isle.ink-mainnet.quiknode.pro/c58c6f3d31844addbec45521ea20c278a7fe6670
```