# On-Chain Target Verification (2026-05-31)

## When to Use This

When you have a contract address and need to determine:
1. Is there real TVL?
2. Are there active users/orders?
3. Is the protocol dead or alive?
4. What is the on-chain state?

**Use BEFORE deep investigation.** Saves hours on dead targets.

## Step-by-Step Verification Checklist

### 1. Code Size (Quick Triage)
```bash
cast code <ADDR> --rpc-url <RPC>
# Result:
#   < 200 bytes:  suspicious — too small for real DeFi (likely proxy/placeholder)
#   200-500 bytes: likely proxy (ERC1967/UUPS/Beacon)
#   1000+ bytes:  likely implementation
#   5000+ bytes:  full contract (token, factory, vault)
```

### 2. Owner + Basic State
```bash
# Slot 0 = owner in many contracts
cast storage <ADDR> 0 --rpc-url <RPC>
# As address:
python3 -c "print('0x' + hex(int('<value>', 16))[-40:])"

# Try common view functions
cast call <ADDR> "owner()" --rpc-url <RPC>
cast call <ADDR> "srcLzc()" --rpc-url <RPC>
cast call <ADDR> "endpoint()" --rpc-url <RPC>
cast call <ADDR> "maxFee()" --rpc-url <RPC>
```

### 3. Token Balances (TVL Check)
```solidity
// In forge test
address[] memory tokens = [
    WBNB, USDT, BUSD, USDC, DAI
    // ... known chain tokens
];
for (uint i = 0; i < tokens.length; i++) {
    (bool ok, bytes memory data) = tokens[i].staticcall(
        abi.encodeWithSignature("balanceOf(address)", TARGET)
    );
    if (ok && data.length >= 32) {
        uint256 bal = uint256(bytes32(data));
        if (bal > 0) emit log_named_uint("FOUND TVL", bal);
    }
}
```

### 4. Storage Slot Scan (Find Active Data)
```solidity
// Check slots 0-20 for non-zero values
for (uint i = 0; i <= 20; i++) {
    bytes32 val = vm.load(TARGET, bytes32(uint256(i)));
    if (uint256(val) != 0) {
        emit log_named_uint(string(abi.encodePacked("Slot ", i)), uint256(val));
    }
}
```

### 5. Contract-Specific Queries
```solidity
// Try book()/getOrder() patterns (MACH-style orderbook)
bytes4 bookSel = bytes4(keccak256("book(uint256,address,address)"));
bytes4 getOrderSel = bytes4(keccak256("getOrder(address,address,uint256,uint256)"));

// WBNB/BUSD pair across multiple chains
for (uint256 lzc = 0; lzc < 10; lzc++) {
    (bool ok, bytes memory data) = TARGET.staticcall(
        abi.encodeWithSelector(bookSel, lzc, WBNB, BUSD)
    );
    if (ok && data.length > 32 && uint256(bytes32(data)) != 0) {
        emit log_named_uint("Active lzc", lzc);
    }
}
```

### 6. ABI Discovery (BSCScan)
```bash
# Get full ABI
curl -s "https://api.etherscan.io/v2/api?chainid=56&module=contract&action=getabi&address=$ADDR&apikey=$KEY" \
  | python3 -c "import json,sys; abi=json.loads(json.load(sys.stdin)['result']); [print(f['name']) for f in abi if f['type']=='function']"
```

## MACH Case Study (2026-05-31)

Contract: `0xB6A80EfAAB1d5CC7fC337b9924ef218547F6E9B8` (BSC)

| Check | Result | Interpretation |
|-------|--------|----------------|
| Code size | 20,655 bytes | Full implementation ✅ |
| Owner | `0x451F52446EBD4376d4a05f4267eF1a03Acf1aAf4` |EOA (not multisig) |
| srcLzc | 30102 | LayerZero chain ID |
| endpoint | `0x1a44076050125825900e736c501f859c50fE728c` | LayerZero V2 |
| maxFee | 1001 | 10.01% max fee |
| WBNB balance | 0 | No TVL ❌ |
| USDT balance | 0 | No TVL ❌ |
| BUSD balance | 0 | No TVL ❌ |
| getOrder (WBNB/USDT, lzc 0-6, idx 0-5) | All revert/empty | No active orders ❌ |
| Storage slots 0-20 | Mostly zeros | Contract inactive ❌ |

**Verdict: TARGET IS DEAD.** TVL=0, no active orders, contract verified on BSCScan but abandoned.

**Bug findings from local PoC**: 6 passing tests confirming `cancelOrder` logic bugs (state inconsistency, no refund for transferred funds, zero-amount match after cancel, race condition). Confidence: MEDIUM — bugs are real but protocol is inactive so no real fund loss possible.

**This is the correct outcome.** We verified on-chain, found nothing, documented the bugs via mock PoC, and moved on with a clear verdict. No wasted time on a dead target.