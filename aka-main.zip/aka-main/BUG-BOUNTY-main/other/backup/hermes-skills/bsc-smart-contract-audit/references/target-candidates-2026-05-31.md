# Target Candidates (2026-05-31)

Discovered by gpt-codex. All verified against DeFiLlama TVL < $1M range.

---

## 1. Lendle — Mantle Lending Market

**Chain:** Mantle | **TVL:** ~$552K | **Type:** Aave-style lending

**Risk surface:** lending pool accounting, liquidation edge cases, oracle config, WETHGateway native asset, reward accounting, MasterChef/incentives misconfiguration

**Contracts:**
- LendingPool: `0xCFa5aE7c2CE8Fadc6426C1ff872cA45378Fb7cF3`
- LendingPoolConfigurator: `0x30D990834539E1CE8Be816631b73a534e5044856`
- LendingPoolAddressesProvider: `0xAb94Bedd21ae3411eB2698945dfCab1D5C19C3d4`
- AaveOracle: `0x870c9692Ab04944C86ec6FEeF63F261226506EfC`
- AaveProtocolDataProvider: `0x552b9e4bae485C4B7F540777d7D25614CdB84773`
- WETHGateway: `0xEc831f8710C6286a91a348928600157f07aC55c2`
- MasterChef: `0xC90C10c7e3B2F14870cC870A046Bd099CCDDEe12`
- ChefIncentivesController: `0x79e2fd1c484EB9EE45001A98Ce31F28918F27C41`

**Docs:** https://docs.lendle.xyz/contracts-and-security/mantle-contracts

---

## 2. Superlend — Etherlink Lending Market

**Chain:** Etherlink | **TVL:** ~$604K | **Type:** Aave-style lending

**Risk surface:** reserve config mismatch, bad collateral parameters, oracle decimals/stale price, liquidation edge cases, gateway deposit/withdraw mismatch, slToken/debt token accounting

**Contracts:**
- Pool: `0x3bD16D195786fb2F509f2E2D7F69920262EF114D`
- PoolConfigurator: `0x30F6880Bb1cF780a49eB4Ef64E64585780AAe060`
- PoolAddressesProvider: `0x5ccF60c7E10547c5389E9cBFf543E5D0Db9F4feC`
- ACLManager: `0xcc42524a51E3999E87a4cC3c6871caCfAb9BDf30`
- Oracle: `0xeCF313dE38aA85EF618D06D1A602bAa917D62525`
- WrappedTokenGateway: `0x65fe928c5D04a2DA42347bA9D4d1C3f4952851F5`
- Treasury: `0x669bd328f6C494949Ed9fB2dc8021557A6Dd005f`

**Docs:** https://docs.superlend.xyz/superlend-markets/etherlink-market/deployed-contracts

---

## 3. Orby Network — Cronos CDP / Stablecoin

**Chain:** Cronos | **TVL:** ~$67K | **Type:** CDP stablecoin

**Risk surface:** liquidation math, stale oracle/price feed, collateral surplus withdrawal, redemption/repayment edge cases, StabilityPool accounting, undercollateralized state transitions

**Contracts:**
- BorrowerOperations: `0x80d32B0FE29A56dd4b6eD5BdcfD2D488db4878fb`
- TroveManager: `0x7A47cF15a1fCbAd09c66077d1D021430eed7AC65`
- PriceFeed: `0x6aBDda4D610cD61651E630e59141907390F08876`
- StabilityPool: `0xF766505680a63b5e70616Ef21b72814Ec5649945`
- CollSurplusPool: `0xbCC0019DaE95B493382105ABDb4E5e0E21951762`
- DefaultPool: `0x9A888Fba243570fCe8D82144A1f93712a1236940`
- SortedTroves: `0x5Aa450927B199e519cd4B098461D0FF79D13A42d`
- USC Token: `0xD42E078ceA2bE8D03cd9dFEcC1f0d28915Edea78`

**Docs:** https://doc.orby.network/additional-info/smart-contract-addresses

---

## 4. CronaSwap — Cronos DEX/Farm/Vault

**Chain:** Cronos | **TVL:** ~$417K | **Type:** DEX/farm/vault

**Risk surface:** MasterChef reward accounting, vault share accounting, migration/emergency withdraw, router fee-on-transfer edge cases, LP mint/burn assumptions, admin/timelock config risks

**Contracts:**
- Router: `0xcd7d16fB918511BF7269eC4f48d61D79Fb26f918`
- Factory: `0x73A48f8f521EB31c55c0e1274dB0898dE599Cb11`
- MasterChef: `0x77ea4a4cF9F77A034E4291E8f457Af7772c2B254`
- CronaVault: `0xDf3EBc46F283eF9bdD149Bb24c9b201a70d59389`
- CronaToken: `0xadbd1231fb360047525BEdF962581F3eee7b49fe`
- CronaBar: `0x25f0965F285F03d6F6B3B21c8EC3367412Fd0ef6`

**Docs:** https://docs.cronaswap.org/contract-detail

---

## 5. InkySwap / InkyPump — Ink Token Factory

**Chain:** Ink | **TVL:** ~$507K | **Type:** Token factory with bonding curve

**Risk surface:** token creation fee logic, bonding curve math, anti-snipe fee decay, creator fee exemption, graduation to Uniswap, permanent LP burn/liquidity handling, tradingEnabled state assumptions

**Contract:**
- TokenFactory: `0x1D74317d760f2c72A94386f50E8D10f2C902b899`

**Docs:** https://docs.inkyswap.com/api-reference/contracts/overview

---

## 6. Crodex / EmpireDEX — Cronos DEX

**Chain:** Cronos | **TVL:** ~$128K | **Type:** DEX

**Risk surface:** router swap math, pair reserve sync/skimming, fee-on-transfer token handling, LP mint/burn edge cases, escrow release assumptions, staking withdrawal fee/boost logic

**Contracts:**
- Factory: `0x06530550A48F990360DFD642d2132354A144F31d`
- Router: `0xdADaae6cDFE4FA3c35d54811087b3bC3Cd60F348`
- CRODEX Token: `0xc83859C413a6bA5ca1620cD876c7E33a232c1C34`
- CRODEX/CRO LP: `0x80523212e85e7FD850c85CC804263Ad421696d87`
- Escrow: `0x9fF555DDEbD500C0F1fa7C898dCbdb7CCa6809FC`
- WCRO: `0x5C7F8A570d578ED84E63fdFA7b1eE72dEae1AE23`

**Docs:** https://empire-dex.readthedocs.io/en/latest/multichain.html

---

## Priority Order for Bedah

1. **Lendle** (Mantle, $552K) — Aave-style lending, richest attack surface
2. **Superlend** (Etherlink, $604K) — same pattern, different chain
3. **Orby** (Cronos, $67K) — CDP, liquidation math, smallest TVL but unique surface
4. **CronaSwap** (Cronos, $417K) — MasterChef + vault, classic bug pattern
5. **InkySwap** (Ink, $507K) — bonding curve, unique surface
6. **Crodex** (Cronos, $128K) — DEX, lower priority