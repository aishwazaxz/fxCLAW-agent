---
name: m15
description: "m15 — Daily Assistant II: Watchdog, Vault, Multimodal, Triage (NEW in v4.0)"
tags: [agent, m15]
---

# m15 — Daily Assistant II: Watchdog, Vault, Multimodal, Triage (NEW in v4.0)

---

Empat kemampuan harian biar bot makin diandelin & gampang dipakai. Semua keyless di core; yang butuh model (vision/STT) pakai lokal/gratis atau provider m7 yang udah ada.

| Fitur | Script | Inti |
|---|---|---|
| Self-healing watchdog | `tools/watchdog.py` | mantau proses, restart yang mati (rate-limited), alert |
| Snippet/address vault + macro | `tools/vault.py` | "wallet kerja" → address; "morning routine" → steps |
| Voice & screenshot input | `tools/multimodal.py` | voice→teks (Whisper lokal), screenshot→paham (vision m7) |
| Inbox triage | `tools/triage.py` | skor + prioritasin pesan masuk, sodorin yang penting |

---

## 1. Self-healing watchdog

Mantau proses yang **operator daftarin eksplisit** (bukan dari input apa pun). Restart di-rate-limit (default 5×/jam) biar gak masuk loop restart; mentok rate → STOP + alert "butuh operator".

```python
from watchdog import Watchdog, WatchedProcess, shell_check, shell_restart
wd = Watchdog([
    WatchedProcess("openclaw", shell_check("openclaw"),
                   shell_restart(["pm2", "restart", "openclaw"]), max_restarts_per_hour=5),
])
await wd.run(notifier, interval_s=30)
```

Bot juga `Watchdog.touch_heartbeat()` tiap loop; watchdog cek `bot_heartbeat_alive()` buat deteksi hang. Selaras sama x4 `SAFE_AUTO_ACTIONS` (restart_crashed_process). **File ini FROZEN** — self-improve gak boleh ngeditnya.

## 2. Snippet/address vault + macro

```python
from vault import Vault
v = Vault()
v.put("wallet kerja", "0x52908...", kind="address")
v.add_macro("morning routine", ["cek portfolio", "cek gas", "cek claim window", "kirim briefing"])

addr = v.resolve_address("wallet kerja")   # "kirim ke wallet kerja" → resolve
steps = v.get_macro("morning routine")     # "jalanin morning routine" → eksekusi step
```

**SAFETY**: vault cuma nyimpen & resolve. Address hasil resolve, pas dipakai di tx, **tetap lewat governor + konfirmasi**. `kind="address"` divalidasi formatnya (EVM/base58). **File FROZEN** — kalau loop bisa ngeditnya, dia bisa diam-diam ganti "wallet kerja" jadi alamat attacker. Resolve label = anti salah-tempel + anti poisoning.

## 3. Voice & screenshot input

```python
from multimodal import transcribe, describe_image
text = transcribe("/tmp/voice.ogg")                    # Whisper lokal (gratis)
desc = describe_image("/tmp/shot.png", "error apa ini?", vision_fn=my_m7_vision)
```

STT lokal gratis: `pip install faster-whisper` (ringan) atau `openai-whisper`. Vision: wire `vision_fn` ke provider multimodal di m7 (Claude/GPT/Gemini). Pattern Telegram (wire di m4): voice→transcribe→route; photo→describe→route. Hasilnya diproses kayak pesan teks biasa (aksi dana tetap lewat governor).

## 4. Inbox triage

```python
from triage import Message, triage, format_digest
d = triage(messages, vips={"bos", "partner"}, my_handles={"@hermes"})
print(format_digest(d))   # 🔴 prioritas tinggi + ⚪ lainnya
```

Skor heuristik keyless: VIP sender + kata urgent + mention + pertanyaan + recency + link/address. Ringkasan opsional via `summary_fn` (m7). Bagus dipasang di briefing pagi (m14) atau on-demand.

---

## Env var

```bash
export HERMES_BOT_HEARTBEAT=~/.hermes/bot-heartbeat   # watchdog self-monitor
export HERMES_VAULT_DB=~/.hermes/vault.db
export HERMES_WHISPER_MODEL=base                       # tiny/base/small/medium
```

## Trigger phrases

`watchdog`, `restart kalau mati`, `pantau proses`, `simpen alamat`, `wallet kerja`, `macro`, `jalanin routine`, `voice note`, `transcribe`, `baca screenshot`, `triage`, `ringkas pesan`.
