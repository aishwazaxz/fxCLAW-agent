# ONIX Platform API Reference

Platform: api-onix-ns2.seamless-hptech.com
Framework: Laravel + MongoDB
Auth: d-key + domain_key + agent_id headers

## Required Headers

```
d-key: CS2ABA0
domain_key: CS2ABA0
agent_id: CS2ABA0
x-api-key: edV1^z5uhx6WN8z
User-Agent: okhttp/4.9.3
Accept: application/json
X-Requested-With: XMLHttpRequest
```

d-key values per app:
- CS2ABA0 = jangkar55
- CS2ABCA = asgacor
- CS2ABAJ = juara126
- CS2ABA1 = leon188
- CS2ABAG = nona55
- CS2ABAH = platinum789

## Session Flow

1. GET / → establishes session (onixgaming cookie)
2. GET /ajaxCSRFToken → returns CSRF token (no auth needed)
3. POST endpoints with _token in body + X-CSRF-TOKEN header

## Key Endpoints

### No Auth Required
- `GET /register` → Full platform config JSON (banks, ewallets, OTP status, honeypot, password regex)
- `GET /ajaxCSRFToken` → CSRF token
- `GET /promotion` → Promo banners + commission structure
- `GET /referral` → Referral config
- `GET /getHkgpLiveDraw` → Lottery live draw data

### Username Enumeration (POST with CSRF)
- `POST /login` — Different errors:
  - "tidak terdaftar" = user NOT registered
  - "password salah" = user EXISTS
- `POST /checkExistingEmail` — Returns true/false
- `POST /checkUserNameAvailability` — Returns true or validation message

### Auth Required (440 = not logged in)
- `GET /getBal` → Balance
- `GET /get_reward_balance` → Reward balance
- `GET /ajaxRedemption` → Redemption
- `GET /ajax{Provider}Bal` → Game provider balance (CMD, HKB, IDN, Pussy888)

## Register Page Data Leak

GET /register returns JSON with:
- 49+ bank accounts with MongoDB ObjectIDs
- 10 e-wallet methods (DANA, OVO, GOPAY, LinkAja, ShopeePay, Sakuku, Jenius, Doku, QRIS, QRISAUTO)
- is_disable_otp: true/false
- honeypot field structure (4 fields, 1 with hardcoded value)
- register_token format: CS2ABA0-{timestamp}-{random}
- Password regex, account name regex
- Admin/creator usernames in promo data

## Infrastructure

Payment gateway: stgapicurr.seamlesss-hptech.com (CF 403 HTTP, 500 HTTPS)
Help2Pay: stgpay.ug396-api.com (403)
Referral: stgapi.seamlesss-hptech.com (403)
CDN: css.apkstore888.com (HTTP)
Firebase: api-onix-ns2-live2-default-rtdb.firebaseio.com (READ OPEN)

Subdomains (same IP 45.194.53.26):
- admin.seamlesss-hptech.com
- stg.seamlesss-hptech.com
- stgapicurr.seamlesss-hptech.com

## Pitfalls

- CSRF token must be fresh (get before each POST batch)
- Rate limit: ~5 login attempts per 60 seconds
- POST /register returns 405 (registration via mobile app only)
- Game provider balance endpoints need auth (440 without)
- MongoDB ObjectIDs in register data can be used for IDOR
