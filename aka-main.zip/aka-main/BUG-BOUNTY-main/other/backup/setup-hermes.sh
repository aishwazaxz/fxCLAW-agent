#!/bin/bash
# Hermes Full Setup Script
# Jalankan ini di Codespace baru untuk restore semua config
# Usage: bash backup/setup-hermes.sh

set -e

echo "═══════════════════════════════════════════════════════════════"
echo " HERMES FULL SETUP"
echo "═══════════════════════════════════════════════════════════════"
echo ""

HERMES_DIR="$HOME/.hermes"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"

# 1. Create Hermes directories
echo "[1] Creating Hermes directories..."
mkdir -p "$HERMES_DIR/skills/security-audit"
mkdir -p "$HERMES_DIR/skills/agent"
mkdir -p "$HERMES_DIR/scripts/agent"
mkdir -p "$HERMES_DIR/memories"
echo "  Done"

# 2. Copy skills
echo ""
echo "[2] Copying skills..."
for skill_dir in "$SCRIPT_DIR/hermes-skills"/*/; do
    if [ -d "$skill_dir" ]; then
        skill_name=$(basename "$skill_dir")
        cp -r "$skill_dir" "$HERMES_DIR/skills/security-audit/$skill_name"
        echo "  ✓ $skill_name"
    fi
done

# 3. Copy scripts
echo ""
echo "[3] Copying scripts..."
cp "$SCRIPT_DIR/hermes-scripts"/*.py "$HERMES_DIR/scripts/agent/" 2>/dev/null
echo "  ✓ $(ls "$SCRIPT_DIR/hermes-scripts"/*.py | wc -l) scripts"

# 4. Copy memories
echo ""
echo "[4] Copying memories..."
cp "$SCRIPT_DIR/hermes-memories"/*.md "$HERMES_DIR/memories/" 2>/dev/null
echo "  ✓ $(ls "$SCRIPT_DIR/hermes-memories"/*.md | wc -l) memories"

# 5. Copy repo skills (from skills/ folder)
echo ""
echo "[5] Copying repo skills..."
for skill_file in "$REPO_DIR/skills"/*.md; do
    if [ -f "$skill_file" ]; then
        skill_name=$(basename "$skill_file" .md)
        skill_dir="$HERMES_DIR/skills/security-audit/$skill_name"
        mkdir -p "$skill_dir"
        
        # Create SKILL.md with frontmatter
        title=$(head -1 "$skill_file" | sed 's/^# //')
        cat > "$skill_dir/SKILL.md" << SKILLEOF
---
name: $skill_name
description: "$title"
tags: [security-audit, $skill_name]
---

$(cat "$skill_file")
SKILLEOF
        echo "  ✓ $skill_name"
    fi
done

# Copy m*.md skills
for skill_file in "$REPO_DIR/skills/m"/*.md; do
    if [ -f "$skill_file" ]; then
        skill_name=$(basename "$skill_file" .md)
        skill_dir="$HERMES_DIR/skills/agent/$skill_name"
        mkdir -p "$skill_dir"
        
        title=$(head -1 "$skill_file" | sed 's/^# //')
        cat > "$skill_dir/SKILL.md" << SKILLEOF
---
name: $skill_name
description: "$title"
tags: [agent, $skill_name]
---

$(cat "$skill_file")
SKILLEOF
        echo "  ✓ $skill_name"
    fi
done

# Copy x*.md skills
for skill_file in "$REPO_DIR/skills"/x*.md; do
    if [ -f "$skill_file" ]; then
        skill_name=$(basename "$skill_file" .md)
        skill_dir="$HERMES_DIR/skills/security-audit/$skill_name"
        mkdir -p "$skill_dir"
        
        title=$(head -1 "$skill_file" | sed 's/^# //')
        cat > "$skill_dir/SKILL.md" << SKILLEOF
---
name: $skill_name
description: "$title"
tags: [security-audit, $skill_name]
---

$(cat "$skill_file")
SKILLEOF
        echo "  ✓ $skill_name"
    fi
done

# 6. Copy agent tools to repo tools/
echo ""
echo "[6] Copying agent tools to tools/agent/..."
mkdir -p "$REPO_DIR/tools/agent"
cp "$SCRIPT_DIR/hermes-scripts"/*.py "$REPO_DIR/tools/agent/" 2>/dev/null
echo "  ✓ $(ls "$REPO_DIR/tools/agent"/*.py | wc -l) tools"

# 7. Verify
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo " SETUP COMPLETE"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "Skills installed:"
echo "  security-audit: $(ls "$HERMES_DIR/skills/security-audit/" | wc -l)"
echo "  agent: $(ls "$HERMES_DIR/skills/agent/" | wc -l)"
echo ""
echo "Scripts installed:"
echo "  $(ls "$HERMES_DIR/scripts/agent/"*.py | wc -l)"
echo ""
echo "Memories installed:"
echo "  $(ls "$HERMES_DIR/memories/"*.md | wc -l)"
echo ""
echo "Total skills: $(find "$HERMES_DIR/skills" -name "SKILL.md" | wc -l)"
echo ""
echo "Restart Hermes to load new skills."
echo "═══════════════════════════════════════════════════════════════"
