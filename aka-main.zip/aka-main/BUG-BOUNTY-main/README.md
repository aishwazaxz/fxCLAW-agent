# BUG-BOUNTY

Bug bounty hunting workspace.

## Structure

```
BUG-BOUNTY/
├── findings/           # Hasil hunting
│   ├── active/         # Target yang sedang di-hunt
│   └── completed/      # Target yang sudah selesai
│
├── tools/              # Tools untuk hunting
│   ├── web/            # Web hunting tools (XSStrike, sqlmap, dirsearch, nikto, cf-bypass, waf-bypass, browser, security)
│   └── web3/           # Web3/Onchain tools (contract interaction, exploit suite, testnet)
│
├── skills/             # Pure skills (knowledge & methodology)
│   ├── web-*           # Web hunting skills (bug-bounty, judol, hunting-workflow, dll)
│   ├── web3-*          # Web3 skills (defi, nft, swap, bridge, audit, dll)
│   ├── recon/          # Recon skills
│   └── security-audit/ # Security audit skills
│
└── other/              # Backup, config, dan misc
    ├── hermes-agent/   # Hermes config, memories, scripts
    ├── backup/         # Old backups
    ├── targets/        # Target lists
    ├── modules/        # Modules
    ├── recon-output/   # Recon output
    ├── agent/          # Agent tools
    ├── guides/         # Guides
    └── slotsmate/      # SlotsMate
```

## Quick Reference

- **Active findings**: `findings/active/`
- **Completed findings**: `findings/completed/`
- **Web tools**: `tools/web/`
- **Web3 tools**: `tools/web3/`
- **Skills**: `skills/`
- **Decepticon reference**: `/workspaces/aka/Decepticon/`

## Naming Convention

### Findings
- Active: `{target}_{vuln_type}/` atau `{target}_poc/`
- Completed: `{target}_{vuln_type}/` dengan evidence lengkap

### Skills
- Web: `web-{skill-name}/`
- Web3: `web3-{skill-name}/`
